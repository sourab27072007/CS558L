#!/bin/sh
a=$(date +"%s")
#echo "start time is $a"
./receiver 11 6 00:11:43:d6:d6:36 rdata21.bin &
./receiver 11 12 00:0e:0c:68:a8:57 rdata31.bin &
wait
b=$(date +"%s")
#echo "end time is $b"
diff=$((b-a))
#echo "execution time is $diff"
#printf "throughput is %d" $((8*2*10485760/(diff*1000000)))
#echo "Mbps"
echo "node A received all file segments"
echo "Checksum for rdata21.bin is "
md5sum rdata21.bin
echo "Checksum for rdata31.bin is"
md5sum rdata31.bin



./receiver rdata21.bin 6