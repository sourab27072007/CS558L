

#ifndef HEADER_H_
#define HEADER_H_

#define MAC_LENGTH 6
#define L3_length 2
#define DATA_LEN 1470
#define BUFF_SIZE 1500

/*ARP constants*/
#define ARP_REQUEST 1
#define ARP_REPLY 2


struct arp_header
{
	unsigned short opcode;
	unsigned char sender_mac[MAC_LENGTH];
	unsigned char sender_ip[L3_length];
	unsigned char target_mac[MAC_LENGTH];
	unsigned char target_ip[L3_length];
};

struct l3_header
{
	u_int16_t dest_addr;
	u_int16_t src_addr ;
	u_int16_t check;
	u_int8_t ttl;
	u_int8_t src_id;
	u_int8_t dest_id;
	u_int16_t data_check;
	u_int16_t seq_num;
	u_int8_t dummy;
};

#endif /* HEADER_H_ */
