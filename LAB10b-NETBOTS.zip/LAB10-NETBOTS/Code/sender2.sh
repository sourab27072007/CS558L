#!/bin/sh
./sender 11 5 6 data21.bin 00:04:23:ae:cc:32 21 3 &
./sender 31 7 8 data23.bin 00:0e:0c:68:a8:57 21 4 &
wait
echo "node 2 sent all file segments"
echo "checksum for data21.bin"
md5sum data21.bin
echo "checksum for data23.bin"
md5sum data23.bin

