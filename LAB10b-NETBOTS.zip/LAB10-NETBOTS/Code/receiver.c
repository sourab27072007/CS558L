

#include <arpa/inet.h>
#include <linux/if_packet.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <net/if.h>
#include <netinet/ether.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <netdb.h>
#include <netinet/ip.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <sys/mman.h>

#define PROTO_ARP 0x0806
#define MAC_LENGTH 6
#define L3_length 2
#define DATA_LEN 1470

#define DEFAULT_IF	"lo"//"eth3"//"eth0"//"enp0s3"//"eth0"
#define BUF_SIZ		1500
#define MAC_LENGTH 6
#define IPV4_LENGTH 2
#define MIN_APP_PKT_LEN			60 - sizeof(ipheader)-sizeof(struct ethhdr)

//Threads
pthread_t nack_thread;
pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;

/*ARP constants*/
#define ARP_REQUEST 1
#define ARP_REPLY 2

//Start Variables with other interface
int recv_file_fd, rem_data;
size_t filesize;
int packets_num;
unsigned int last_packet_size;
int my_addr;
uint16_t dest_addr;
u_int8_t dest_id = 0, src_id = 0;
uint8_t port;
long ur_offset = 0;
/* needed for reliable protocol */
int start_index = 1;
int last_index = 0;
;
int *track_packets;
int startCallback = 0;
int loop_index = 1;
int total = 0, ur_total = 0;
int Last_Packet_Data = 1;
char device_name[10];

//End Variables with other interface

char *recv_offset, *recv_memmap;
struct ethhdr *my_eth;
int hw_name;
int sockfd_send;
int sockfd_recv;
struct stat recv_statbuf;

//Function Declarations
void process_packet(int header, const u_char *packet, char *argv);
static long int Current_time();
static u_short ip_checksum(const u_char* Buffer);
void interface_index(int *hw_index, char*ethname);
int updateTrackPacketsArray(int seq_num);
void file_creation(char *);
void write_re_to_file(u_char * payload, int payload_size, int seqNum);
void* handleFailures(void *argv);
int check_all_pckt_rcvd();
void send_end();
void generate_route_on_resend_packet(u_char* packetOut, int size, int seqNum);
int getNackSeqNum();
void send_nack_to_client(int seqNum);

struct arp_header {
	unsigned short opcode;
	unsigned char sender_mac[MAC_LENGTH];
	unsigned char sender_ip[L3_length];
	unsigned char target_mac[MAC_LENGTH];
	unsigned char target_ip[L3_length];
};
typedef struct l3_header {
	u_int16_t dest_addr;
	u_int16_t src_addr;
	u_int16_t check;
	u_int8_t ttl;
	u_int8_t src_id;
	u_int8_t dest_id;
	u_int16_t data_check;
	u_int16_t seq_num;
	u_int8_t dummy;
} ipheader;

static long int Current_time() {
	struct timeval t;
	if (gettimeofday(&t, NULL) == -1) {
		perror("time");
		exit(1);
	}
	//return ((t.tv_sec) * 1000.0 + (t.tv_usec) / 1000.0);
	return t.tv_sec;

}
static u_short ip_checksum(const u_char* Buffer) {
	ipheader *iph = (ipheader*) (Buffer + sizeof(struct ethhdr));
	unsigned int sum = 0;

	iph->dummy = 0;
	/*    printf("\n ttl inside fn %d",iph->ttl);*/
	sum += (((u_short) iph->ttl) << 8) | (u_short) iph->dummy;
	sum += ntohs((iph->src_addr) & 0xff);
	sum += ntohs((iph->dest_addr) & 0xff);

	int chk = (((u_short)(sum >> 16)) & 0xf) + ((u_short)(sum) & 0xffff);
	return ~((u_short) chk);
}
void interface_index(int *hw_index, char*ethname) {
	struct ifconf ifc;
	struct ifreq ifr[10], if_ip;
	struct ifreq ifr_index;
	int sd, ifc_num, i;
	struct sockaddr_in ipaddr;
	char *eth_name = "eth";
	char *ip_address = "10";

	sd = socket(PF_INET, SOCK_DGRAM, 0);
	if (sd > 0) {
		ifc.ifc_len = sizeof(ifr);
		ifc.ifc_req = ifr;

		if (ioctl(sd, SIOCGIFCONF, (char*) &ifc) < 0) {
			printf("ioctl lookup failed\n");
			exit(0);
		}
		ifc_num = ifc.ifc_len / sizeof(struct ifreq);

		for (i = 0; i < ifc_num; i++) {

			if ((ifr[i]).ifr_addr.sa_family != AF_INET) {
				continue;
			}
			if (!strncmp((ifr[i]).ifr_name, eth_name, 3)) {

				strcpy(ifr_index.ifr_name, (ifr[i]).ifr_name);
				memset(&if_ip, 0, sizeof(if_ip));
				strncpy(if_ip.ifr_name, (ifr[i]).ifr_name, IFNAMSIZ); //giving name of Interface
				if ((ioctl(sd, SIOCGIFADDR, &if_ip)) < 0)
					printf("error in mac ioctl reading\n"); //getting MAC Address
				memset(&ipaddr, 0, sizeof(ipaddr));
				ipaddr.sin_addr =
						(((struct sockaddr_in *) &(if_ip.ifr_addr))->sin_addr);
				if (!strncmp(inet_ntoa(ipaddr.sin_addr), ip_address, 2)) {
					if (ioctl(sd, SIOCGIFINDEX, &ifr_index) == -1) {
						perror("SIOCGIFINDEX");
						exit(1);
					}
					*hw_index = ifr_index.ifr_ifindex;
					strcpy(ethname, (ifr[i]).ifr_name);
					break;
				}
			}

		}
	}
	close(sd);
}
void file_creation(char *fname) {
	if ((filesize % DATA_LEN) != 0) {
		packets_num = filesize / DATA_LEN + 1;
		//last_packet_size = filesize%DATA_LEN;
	} else {
		packets_num = filesize / DATA_LEN;
		//last_packet_size = DATA_LEN;
	}
	track_packets = (int *) calloc(packets_num + 10, sizeof(int));
	recv_file_fd = open(fname, O_RDWR | O_CREAT | O_TRUNC, 0x0777);
	if (lseek(recv_file_fd, filesize - 1, SEEK_SET) == -1) {
		perror("lseek error");
		exit(1);
	}
	if (write(recv_file_fd, "", 1) != 1) {
		perror("write error");
		exit(1);
	}
	if (lseek(recv_file_fd, 0, SEEK_SET) == -1) {
		perror("error in seek:");
		exit(1);
	}
	if (fstat(recv_file_fd, &recv_statbuf) < 0) {
		perror("error in fstat:");
		exit(1);
	}
	recv_memmap = mmap(0, recv_statbuf.st_size, PROT_WRITE, MAP_SHARED,
			recv_file_fd, 0);
	recv_offset = recv_memmap;
	if (recv_memmap == MAP_FAILED) {
		perror("MMAP FAILED");
		exit(1);
	}
}

void process_packet(int header, const u_char *packet, char *argv) {
	ipheader* rth = (ipheader*) (packet + sizeof(struct ethhdr));
	u_char *packetIn = (u_char *) packet;
	char err[128];
	int size = 1500;
	int ret = 0, hdrlen, payload_size = 0;
	if (rth->src_addr == my_addr) {
		return;
	}
	if (rth->dest_addr == my_addr) {
		hdrlen = sizeof(ipheader) + sizeof(struct ethhdr);
		if (rth->dest_id != atoi(argv)) {
			//fprintf(stderr, "Requesting port %d doesnot match my port %d\n",rth->dest_id, port);
			return;
		}
		dest_addr = rth->src_addr;
		dest_id = rth->src_id;
		src_id = rth->dest_id;
		if (updateTrackPacketsArray(rth->seq_num)) {
			track_packets[rth->seq_num] = 1;
			if ((rth->seq_num) > last_index)
				last_index = rth->seq_num;
			payload_size = size - hdrlen;
			write_re_to_file(packetIn + hdrlen, payload_size, rth->seq_num);
		}
		if (last_index >= 0.7 * packets_num) {
			//usleep(10000);
			startCallback = 1;
		}
	}
}
int updateTrackPacketsArray(int seq_num) {
	pthread_mutex_lock(&m);
	if (seq_num > 0 && seq_num <= packets_num) {
		if (track_packets[seq_num] == 0) {
			track_packets[seq_num] = 1;
			pthread_mutex_unlock(&m);
			return 1;
		} else {
			pthread_mutex_unlock(&m);
			return 0;
		}

	}
	pthread_mutex_unlock(&m);
	return 0;
}
void write_re_to_file(u_char * payload, int payload_size, int seqNum) {
	pthread_mutex_lock(&m);
	if (seqNum == packets_num)
		payload_size = rem_data;
	memcpy(recv_offset + (seqNum - 1) * DATA_LEN, payload, payload_size);
	total++;
	//printf("Total value is %d\n", total);
	pthread_mutex_unlock(&m);
	if (total == packets_num) {
		fprintf(stdout, "FILE WRITING DONE\n");
		close(recv_file_fd);
	}
}
void* handleFailures(void *argv) {
	char err[128];
	//start_index=0;
	int i;
	while (1) {
		if (startCallback) {
			if (check_all_pckt_rcvd() == 1) {
				//printf("Reached Lastpacket %d and packets num %d \n", total,
				//packets_num);
				printf("SEND END\n");
				send_end(argv);
				close(sockfd_recv);
				break;
			}
			for (i = 1; i <=packets_num; i++){
				//printf("Packet with seq[%d], index =%d\n", track_packets[i], i);
				pthread_mutex_lock(&m);
				if(total>=packets_num){
					break;
				}
				if (track_packets[i] == 0) {
					if (i == (packets_num - 1)) {
						send_nack_to_client(i);
						//printf("Request Sequence Number %d \n", i);
						if (total >= (packets_num)) {
							pthread_mutex_unlock(&m);
							break;
						}
						i = 0;
					} else {
						/*if (total >= (packets_num-1)) {
							pthread_mutex_unlock(&m);
							break;
						}*/
						send_nack_to_client(i);
						//printf("Request Sequence Number %d \n", i);


						//i = i + 1;
					}
					pthread_mutex_unlock(&m);
				}
				pthread_mutex_unlock(&m);
				usleep(100);
			}
		}
		//pthread_mutex_unlock(&m);
	}
}
int check_all_pckt_rcvd() {
	if (total >= packets_num)
		return 1;
	else
		return 0;
}
void send_end() {
	int n, ret, i;
	u_char packet[DATA_LEN];
	int seqNum = -1;
	for(i=0;i<5;i++){
		generate_route_on_resend_packet(packet, 70, seqNum);
		usleep(100);
	}

}
void generate_route_on_resend_packet(u_char* packetOut, int size, int seqNum) {
	u_int8_t dest_port;
	int i, hdrlen, payload_size;
	struct ethhdr *eh_s = (struct ethhdr*) packetOut;
	ipheader* rth = (ipheader*) (packetOut + sizeof(struct ethhdr));
	struct sockaddr_ll socket_address;
	char *data_segment;
	hdrlen = sizeof(ipheader) + sizeof(struct ethhdr);
	payload_size = size - hdrlen;

	/*construct the IP header*/
	rth->dest_addr = dest_addr;
	rth->src_addr = my_addr;
	rth->ttl = 64;
	rth->src_id = src_id;
	rth->dest_id = dest_id;
	rth->seq_num = (seqNum & 0xffffffff);
	for (i = hdrlen; i < size; i++) {
		packetOut[i] = (u_char)(0x00000000 & 0x000000ff);
	}

	eh_s = (struct ethhdr*) packetOut;
	data_segment =
			(char*) (packetOut + sizeof(struct ethhdr) + sizeof(ipheader));
	/*construct the ether head*/
	for (i = 0; i < 6; i++) {
		eh_s->h_dest[i] = my_eth->h_dest[i];
		eh_s->h_source[i] = my_eth->h_source[i];
	}
	eh_s->h_proto = htons(ETH_P_IP);
	/*fill the data*/
	/* Index of the network device */
	memset(&socket_address, '\0', sizeof(socket_address));
	socket_address.sll_ifindex = hw_name;
	/* Address length*/
	socket_address.sll_halen = ETH_ALEN;
	/* Destination MAC */
	for (i = 0; i < 6; i++)
		socket_address.sll_addr[i] = eh_s->h_source[i];
	/* Send packet */
	rth->check = htons(ip_checksum(packetOut));
	/*for(i=0;i<4;i++)
	 {*/
	//for (i = 0; i < 3; i++) {
	if (sendto(sockfd_send, packetOut, BUF_SIZ, 0,
			(struct sockaddr*) &socket_address, sizeof(struct sockaddr_ll))
			< 0) {
		perror("sendto");
	} else {
		//printf("NAK sent for seq num: %d\n", rth->seq_num);
	}
	/*usleep(100);
		if (track_packets[rth->seq_num] == 1) {
			break;
		}*/
	//}
}
void send_nack_to_client(int seqNum) {
	int n, ret;
	u_char packet[DATA_LEN];
	generate_route_on_resend_packet(packet, 70, seqNum);
}
int main(int argc, char *argv[]) {

	struct ifreq if_mac;
	int index = 0;
	uint8_t buffer[BUF_SIZ];	//arp request buffer
	uint8_t actual_buffer[BUF_SIZ];	//actual data transfer buffer
	struct ethhdr *eh_s;

	struct sockaddr_ll socket_address, bind_addr;
	struct arp_header *arp_req;
	ipheader *ip, *iph;
	struct sockaddr saddr;
	struct sockaddr_in dest;
	unsigned int saddr_len = sizeof(saddr);
	unsigned short received_checksum;
	unsigned char *data_segment;
	time_t t;
	int flag = 0;
	long int start_time, stop_time;
	double throughput;
	int header_length;

	char buf[100];
	memset(buf, '\0', 100);
	my_eth = (struct ethhdr*) buf;

	/*Init declarations*/

	packets_num = 0;

	char file_name[strlen(argv[4])];
	strcpy(file_name, argv[4]);
	char arg1_port[strlen(argv[2])];
	strcpy(arg1_port, argv[2]);

	/* Get interface name*/
	char eth_name[10];
	memset(eth_name, '\0', 10);
	interface_index(&hw_name, eth_name);

	/* Open RAW socket to send on */
	if ((sockfd_recv = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_IP))) < 0) {
		perror("socket");
	}
	if ((sockfd_send = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_IP))) < 0) {
		perror("socket");
	}

	/*bind the socket to the interface*/
	bind_addr.sll_family = AF_PACKET;
	bind_addr.sll_ifindex = hw_name;
	bind_addr.sll_protocol = htons(ETH_P_IP);

	if ((bind(sockfd_recv, (struct sockaddr *) &bind_addr, sizeof(bind_addr)))
			== -1) {
		perror("Error binding raw socket to interface\n");
		exit(1);
	}
	if ((bind(sockfd_send, (struct sockaddr *) &bind_addr, sizeof(bind_addr)))
			== -1) {
		perror("Error binding raw socket to interface\n");
		exit(1);
	}

	/* Get the MAC address */
	memset(&if_mac, 0, sizeof(struct ifreq));
	strncpy(if_mac.ifr_name, eth_name, 4);
	if (ioctl(sockfd_recv, SIOCGIFHWADDR, &if_mac) < 0)
		perror("SIOCGIFHWADDR");
	int i = 0, buflen = -1;
	for (i = 0; i < 6; i++) {
		my_eth->h_source[i] = (unsigned char) (if_mac.ifr_hwaddr.sa_data[i]);
	}
#if 0
	int fd_arp;
	fd_arp = open("arp.txt", O_RDONLY);
	for (i = 0; i < 6; i++) {
		if (read(fd_arp, &my_eth->h_dest[i], 1) < 0) {
			printf("ERROR: ARP file read error\n");
			exit(1);
		}

	}

	if (lseek(fd_arp, -1, SEEK_END) < 0) {
		perror("Lseek Error");
		exit(1);
	}

	if (read(fd_arp, &my_addr, 1) < 0) {
		printf("ERROR: ARP file read error\n");
		exit(1);
	}
	close(fd_arp);
#endif


	/*node1 mac*/
	/*00:14:22:23:8b:75*/
	/*
	my_eth->h_dest[0] = 0x00;
	my_eth->h_dest[1] = 0x14;
	my_eth->h_dest[2] = 0x22;
	my_eth->h_dest[3] = 0x23;
	my_eth->h_dest[4] = 0x8b;
	my_eth->h_dest[5] = 0x75;
	 */

	char *mac_ptr = (char*)malloc((strlen(argv[3])*sizeof(char))+1);
	memset(mac_ptr,'\0',strlen(mac_ptr));
	strcpy(mac_ptr,argv[3]);
	char *byte_ptr = mac_ptr;
	int z=0,num;
	while(*mac_ptr!='\0')
	{
		if(*mac_ptr == ':')
		{
			*mac_ptr++ = '\0';

		num = (int)strtoul(byte_ptr, NULL, 16);       // number base 16
		my_eth->h_dest[z] = num;
		z++;
		byte_ptr = mac_ptr;
		}
		else
			mac_ptr++;
	}
	num = (int)strtoul(byte_ptr, NULL, 16);       // number base 16
	my_eth->h_dest[z] = num;


	my_addr = atoi(argv[1]);


#if 0
	while(1)
	{
		/*Construct the Ethernet header*/
		memset(buffer, 0, BUF_SIZ);
		/*receive packets */
		buflen=recvfrom(sockfd_recv,buffer,1500,0,(struct sockaddr *)&saddr,(socklen_t *)&saddr_len);
		if(buflen<0)
		{
			printf("error in reading recvfrom function\n");
			exit(1);
		}
		eh_s = (struct ethhdr *) buffer;
		arp_req = (struct arp_header *)(buffer+sizeof(struct ethhdr));
		if(arp_req->arp_code == htons(ARP_REQUEST))
		{
			for(i=0;i<6;i++)
				my_eth->h_dest[i] = eh_s->h_source[i];
			for(i =0;i<6;i++)
			{
				eh_s->h_dest[i] = eh_s->h_source[i];
				eh_s->h_source[i] = my_eth->h_source[i];
			}
			eh_s->h_proto = htons(ETH_P_IP);
			for(index=0;index<6;index++)
			{
				arp_req->target_mac[index] = eh_s->h_dest[index];
				arp_req->send_mac[index] = my_eth->h_source[index];
			}
			arp_req->arp_code = htons(ARP_REPLY);
			arp_req->target_ip[1]=arp_req->send_ip[1];
			arp_req->send_ip[1]=atoi(argv[1]); /* Index of the network device */
			memset(&socket_address,'\0',sizeof(socket_address));
			socket_address.sll_ifindex = hw_name;
			/* Address length*/
			socket_address.sll_halen = ETH_ALEN;
			/* Destination MAC */
			for(i=0;i<6;i++)
				socket_address.sll_addr[i] = eh_s->h_source[i];
			/* Send packet */
			if (sendto(sockfd_send, buffer, BUF_SIZ, 0, (struct sockaddr*)&socket_address, sizeof(struct sockaddr_ll)) < 0)
				perror("sendto");
			else
				printf("ARP response sent\n");
			break;
		}
	}
#endif

	/*Start of File_size*/
	char *Payload;

	while (1) {
		buflen = recvfrom(sockfd_recv, buffer, BUF_SIZ, 0,
				(struct sockaddr *) &saddr, (socklen_t *) &saddr_len);
		if (buflen < 0) {
			printf("error in reading recvfrom function\n");
			exit(1);
		}
		ip = (ipheader*) (buffer + sizeof(struct ethhdr));

		if (ip->dest_addr != my_addr || ip->dest_id != atoi(arg1_port))
			continue;
		else
			break;
	}
	start_time = Current_time();
	printf("Start time is %ld\n",start_time);
	printf("File reception Started...Please Wait\n");
	Payload = (char*) (buffer + sizeof(ipheader) + sizeof(struct ethhdr));
	filesize = atoi(Payload);
	// File creation
	file_creation(file_name);
	/*End of receival of file size*/

	/*Actual Packet Receival*/
	i = 0;
	header_length = sizeof(ipheader) + sizeof(struct ethhdr);
	if ((pthread_create(&nack_thread, NULL, handleFailures, (void*) (arg1_port)))
			!= 0) {
		fprintf(stderr, "pthread_create[0] \n");
		pthread_exit(0);
		exit(1);
	}
	rem_data =
			(filesize % DATA_LEN == 0) ?
					DATA_LEN : (filesize - ((filesize / DATA_LEN) * DATA_LEN));
	while (1) {
		memset(actual_buffer, 0, BUF_SIZ);
		buflen = recvfrom(sockfd_recv, actual_buffer, BUF_SIZ, 0,
				(struct sockaddr *) &saddr, (socklen_t *) &saddr_len);
		iph = (ipheader*) (actual_buffer + sizeof(struct ethhdr));
		//printf("Packet %d recived\n", iph->seq_num);
		if (iph->seq_num == 0)
			continue;
		if (buflen < 0) {
			printf("error in reading recvfrom function\n");
			exit(1);
		}
		//pthread_mutex_lock(&m);
		process_packet(header_length, actual_buffer, arg1_port);
		//check if my last packet has been received
		if (total == packets_num) {
			printf("Done");
			//pthread_mutex_unlock(&m);
			break;
		}
		//pthread_mutex_unlock(&m);
	}
	stop_time=Current_time();
	printf("Stop time is %ld\n",stop_time);
	printf("Execution time is %ld\n",(stop_time-start_time));
	throughput = ((double)(filesize*8)/(double)(stop_time-start_time));
	printf("Throughput is :%0.2f Mbps\n",throughput/(1000000.0));
	pthread_join(nack_thread, 0);
	return 0;
}
