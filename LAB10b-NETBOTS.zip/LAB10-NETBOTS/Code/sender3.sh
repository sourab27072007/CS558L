#!/bin/sh
./sender 21 9 10 data32.bin 00:11:43:d6:d6:36 31 5 &
./sender 11 11 12 data31.bin 00:04:23:ae:cc:32 31 6&
wait
echo "nodeC sent all file segments"
echo "check sum for data31.bin"
md5sum data31.bin
echo "check sum for data32.bin"
md5sum data32.bin
