#!/bin/sh
a=$(date +"%s")
#echo "start time is $a"
./receiver 21 10 00:0e:0c:68:a8:57 rdata32.bin &
./receiver 21 2 00:04:23:ae:cc:32 rdata12.bin &
wait
b=$(date +"%s")
#echo "end time is $b"
diff=$((b-a))
#echo "execution time is $diff"
#printf "throughput is %d" $((8*2*10485760/(diff*1000000)))
#echo "Mbps"
echo "node B received all file segments"
echo "checksum for rdata32.bin is"
md5sum rdata32.bin
echo "checksum for rdata12.bin is"
md5sum rdata12.bin
