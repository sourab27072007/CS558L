#!/bin/sh
./sender 21 1 2 data12.bin 00:11:43:d6:d6:36 11 1 &
./sender 31 3 4 data13.bin 00:0e:0c:68:a8:57 11 3 &
wait
echo "node 1 sent all file segments"
echo "checksum for data12.bin"
md5sum data12.bin
echo "checksum for data13.bin"
md5sum data13.bin

