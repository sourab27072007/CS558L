#!/bin/sh
a=$(date +"%s")
#echo "start time is $a"
./receiver 31 4 00:04:23:ae:cc:32 rdata13.bin &
./receiver 31 8 00:15:17:5d:16:b4 rdata23.bin &
wait
b=$(date +"%s")
#echo "end time is $b"
diff=$((b-a))
#echo "execution time is $diff"
#printf "throughput is %d" $((8*2*10485760/(diff*1000000)))
#echo "Mbps"
echo "nodeC received all file segments"
echo "check sum for rdata13.bin"
md5sum rdata13.bin
echo "check sum for rdata23.bin"
md5sum rdata23.bin
