

#include <arpa/inet.h>
#include <linux/if_packet.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <net/if.h>
#include <netinet/ether.h>
#include <netinet/ip.h>
#include <netinet/in.h>
#include <unistd.h>
#include <time.h>
#include <sys/time.h>
#include "header.h"
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <pthread.h>

int hw_name;
struct ethhdr *my_eth;
u_int16_t source_ip, dest_ip;
u_int8_t SRC_ID, DEST_ID;
char *data_ptr = NULL;
int sockfd_send;
pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;

static u_short calc_ip_checksum(const u_char* Buffer) {
	struct l3_header *iph = (struct l3_header*) (Buffer + sizeof(struct ethhdr));
	unsigned int sum = 0;

	iph->dummy = 0;
	/*    printf("\n ttl inside fn %d",iph->ttl);*/
	sum += (((u_short) iph->ttl) << 8) | (u_short) iph->dummy;
	sum += ntohs((iph->src_addr) & 0xff);
	sum += ntohs((iph->dest_addr) & 0xff);

	int chk = (((u_short)(sum >> 16)) & 0xf) + ((u_short)(sum) & 0xffff);
	return ~((u_short) chk);

}

static
void *start_lost_pkt_retrnsm(void * arg) {

	unsigned char buff[BUFF_SIZE], send_buff[BUFF_SIZE];
	int i;
	unsigned short seq_num = 0;
	int buflen = 0;
	struct timespec time_to_sleep, tim2;
	time_to_sleep.tv_sec = 0;
	time_to_sleep.tv_nsec = 10L;
	int sockfd_recv;
	struct sockaddr_ll bind_addr, socket_address;
	struct sockaddr saddr;
	unsigned int saddr_len = sizeof(saddr);
	struct ethhdr *l2_hd_send;
	struct l3_header *l3_hd, *l3_hd_send;
	unsigned short received_checksum;
	unsigned char *data;

	if ((sockfd_recv = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_IP))) < 0) {
		perror("socket");
	}

	/*bind the socket to the interface*/
	bind_addr.sll_family = AF_PACKET;
	bind_addr.sll_ifindex = hw_name;
	bind_addr.sll_protocol = htons(ETH_P_IP);

	if ((bind(sockfd_recv, (struct sockaddr *) &bind_addr, sizeof(bind_addr)))
			== -1) {
		perror("Error binding raw socket to interface\n");
		exit(1);
	}

	memset(send_buff, '\0', BUFF_SIZE);
	//memset(buff,'\0',BUFF_SIZE);
	l2_hd_send = (struct ethhdr*) send_buff;
	l3_hd_send = (struct l3_header*) (send_buff + sizeof(struct ethhdr));

	/*construct the ether head*/
	for (i = 0; i < 6; i++) {
		l2_hd_send->h_dest[i] = my_eth->h_dest[i];
		l2_hd_send->h_source[i] = my_eth->h_source[i];
	}
	l2_hd_send->h_proto = htons(ETH_P_IP);

	/*construct the IP header*/
	l3_hd_send->src_addr = source_ip;
	l3_hd_send->dest_addr = dest_ip;
	l3_hd_send->dest_id = DEST_ID;
	l3_hd_send->src_id = SRC_ID;
	l3_hd_send->ttl = 64;
	data = send_buff + sizeof(struct ethhdr) + sizeof(struct l3_header);

	/* Index of the network device */
	memset(&socket_address, '\0', sizeof(socket_address));
	socket_address.sll_ifindex = hw_name;
	/* Address length*/
	socket_address.sll_halen = ETH_ALEN;

	/* Destination MAC */
	for (i = 0; i < 6; i++)
		socket_address.sll_addr[i] = my_eth->h_source[i];

	while (1) {
		memset(buff, '\0', BUFF_SIZE);
		buflen = recvfrom(sockfd_recv, buff, BUFF_SIZE, 0,
				(struct sockaddr *) &saddr, (socklen_t *) &saddr_len);
		if (buflen < 0) {
			printf("error in reading recvfrom function\n");
			exit(1);
		}

		l3_hd = (struct l3_header*) (buff + sizeof(struct ethhdr));
		//printf("Retransmission happening with seq_no %d \n", l3_hd->seq_num);
		received_checksum = htons(calc_ip_checksum(buff));
		if (received_checksum != l3_hd->check) {
			continue;
		}

		if (l3_hd->dest_addr != source_ip || l3_hd->dest_id != SRC_ID)
			continue;

		seq_num = l3_hd->seq_num;

		/*this is special seq no indicating that server has
		 received the file and server is about to close the connection*/
		if (seq_num == -1)
			break;

		memset(data, '\0', DATA_LEN);
		/*l3_hd_send->seq_num = seq_num;
		 l3_hd_send->src_addr=l3_hd->dest_addr;
		 l3_hd_send->dest_addr=l3_hd->src_addr;
		 l3_hd_send->dest_id = DEST_ID;
		 l3_hd_send->src_id = SRC_ID;
		 l3_hd_send->ttl = 64;*/
		/*l3_hd_send->src_addr = source_ip;
		l3_hd_send->dest_addr = dest_ip;
		l3_hd_send->dest_id = DEST_ID;
		l3_hd_send->src_id = SRC_ID;
		l3_hd_send->ttl = 64;*/
		l3_hd_send->seq_num = seq_num;
		l3_hd_send->check = htons(calc_ip_checksum(send_buff));

		memcpy(data, data_ptr + (seq_num - 1) * DATA_LEN, DATA_LEN);
		//printf("Retransmission happening with seq_no %d \n", seq_num);
		//printf("Source Ip=%d and Destination Ip=%d \n", l3_hd_send->src_addr,
		//l3_hd_send->dest_addr);
		//printf("Source Ethernet=%02X:%02X:%02X:%02X:%02X:%02X and dest addr %02X:%02X:%02X:%02X:%02X:%02X \n",(unsigned char)l2_hd_send->h_dest[0],(unsigned char)l2_hd_send->h_dest[1],(unsigned char)l2_hd_send->h_dest[2],(unsigned char)l2_hd_send->h_dest[3],(unsigned char)l2_hd_send->h_dest[4],(unsigned char)l2_hd_send->h_dest[5],
		//(unsigned char)l2_hd_send->h_source[0],(unsigned char)l2_hd_send->h_source[1],(unsigned char)l2_hd_send->h_source[2],(unsigned char)l2_hd_send->h_source[3],(unsigned char)l2_hd_send->h_source[4],(unsigned char)l2_hd_send->h_source[5]);
		//for (i = 0; i < 3; i++) {
		pthread_mutex_lock(&m);
		if (sendto(sockfd_send, send_buff, BUFF_SIZE, 0,
				(struct sockaddr*) &socket_address,
				sizeof(struct sockaddr_ll)) < 0){
			pthread_mutex_unlock(&m);
			perror("sendto");
		}
		pthread_mutex_unlock(&m);
		//}
		//usleep(10);
		//nanosleep(&time_to_sleep , &tim2);
	}
	return 0;
}

void get_index_of_interface(int *hw_index, char*ethname) {
	struct ifconf ifc;
	struct ifreq ifr[10], if_ip;
	struct ifreq ifr_index;
	int sd, ifc_num, i;
	struct sockaddr_in ipaddr;
	char *eth_name = "eth";
	char *ip_address = "10";

	sd = socket(PF_INET, SOCK_DGRAM, 0);
	if (sd > 0) {
		ifc.ifc_len = sizeof(ifr);
		ifc.ifc_req = ifr;

		if (ioctl(sd, SIOCGIFCONF, (char*) &ifc) < 0) {
			printf("ioctl lookup failed\n");
			exit(0);
		}
		ifc_num = ifc.ifc_len / sizeof(struct ifreq);

		for (i = 0; i < ifc_num; i++) {

			if ((ifr[i]).ifr_addr.sa_family != AF_INET) {
				continue;
			}
			if (!strncmp((ifr[i]).ifr_name, eth_name, 3)) {

				strcpy(ifr_index.ifr_name, (ifr[i]).ifr_name);
				memset(&if_ip, 0, sizeof(if_ip));
				strncpy(if_ip.ifr_name, (ifr[i]).ifr_name, IFNAMSIZ); //giving name of Interface
				if ((ioctl(sd, SIOCGIFADDR, &if_ip)) < 0)
					printf("error in mac ioctl reading\n"); //getting MAC Address
				memset(&ipaddr, 0, sizeof(ipaddr));
				ipaddr.sin_addr =
						(((struct sockaddr_in *) &(if_ip.ifr_addr))->sin_addr);
				if (!strncmp(inet_ntoa(ipaddr.sin_addr), ip_address, 2)) {
					if (ioctl(sd, SIOCGIFINDEX, &ifr_index) == -1) {
						perror("SIOCGIFINDEX");
						exit(1);
					}
					*hw_index = ifr_index.ifr_ifindex;
					strcpy(ethname, (ifr[i]).ifr_name);
					break;
				}
			}

		}
	}
	close(sd);
}

/*
 static
 double GetCurrentTime()
 {
 struct timeval t;
 if(gettimeofday(&t, NULL) == -1)
 {
 perror("time");
 exit(1);
 }
 return((t.tv_sec)*1000.0 + (t.tv_usec)/1000.0);

 }
 */

int main(int argc, char *argv[]) {
	int fd_arp, fd, last_seq_no, seq_no = 0;
	struct ifreq if_mac;
	uint8_t buffer[BUFF_SIZE];
	struct ethhdr *eh_s;
	char *buf = (char*) malloc(sizeof(char) * 100);
	memset(buf, '\0', 100);
	my_eth = (struct ethhdr*) buf;
	int delay_param = atoi(argv[7]);

	struct sockaddr_ll socket_address, bind_addr;
	unsigned char *data_segment;
	struct l3_header *ip_hd;
	//time_t t;
	//int flag = 0;
	//double start_time,stop_time,throughput;
	struct stat stat_buffer;
	pthread_t thread_id;

	/* Get interface name*/
	char eth_name[10];
	memset(eth_name, '\0', 10);
	get_index_of_interface(&hw_name, eth_name);

	/* Open RAW socket to send on */
	if ((sockfd_send = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_IP))) < 0) {
		perror("socket");
	}

	/*bind the socket to the interface*/
	bind_addr.sll_family = AF_PACKET;
	bind_addr.sll_ifindex = hw_name;
	bind_addr.sll_protocol = htons(ETH_P_IP);

	if ((bind(sockfd_send, (struct sockaddr *) &bind_addr, sizeof(bind_addr)))
			== -1) {
		perror("Error binding raw socket to interface\n");
		exit(1);
	}

	/* Get the MAC address */
	memset(&if_mac, 0, sizeof(struct ifreq));
	strncpy(if_mac.ifr_name, eth_name, 4);
	if (ioctl(sockfd_send, SIOCGIFHWADDR, &if_mac) < 0)
		perror("SIOCGIFHWADDR");

	int i = 0;
	for (i = 0; i < 6; i++) {
		my_eth->h_source[i] = (unsigned char) (if_mac.ifr_hwaddr.sa_data[i]);
	}

#if 0
	fd_arp = open("arp.txt", O_RDONLY);
	for (i = 0; i < 6; i++) {
		if (read(fd_arp, &my_eth->h_dest[i], 1) < 0) {
			printf("ERROR: ARP file read error\n");
			exit(1);
		}

	}

	if (lseek(fd_arp, -1, SEEK_END) < 0) {
		perror("Lseek Error");
		exit(1);
	}

	if (read(fd_arp, &source_ip, 1) < 0) {
		printf("ERROR: ARP file read error\n");
		exit(1);
	}
	close(fd_arp);
#endif


	/*node2 mac*/
	/*00:04:23:9e:f5:88*/

	/*
	my_eth->h_dest[0] = 0x00;
	my_eth->h_dest[1] = 0x04;
	my_eth->h_dest[2] = 0x23;
	my_eth->h_dest[3] = 0x9e;
	my_eth->h_dest[4] = 0xf5;
	my_eth->h_dest[5] = 0x88;
	 */

	char *mac_ptr = (char*)malloc((strlen(argv[5])*sizeof(char))+1);
	memset(mac_ptr,'\0',strlen(mac_ptr));
	strcpy(mac_ptr,argv[5]);
	//mac_ptr[strlen(mac_ptr)-1] = '\0';
	char *byte_ptr = mac_ptr;
	int z=0,num;
	while(*mac_ptr!='\0')
	{
		if(*mac_ptr == ':')
		{
			*mac_ptr++ = '\0';

		num = (int)strtoul(byte_ptr, NULL, 16);       // number base 16
		my_eth->h_dest[z] = num;
		z++;
		byte_ptr = mac_ptr;
		}
		else
			mac_ptr++;
	}
	num = (int)strtoul(byte_ptr, NULL, 16);       // number base 16
	my_eth->h_dest[z] = num;
	source_ip = atoi(argv[6]);


	if ((fd = open(argv[4], O_RDONLY)) < 0)
		perror("error opening file:");

	if (fstat(fd, &stat_buffer) < 0)
		perror("fstat error");
	if ((data_ptr = mmap(0, stat_buffer.st_size, PROT_READ, MAP_SHARED, fd, 0))
			== (caddr_t) - 1)
		perror("mmap error");

	/*find last seq number and populate it*/
	if ((int) stat_buffer.st_size % DATA_LEN == 0) {
		last_seq_no = (int) stat_buffer.st_size / DATA_LEN;
	} else {
		last_seq_no = (int) stat_buffer.st_size / DATA_LEN + 1;
	}
	SRC_ID = atoi(argv[2]);
	DEST_ID = atoi(argv[3]);
	dest_ip = atoi(argv[1]);

	memset(buffer, '\0', BUFF_SIZE);
	eh_s = (struct ethhdr*) buffer;
	ip_hd = (struct l3_header*) (buffer + sizeof(struct ethhdr));
	data_segment = buffer + sizeof(struct ethhdr) + sizeof(struct l3_header);

	/*fill the data*/
	sprintf((char*) data_segment, "%d", (int) stat_buffer.st_size);

	/*construct the ether head*/
	for (i = 0; i < 6; i++) {
		eh_s->h_dest[i] = my_eth->h_dest[i];
		eh_s->h_source[i] = my_eth->h_source[i];
	}
	eh_s->h_proto = htons(ETH_P_IP);

	/*construct the IP header*/
	ip_hd->src_addr = source_ip;
	ip_hd->dest_addr = dest_ip;
	ip_hd->dest_id = DEST_ID;
	ip_hd->src_id = SRC_ID;
	;
	ip_hd->ttl = 64;
	ip_hd->seq_num = 0;
	ip_hd->check = htons(calc_ip_checksum(buffer));

	/* Index of the network device */
	memset(&socket_address, '\0', sizeof(socket_address));
	socket_address.sll_ifindex = hw_name;
	/* Address length*/
	socket_address.sll_halen = ETH_ALEN;

	/* Destination MAC */
	for (i = 0; i < 6; i++)
		socket_address.sll_addr[i] = eh_s->h_source[i];

	/* Send packet */
	for (i = 0; i < 5; i++) {
		if (sendto(sockfd_send, buffer, BUFF_SIZE, 0,
				(struct sockaddr*) &socket_address, sizeof(struct sockaddr_ll))
				< 0)
			perror("sendto");

		usleep(5*(1.0/(float)delay_param));
	}
	pthread_create(&thread_id, 0, start_lost_pkt_retrnsm, NULL);
	printf("File is being transferred to server,please wait...\n");

	seq_no = 0;
	int file_size = (int) stat_buffer.st_size;
	int rem_data =
			(file_size % DATA_LEN == 0) ?
					DATA_LEN :
					(file_size - ((file_size / DATA_LEN) * DATA_LEN));
	while (1) {
		seq_no++;
		if (seq_no == last_seq_no)
			break;

		ip_hd->seq_num = seq_no;
		memcpy(data_segment, data_ptr + (seq_no - 1) * DATA_LEN, DATA_LEN);
		//nanosleep(&time_to_sleep , &tim2);
		usleep(100*(1.0/(float)delay_param));
		pthread_mutex_lock(&m);
		if (sendto(sockfd_send, buffer, BUFF_SIZE, 0,
				(struct sockaddr*) &socket_address, sizeof(struct sockaddr_ll))
				< 0){
			perror("sendto");
			pthread_mutex_unlock(&m);
		}
		pthread_mutex_unlock(&m);
		memset(data_segment, '\0', DATA_LEN);
		//printf("Sent Packet: %d\n", seq_no);
	}
	ip_hd->seq_num = seq_no;

	//if((int)stat_buffer.st_size % DATA_LEN==0)
	memcpy(data_segment, data_ptr + (last_seq_no - 1) * DATA_LEN, rem_data);
	//else
	//memcpy(data_segment,data_ptr+(last_seq_no-1)*DATA_LEN,file_size%rem_data);

	for (i = 0; i < 10; i++) {
		pthread_mutex_lock(&m);
		if (sendto(sockfd_send, buffer, 30 + rem_data, 0,
				(struct sockaddr*) &socket_address, sizeof(struct sockaddr_ll))
				< 0){
			perror("sendto");
			pthread_mutex_unlock(&m);
		}
		usleep(100*(1.0/(float)delay_param));
		pthread_mutex_unlock(&m);
	}
	pthread_join(thread_id, 0);
	munmap(data_ptr, stat_buffer.st_size);
	close(fd);
	printf("File transferred successfully\n");
	free(buf);
	return 0;
}
