1. Run script files on node 1,2,3.

Note: Set Mac add equal to that of 192.X.X.X
Add port to interfaces apart from 192.X.X.X
