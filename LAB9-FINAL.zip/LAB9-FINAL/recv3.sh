#!/bin/sh
a=$(date +"%s")
echo "start time is $a"
sudo ./receiver rca.bin 4 &
sudo ./receiver rcb.bin 8 &
wait
b=$(date +"%s")
echo "end time is $b"
diff=$((b-a))
echo "execution time is $diff"
printf "throughput is %d" $((8*2*10485760/(diff*1000000)))
echo "Mbps"
echo "nodeC received all file segments"
echo "check sum for rca.bin"
sudo md5sum rca.bin
echo "check sum for rcb.bin"
sudo md5sum rcb.bin
