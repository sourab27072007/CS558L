#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/time.h>
#include <pthread.h>
#include <asm/types.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>
#include <linux/if_arp.h>
#include <arpa/inet.h>
#include <arpa/inet.h>
#include <linux/if_packet.h>
#include <linux/udp.h>
#include <netinet/ip.h> 


#define INET6_ADDRSTRLEN 46
#define ETHER_TYPE	0x0800 //we need to read everything on this IP
#define PROTO_ARP 0x0806
#define ETH2_HEADER_LEN 14
#define HW_TYPE 1
#define PROTOCOL_TYPE 0x800
#define MAC_LENGTH 6
#define IPV4_LENGTH 2
#define ARP_REQUEST 0x01
#define ARP_REPLY 0x02
#define BUF_SIZE 1500
#define BUF_SIZ 1500


struct arp_header
{
	unsigned short opcode;
	unsigned char sender_mac[MAC_LENGTH];
	unsigned char sender_ip[IPV4_LENGTH];
	unsigned char target_mac[MAC_LENGTH];
	unsigned char target_ip[IPV4_LENGTH];
};

struct	ether_header {
	u_char	ether_dhost[MAC_LENGTH];
	u_char	ether_shost[MAC_LENGTH];
	u_short	ether_type;
};
struct ipheader
{
	u_int16_t daddr;
	u_int16_t saddr ;
	u_int16_t check;
	u_int8_t ttl;
	u_int8_t src_id;
	u_int8_t dest_id;
	u_int16_t data_check;
	int16_t seq_num;
	u_int8_t dummy;};


typedef struct interface_ip_mac
{
	char source_ip[IPV4_LENGTH];
	char my_ip[4];
	char source_mac[MAC_LENGTH];
	char eth_ifc[10];
	char target_ip[IPV4_LENGTH];
	unsigned char target_mac[MAC_LENGTH];
	int HW_index;
	struct interface_ip_mac *next;
}ifc_mac_ip;
ifc_mac_ip *interface=NULL;;
ifc_mac_ip *head=NULL;
ifc_mac_ip *default_gateway=NULL;
void *packet_sniffer(void * arg);
u_short calc_ip_checksum(const u_char* Buffer);
#define INT_TO_ADDR(_addr) \
		(_addr & 0xFF), \
		(_addr >> 8 & 0xFF), \
		(_addr >> 16 & 0xFF), \
		(_addr >> 24 & 0xFF)

char ETH_name[3][5];
int ifc_num;
char ip[98];
int ETH_name_index = 0;
pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;

int lookup_address(u_int16_t dest_ip,unsigned char source_mac[],unsigned char desination_mac[],int *iface_index);

void display_IP_table()
{
	ifc_mac_ip *interface=head;
	printf("SourceIP \t SourceMAC \t DestinationIP \t DestinationMAC \t Ethernet_Interface \n");
	while(interface!=NULL)
	{
		printf("%u.%u \t ",(unsigned int)interface->source_ip[0],(unsigned int)interface->source_ip[1]);

		printf("%02X:%02X:%02X:%02X:%02X:%02X \t ",(unsigned char)interface->source_mac[0],(unsigned char)interface->source_mac[1],(unsigned char)interface->source_mac[2],
				(unsigned char)interface->source_mac[3],(unsigned char)interface->source_mac[4],(unsigned char)interface->source_mac[5]);
		printf("%u.%u \t ",(unsigned int)interface->target_ip[0],(unsigned int)interface->target_ip[1]);

		printf("%02X:%02X:%02X:%02X:%02X:%02X \t ",(unsigned char)interface->target_mac[0],(unsigned char)interface->target_mac[1],(unsigned char)interface->target_mac[2],
				(unsigned char)interface->target_mac[3],(unsigned char)interface->target_mac[4],(unsigned char)interface->target_mac[5]);
		printf("%s \n",interface->eth_ifc);
		interface=interface->next;
	}
}

void get_all_interface()
{
	struct ifconf ifc;
	struct ifreq ifr[10];
	struct ifreq ifr_index[10];
	int sd, addr, bcast, mask, network, i,j;
	char addr1[50],addr2[50],addr3[50],addr4[50];

	memset(addr1,'\0',sizeof(addr1));
	memset(addr2,'\0',sizeof(addr2));
	memset(addr3,'\0',sizeof(addr3));
	memset(addr4,'\0',sizeof(addr4));
	int k=0;
	int index;

	/* Create a socket so we can use ioctl on the file
	 * descriptor to retrieve the interface info.
	 */

	sd = socket(PF_INET, SOCK_DGRAM, 0);
	if (sd > 0)
	{
		ifc.ifc_len = sizeof(ifr);
		ifc.ifc_ifcu.ifcu_buf = (caddr_t)ifr;

		if (ioctl(sd, SIOCGIFCONF, &ifc) == 0)
		{
			ifc_num = ifc.ifc_len / sizeof(struct ifreq);

			for (i = 0; i < ifc_num; i++)
			{

				if (ifr[i].ifr_addr.sa_family != AF_INET)
				{
					continue;
				}
				if( !strncmp(ifr[i].ifr_name,"eth",3))
				{

					strcpy(ETH_name[ETH_name_index],ifr[i].ifr_name);
					strcpy(ifr_index[i].ifr_name,ETH_name[ETH_name_index]);
					/* Retrieve the IP address, broadcast address, and subnet mask. */
					if (ioctl(sd, SIOCGIFADDR, &ifr[i]) == 0)
					{
						addr = ((struct sockaddr_in *)(&ifr[i].ifr_addr))->sin_addr.s_addr;

						sprintf(ip,"%d.%d.%d.%d", INT_TO_ADDR(addr));
						sprintf(addr1,"%d",(addr & 0xFF));
						if (strncmp(addr1,"192",3)!=0)
						{

							if(head==NULL)
							{
								interface=(ifc_mac_ip*)malloc(sizeof(ifc_mac_ip));
								head=interface;
							}
							else
							{
								interface->next=(ifc_mac_ip*)malloc(sizeof(ifc_mac_ip));
								interface=interface->next;
							}


							interface->my_ip[0]=atoi(addr1);

							sprintf(addr2,"%d",(addr >> 8 & 0xFF));
							interface->my_ip[1]=atoi(addr2);
							sprintf(addr3,"%d",(addr >> 16 & 0xFF));
							interface->my_ip[2]=atoi(addr3);
							sprintf(addr4,"%d",(addr >> 24 & 0xFF));
							interface->my_ip[3]=atoi(addr4);
							//printf(" The IPaddress: %s",ip);
							if((interface->my_ip[0]==0xa) &&(interface->my_ip[1]==0x1)&&(interface->my_ip[2]==0x0))
							{
								interface->source_ip[0]=00;
								interface->source_ip[1]=10;
							}
							else if((interface->my_ip[0]==0xa) &&(interface->my_ip[1]==0x1)&&(interface->my_ip[2]==0x1))
							{
								interface->source_ip[0]=00;
								interface->source_ip[1]=20;
							}
							if((interface->my_ip[0]==0xa) &&(interface->my_ip[1]==0x1)&&(interface->my_ip[2]==0x2))
							{
								interface->source_ip[0]=00;
								interface->source_ip[1]=30;
							}

						}
					}
					if (strncmp(addr1,"192",3)!=0)
					{
						if (ioctl(sd, SIOCGIFINDEX, &ifr_index[i]) == -1)
						{
							perror("SIOCGIFINDEX");
							exit(1);
						}
						interface->HW_index = ifr_index[i].ifr_ifindex;
						if(ioctl(sd, SIOCGIFHWADDR, &ifr[i]) == -1)
						{
							perror("SIOCGIFHWADDR");
							exit(1);
						}
						for (index = 0; index < 6; index++)
						{
							interface->source_mac[index]=(unsigned char)ifr[i].ifr_hwaddr.sa_data[index];
						}
						strcpy(interface->eth_ifc,ifr[i].ifr_name);


					}
					k++;
				}
			}
		}
	}
	close(sd);
}

void create_ARP_table()
{
	int sd,i,sd_recv;
	unsigned char buffer[BUF_SIZE];
	unsigned char target_ip[3][IPV4_LENGTH] = {{00,11,},{00,21},{00,31}};//configure this
	struct ifreq ifr;
	struct ethhdr *send_req = (struct ethhdr *)buffer;
	struct ethhdr *rcv_resp= (struct ethhdr *)buffer;
	struct arp_header *arp_req = (struct arp_header *)(buffer+ETH2_HEADER_LEN);
	struct arp_header *arp_resp = (struct arp_header *)(buffer+sizeof(struct ethhdr));
	struct sockaddr_ll socket_address;
	int index,ret,length=0,ifindex;
	ifc_mac_ip *interface=head;

	memset(buffer,0x00,60);
	/*open socket*///htons(ETH_P_ALL)
	if((sd = socket(AF_PACKET, SOCK_RAW,htons(ETH_P_IP)))<0)
	{	
		perror("socket():");
		exit(1);
	}
	if((sd_recv = socket(AF_PACKET, SOCK_RAW,htons(ETH_P_IP)))<0)
	{
		perror("socket():");
		exit(1);
	}

	while(interface!=NULL)
	{	 
		for (index = 0; index < MAC_LENGTH; index++)
		{
			send_req->h_dest[index] = (unsigned char)0xff;
			arp_req->target_mac[index] = (unsigned char)0x00;
			/* Filling the source  mac address in the header*/
			send_req->h_source[index] = (unsigned char)interface->source_mac[index];
			arp_req->sender_mac[index] = (unsigned char)interface->source_mac[index];
			socket_address .sll_addr[index] = (unsigned char)interface->source_mac[index];
		}

		/*prepare sockaddr_ll*/
		socket_address.sll_ifindex = interface->HW_index;//ifindex;
		socket_address.sll_halen = MAC_LENGTH;

		/* Setting protocol of the packet */
		send_req->h_proto = htons(ETH_P_IP);
		/* Creating ARP request */
		arp_req->opcode = htons(ARP_REQUEST);

		for(i=0;i<3;i++)
		{
			if ((interface->source_ip[1] &0xfe) ==(target_ip[i][1] &0xfe))
			{
				for(index=0;index<IPV4_LENGTH;index++)
				{
					arp_req->sender_ip[index]=(unsigned char)interface->source_ip[index];//(unsigned char)source_ip[row][index];
					arp_req->target_ip[index]=(unsigned char)target_ip[i][index];
				}
				break;
			}
		}
		if((ret = sendto(sd, buffer, BUF_SIZE, 0, (struct  sockaddr*)&socket_address, sizeof(socket_address)))<0)
		{
			perror("sendto():");
			exit(1);
		}

		/*printf("\n");*/
		memset(buffer,'\0',BUF_SIZ);
		struct sockaddr_ll bind_addr;
		bind_addr.sll_family = AF_PACKET;
		bind_addr.sll_ifindex = interface->HW_index;
		bind_addr.sll_protocol = htons(ETH_P_IP);

		if((bind(sd_recv, (struct sockaddr *)&bind_addr, sizeof(bind_addr)))== -1)
		{
			perror("Error binding raw socket to interface\n");
			exit(1);
		}

		while(1)
		{
			length = recvfrom(sd_recv, buffer, BUF_SIZE, 0, NULL, NULL);
			if (length == -1)
			{

				perror("recvfrom():");
				exit(1);
			}
			/*      printf("Arp sender ip:%d\n",arp_resp->sender_ip[1]);*/
			if((arp_resp->sender_ip[1] == 11)||(arp_resp->sender_ip[1] == 21)||(arp_resp->sender_ip[1] == 31))
			{
				/*printf(" ARP reply received and details are:\n");
          printf(" Sender IP :");*/
				for(index=0;index<IPV4_LENGTH;index++)
				{
					interface->target_ip[index]=arp_resp->sender_ip[index];
					/*            printf("%u.",(unsigned int)interface->target_ip[index]);*/
				}
				/*          printf("\n Sender MAC :");*/
				for(index=0;index<MAC_LENGTH;index++)
				{
					interface->target_mac[index]=arp_resp->sender_mac[index];
					/*printf(" %02X:",interface->target_mac[index]);*/
				}
				/*printf("\n Receiver  IP :");*/
				/*        for(index=0;index<IPV4_LENGTH;index++)
              printf(" %u.",arp_resp->target_ip[index]);

          printf("\n Receiver MAC :");
          for(index=0;index<MAC_LENGTH;index++)
              printf(" %02X:",arp_resp->target_mac[index]);
				 */
				/*printf("\n");*/

				break;
			}
		}
		//num_req--;
		//row++;
		interface=interface->next;
	}
	//nodes_not_on_rt3();
	close(sd);
}
void set_dafault_gateway()
{
	ifc_mac_ip *interface=head;

	while (interface!=NULL)
	{
		if ((interface->source_ip[0]== 0xa) && (interface->source_ip[1]== 0xa) &&(interface->source_ip[2]== 0x1) && (interface->source_ip[3]== 0x2))
		{
			default_gateway=interface;
		}

		interface=interface->next;
	}
}


void main()
{
	int i=0,inf_count=0;
	pthread_t threads[3];
	get_all_interface();
	create_ARP_table();
	display_IP_table();

	//set_dafault_gateway();
	ifc_mac_ip *interface=head;
	while(interface!=NULL)
		//for(inf_count = 0;inf_count <1;inf_count++)
	{
		pthread_create(&threads[inf_count],0,packet_sniffer,interface);
		interface=interface->next;
		inf_count++;
		//pthread_join(threads[inf_count],0);
	}

	pthread_join(threads[0],0);
	pthread_join(threads[1],0);
	pthread_join(threads[2],0);

}

void *packet_sniffer(void* arg)
{
	char source[INET6_ADDRSTRLEN];
	char dest1[INET6_ADDRSTRLEN];
	int iface_index=0;
	ifc_mac_ip *interface =(ifc_mac_ip*) arg;

	unsigned char source_mac[INET6_ADDRSTRLEN]={'\0'};
	unsigned char destination_mac[INET6_ADDRSTRLEN]={'\0'};
	int sockfd_r,sockfd_s, ret, i;
	int sockopt,index;
	ssize_t numbytes;
	struct ifreq ifopts;	/* set promiscuous mode */
	struct ifreq if_ip;	/* get ip addr */
	struct ifreq if_idx;
	struct ifreq if_mac;
	int tx_len = 0;
	char dest[INET6_ADDRSTRLEN];
	struct sockaddr_storage their_addr;
	struct sockaddr_ll socket_address;
	uint8_t buf[BUF_SIZ];
	char ifName_source[IFNAMSIZ],ifName[IFNAMSIZ];;

	strcpy(ifName_source, interface->eth_ifc);//head->source_mac);

	/* Header structures */
	struct ether_header *eh = (struct ether_header *) buf;
	struct ipheader *iph = (struct ipheader *) (buf + sizeof(struct ether_header));


	/* Open PF_PACKET socket, listening for EtherType ETHER_TYPE */
	if ((sockfd_r = socket(PF_PACKET, SOCK_RAW, htons(ETH_P_IP))) == -1) {
		perror("listener: socket");	
		//return -1;
	}
	/* Open RAW socket to send on */
	if ((sockfd_s = socket(AF_PACKET, SOCK_RAW, IPPROTO_RAW)) == -1) {
		perror("sender:socket");
	}


	strncpy(ifopts.ifr_name, ifName_source, IFNAMSIZ-1);
	ioctl(sockfd_r, SIOCGIFFLAGS, &ifopts);
	ifopts.ifr_flags |= IFF_PROMISC;
	ioctl(sockfd_r, SIOCSIFFLAGS, &ifopts);
	/* Allow the socket to be reused - incase connection is closed prematurely */
	if (setsockopt(sockfd_r, SOL_SOCKET, SO_REUSEADDR, &sockopt, sizeof sockopt) == -1) {
		perror("setsockopt");
		close(sockfd_r);
		exit(1);
	}
	/* Bind to device */
	if (setsockopt(sockfd_r, SOL_SOCKET, SO_BINDTODEVICE, ifName_source, IFNAMSIZ-1) == -1)	{
		perror("SO_BINDTODEVICE");
		close(sockfd_r);
		exit(1);
	}
	/*	printf("listener: Waiting to recvfrom...\n");*/
	while(1)
	{
		memset(buf,'\0',BUF_SIZ);
		numbytes = recvfrom(sockfd_r, buf, BUF_SIZ, 0, NULL, NULL);

		if ((eh->ether_shost[0] == (interface->target_mac[0])) && (eh->ether_shost[1] == (interface->target_mac[1])) &&
				(eh->ether_shost[2] == (interface->target_mac[2])) && (eh->ether_shost[3] == (interface->target_mac[3])) &&
				(eh->ether_shost[4] == (interface->target_mac[4])) && (eh->ether_shost[5] == (interface->target_mac[5])))
		{   
			//pthread_mutex_lock(&m);
			/*printf("listener: got packet %lu bytes\n", numbytes);*/
			/*printf("packet recieved:source frame MAC address is ");*/
			/*for(index=0;index<6;index++)
				printf(" %02X: ",eh->ether_shost[index]);
			printf("\n");*/
			struct ether_header *eh_s = (struct ether_header *) buf;

			if(lookup_address(iph->daddr,source_mac,destination_mac,&iface_index))
			{
				//pthread_mutex_unlock(&m);
				//printf("IP header ihl=%d,version %d,tos=%d,tot_len=%d,id=%d,frage_off=%d,ttl=%d,protocol=%d,chec=%d,saddr=%u,daddr=%u\n",iph->ihl,iph->version,iph->tos,iph->tot_len,iph->id,iph->frag_off,iph->ttl,iph->protocol,iph->check,iph->saddr,iph->daddr);
				/*			printf("ttl value is%d\n",iph->ttl);*/
				//printf("heade len %d\n",iph->ihl);*/
				//printf("iph check of rcv packet%d\n",iph->check);
				//iph->check=0;
				//iph->ttl--;
				/*				printf("ttl value is%d\n",iph->ttl);*/
				if(iph->check ==htons((calc_ip_checksum(buf))))
				{
					iph->ttl--;
					if(iph->ttl<=0)
					{
						/*write icmp*/
					}
					else
					{
						iph->check =htons((calc_ip_checksum(buf)));
						//printf("iph check of recalculated%d/n",iph->check);


						for(index=0;index<6;index++)
						{
							eh_s->ether_shost[index] = 	source_mac[index];
							eh_s->ether_dhost[index] = destination_mac[index];
							socket_address.sll_addr[index] = destination_mac[index];
						}

						/* Ethertype field */
						eh_s->ether_type = htons(ETH_P_IP);
						tx_len += sizeof(struct ether_header);
						tx_len += sizeof(struct iphdr);

						/* Index of the network device */
						socket_address.sll_ifindex = iface_index;//if_idx.ifr_ifindex;
						/* Address length*/
						socket_address.sll_halen = ETH_ALEN;

						if (sendto(sockfd_s, buf, BUF_SIZ, 0, (struct sockaddr*)&socket_address, sizeof(struct sockaddr_ll)) < 0)
							perror("sendto");

						/*					printf("\n");*/
					}
				}
			}
			//	pthread_mutex_unlock(&m);
		}
	}


	close(sockfd_r);
	close(sockfd_s);
	return 0;
}

int lookup_address(u_int16_t dest_ip,unsigned char source_mac[],unsigned char desination_mac[],int *iface_index)
{
	char addr1[50],addr2[50];//,addr3[50],addr4[50];

	memset(addr1,'\0',sizeof(addr1));
	memset(addr2,'\0',sizeof(addr2));
	ifc_mac_ip *interface=head;
	unsigned int addr;
	int index;
	addr=dest_ip;
	sprintf(addr1,"%d",(addr  & 0xFF));
	sprintf(addr2,"%d",(addr >> 8 & 0xFF));
	while(interface!=NULL)
	{
		if ((interface->source_ip[0]==atoi(addr2)) && (interface->source_ip[1]==atoi(addr1)))// && (interface->source_ip[2]==atoi((addr3))) &&(interface->source_ip[3]==atoi(addr3)))
		{
			*iface_index =0;
			return 0;
		}

		if ((interface->target_ip[0]==atoi(addr2)) && (interface->target_ip[1]==atoi(addr1)))// && (interface->target_ip[2]==atoi((addr3))))
		{
			for(index=0;index<=5;index++)
			{
				source_mac[index]=(unsigned char)interface->source_mac[index];//(unsigned char)source_ip[row][index];
				desination_mac[index]=(unsigned char)interface->target_mac[index];
			}
			*iface_index =interface->HW_index;
			return 1;
		}
		interface=interface->next;
	}

}
u_short calc_ip_checksum(const u_char* Buffer) {
	struct ipheader *iph = (struct ipheader*)(Buffer + sizeof(struct ethhdr));
	unsigned int sum = 0;
	iph->dummy=0;
	/*    printf("\n ttl inside fn %d",iph->ttl);*/
	sum += (((u_short)iph->ttl) << 8) | (u_short)iph->dummy;
	sum += ntohs((iph->saddr) & 0xff) ;
	sum += ntohs((iph->daddr) & 0xff);

	int chk = (((u_short)(sum >> 16)) & 0xf) + ((u_short)(sum) & 0xffff);
	return ~((u_short)chk);
}
