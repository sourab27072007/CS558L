#!/bin/sh
sudo ./sender 21 1 2 sab.bin &
sudo ./sender 31 3 4 sac.bin &
wait
echo "node 1 sent all file segments"
echo "checksum for SAB"
sudo md5sum sab.bin
echo "checksum for SAC"
sudo md5sum sac.bin

