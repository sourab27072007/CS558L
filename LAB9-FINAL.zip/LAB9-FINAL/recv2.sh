#!/bin/sh
a=$(date +"%s")
echo "start time is $a"
sudo ./receiver rbc.bin 10 &
sudo ./receiver rba.bin 2 &
wait
b=$(date +"%s")
echo "end time is $b"
diff=$((b-a))
echo "execution time is $diff"
printf "throughput is %d" $((8*2*10485760/(diff*1000000)))
echo "Mbps"
echo "node B received all file segments"
echo "checksum for RBC is"
sudo md5sum rbc.bin
echo "checksum for RBA is"
sudo md5sum rba.bin
