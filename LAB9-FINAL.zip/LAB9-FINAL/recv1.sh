#!/bin/sh
a=$(date +"%s")
echo "start time is $a"
sudo ./receiver rab.bin 6 &
sudo ./receiver rac.bin 12 &
wait
b=$(date +"%s")
echo "end time is $b"
diff=$((b-a))
echo "execution time is $diff"
printf "throughput is %d" $((8*2*10485760/(diff*1000000)))
echo "Mbps"
echo "node A received all file segments"
echo "Checksum for RAB is "
sudo md5sum rab.bin
echo "Checksum for RAC is"
sudo md5sum rac.bin
