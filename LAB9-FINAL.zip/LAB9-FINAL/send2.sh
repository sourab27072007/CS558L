#!/bin/sh
sudo ./sender 11 5 6 sba.bin &
sudo ./sender 31 7 8 sbc.bin &
wait
echo "node 2 sent all file segments"
echo "checksum for SBA"
sudo md5sum sba.bin
echo "checksum for SBC"
sudo md5sum sbc.bin

