import fileinput 
from pox.core import core
from pox.lib.addresses import IPAddr,EthAddr,parse_cidr
from pox.lib.revent import EventContinue,EventHalt
import pox.openflow.libopenflow_01 as of
from pox.lib.util import dpidToStr

import sys
import socket

prevserver = 0
s=socket.socket()
s.bind(('',5462))
s.listen(5)
conn, addr = s.accept()
while True:
	data = conn.recv(1024)
	if(data):
		if ((prevserver % 3) == 0):
	        	conn.send("10.10.2.2")
		elif ((prevserver%3) == 1):
			conn.send("10.10.3.2")
		elif ((prevserver%3) == 2):
			conn.send("10.10.4.2")
		prevserver = prevserver + 1
 		print('Controller received', repr(data))

s.close()
