from pox.core import core
from pox.lib.addresses import IPAddr,EthAddr,parse_cidr
from pox.lib.revent import EventContinue,EventHalt
import pox.openflow.libopenflow_01 as of
from pox.lib.util import dpidToStr
#from scapy.all import *
#from netaddr import *
#Random LB
from random import randint
#Random LB
import sys
import fileinput
import numpy as np
import socket
import threading
log = core.getLogger()

virtual_ip = IPAddr("10.10.5.2")
virtual_mac = EthAddr("00:04:23:ae:cc:32")
print "Pox Controller is up and running..."
def worker():
    #print("watever")
    udp_IP = "10.10.5.2"
    udp_PORT = 20559
    sock1 = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
    sock1.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock1.bind((udp_IP,udp_PORT))
    
    data, addr = sock1.recvfrom(20)
    print"\n",data
    if data == "I am done : 1":
	if server1_Queue.isEmpty():
		pass
	else:
	#if(server1_Queue):
        	val1 = server1_Queue.dequeue()
		server_count[0] = server_count[0] - int(val1)
		print("\ndequeuing from server1...")
		#print("updated server1 queue\n")
		#print(server1_Queue.items)
    elif data == "I am done : 2":
	if server2_Queue.isEmpty():
                pass
	else:
	#if(server2_Queue):
		val2 = server2_Queue.dequeue()
		server_count[1] = server_count[1] - int(val2)
		print("\ndequeuing from server2...")
                #print("updated server1 queue\n")
                #print(server1_Queue.items)
    else:
	if server3_Queue.isEmpty():
                pass
	else:
	#if(server3_Queue):
		val3 = server3_Queue.dequeue()
		server_count[2] = server_count[2] - int(val3)
		print("\ndequeuing from server3...")
                #print("updated server1 queue\n")
                #print(server1_Queue.items)
#    print_lock.release()		
    sock1.close()
    return

global server_index 
global count_lines
server = {}
server[0] = {'ip':IPAddr("10.10.2.2"), 'mac':EthAddr("00:0e:0c:68:a8:56"), 'outport': 2}
server[1] = {'ip':IPAddr("10.10.3.2"), 'mac':EthAddr("00:0e:0c:68:a8:57"), 'outport': 3}
server[2] = {'ip':IPAddr("10.10.4.2"), 'mac':EthAddr("00:11:43:d6:d6:36"), 'outport': 4}
total_servers = len(server)

server_index = 0 
server_count = [0,0,0]
count_lines = 0
"""
t = threading.Thread(target=worker)
t.start()
"""

class Queue:
    def __init__(self):
        self.items = []

    def isEmpty(self):
        return self.items == []

    def enqueue(self, item):
        self.items.insert(0,item)

    def dequeue(self):
        return self.items.pop()

    def size(self):
        return len(self.items)

server1_Queue = Queue()
server2_Queue = Queue()
server3_Queue = Queue()

prevserver = 0
s=socket.socket()
s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
s.bind(('',10015))
s.listen(10)
countOfLines = 0
#print_lock = threading.Lock()
#this listens forever. How to establish a connection between lb and servers.
#print 'before while'
while True:
	#print 'before accept'
        conn, addr = s.accept()
	#print 'after accept'
        data1 = conn.recv(3)
	print(data1)
	data2 = conn.recv(3)
	print(data2)
	data3 = conn.recv(3)
	print(data3)
	data4 = conn.recv(3)
	print(data4)
	data5 = conn.recv(3)
	print(data5)
	data6 = conn.recv(3)
	print(data6)
        #print("1st request's file size received is %s MB"%data1)
	#print("2nd request's file size received is %s MB"%data2)
	#print("3rd request's file size received is %s MB"%data3)
        #print("4th request's file size received is %s MB"%data4)
	#print("Data")
	#print(data)
	#print(type(data))
        #file = open('time.txt','r')
	"""    
	for line in file:
		countOfLines = countOfLines + 1

	file.seek(0,0)
	"""
	#lines = file.readlines()
	#file.close()
	#print(lines)
	#counter = 0
	#print lines
	#print countOfLines
	data = [data1, data2, data3, data4,data5,data6]
	for i in data:
		#counter = 0
		#for each in lines:
			#print(each)
			#a,b = lines[counter].split(",")
			#if a == i:
		load = i
				
	
	
		#print a
		#print b
		b = load	    
		small = np.array(server_count)
		small_index = np.argmin(small)
        	#print("thing")
        	#print(server_count)
        	#print(small_index)
		server_count[small_index] = server_count[small_index] + int(b)
		if small_index==0:
			server1_Queue.enqueue(b)
			print("sending to server1.......")
		elif small_index==1:
			server2_Queue.enqueue(b)
			print("sending to server2.......")
		elif small_index==2:
			server3_Queue.enqueue(b)
			print("sending to server3.......")
		else:
			print("Index out of range error")
		
		print("Server 1 queue")
		print(server1_Queue.items)
		print("Server 2 queue")
		print(server2_Queue.items)
		print("Server 3 queue")
		print(server3_Queue.items)
		print("Server load array")
		print server_count
		
		#print server_count[small_index]
		index=small_index
		#count_lines=count_lines+1
		#count_lines = count_lines % countOfLines
        	#print("Index is")
        	#print(small_index)
		selected_server_ip = server[index]['ip']
		#selected_server_mac = server[index]['mac']
		#selected_server_outport = server[index]['outport']
		print(selected_server_ip)
		conn.send(str(selected_server_ip))
		print(selected_server_ip)
		#print_lock.acquire()
		t = threading.Thread(target=worker)
		t.start()
	"""
	print("Server 1 queue")
	print(server1_Queue.items)
        print("Server 2 queue")
        print(server2_Queue.items)
        print("Server 3 queue")
        print(server3_Queue.items)
        print("Server load List")
        print server_count
	"""

"""
	udp_IP = "10.10.5.2"
	udp_PORT = 20555
	sock1 = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
	sock1.bind((udp_IP,udp_PORT))
	#data, addr = sock1.recvfrom(20)
	print(data)
	if data == "I am done : 1":
		val1 = server1_Queue.dequeue()
		server_count[0] = server_count[0] - int(val1)
	elif data == "I am done : 2":
		val2 = server2_Queue.dequeue()
		server_count[1] = server_count[1] - val2
	else:
		val3 = server3_Queue.dequeue()
		server_count[2] = server_count[2] - val3
		
	sock1.close()
"""	
s.close()




 

    
    
	
	

 
