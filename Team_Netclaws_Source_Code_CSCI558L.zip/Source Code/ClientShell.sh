python cb.py 50 30 20 10 data50.bin data30.bin data20.bin data10.bin 20 10 data20.bin data10.bin
sleep 1s
python cb.py 90 10 30 50 data90.bin data10.bin data30.bin data50.bin 40 20 data40.bin data20.bin
