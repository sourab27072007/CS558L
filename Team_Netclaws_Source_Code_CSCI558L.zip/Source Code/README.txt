--------------------------------------------------------------------------------
README
--------------------------------------------------------------------------------
ROUND ROBIN ALGORITHM
To run the Load Balancer which implements Round Robin Algorithm put the following codes on the respective nodes.
1.On Controller:Run the l2_learning.py and RoundRobinLB.py on the POX controller using the following command-
./pox.py forwarding.l2_learning forwarding.RoundRobinLB
2.On Client node:Run the ClientShell.sh script which contains the files and their respective file sizes using the command-
sh ClientShell.sh
3.On Server nodes:Run server.py code on the 3 servers using the command - 
python server.py

TRAFFIC BASED ALGORITHM
To run the Load Balancer which implements Round Robin Algorithm put the following codes on the respective nodes.
1.On Controller:Run the l2_learning.py and TrafficBasedLB.py on the POX controller using the following command-
./pox.py forwarding.l2_learning forwarding.TrafficBasedLB
2.On Client node:Run the ClientShell.sh script which contains the files and their respective file sizes sing the command-
sh ClientShell.sh
3.On Server nodes:Run server.py code on the 3 servers using the command - 
python server.py

To observe a better performance of the traffic based compared to Round Robin we compare the overall time served by each
server for a request.
We notice better server utilization capabilities when implementing our Traffic Based Load Balancing Algorithm

