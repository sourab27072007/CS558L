import socket
import threading
import time
import os

global counter
counter=0
TCP_IP = '10.10.2.2' #put IP addresses of respective servers
TCP_PORT1 = 3090
TCP_PORT2 = 4091
TCP_PORT3 = 5092
TCP_PORT4 = 6093
TCP_PORT5 = 7094
TCP_PORT6 = 8095
BUFFER_SIZE = 1024
sleep_timer = 0
print "Server 1 is up and running..."
#t1 = threading.Thread(target=func1)
#t2 = threading.Thread(target=func2)
def func1():
	global counter
	s1 = socket.socket()
	s1.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
	s1.bind((TCP_IP, TCP_PORT1))
	s1.listen(5)
	udp_IP = '10.10.5.2'
        udp_PORT = 20559
	while True:
		conn1, addr1 = s1.accept()
		file_desc1 = open('recv1.bin', 'wb')
    		#print "File received"
		line1 = conn1.recv(1024)
      		#print line
		#sleep_ti=line
    		while line1:
			file_desc1.write(line1)
        		line1 = conn1.recv(BUFFER_SIZE)
        		if not line1:
				counter=counter+1
				print(counter)
            			break
    		file_desc1.close()
		print("End time for recv1.bin is %f"%(time.time()))
		print "File content received and written"
		#b = os.path.getsize("recv1.bin")
                #time.sleep(b/1000000)
		sock1 = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        	sock1.sendto("I am done : 1",(udp_IP,udp_PORT))
		#time.sleep(sleep_ti)
	conn1.close()
	s1.close()
	sock1.close()

def func2():
	global counter
        s2 = socket.socket()
	s2.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
        s2.bind((TCP_IP, TCP_PORT2))
        s2.listen(5)
	udp_IP = '10.10.5.2'
        udp_PORT = 20559
        while True:
                conn2, addr2 = s2.accept()
                file_desc2 = open('recv2.bin', 'wb')
                #print "File received"
		line2 = conn2.recv(1024)
                #print line
                while line2:
                        file_desc2.write(line2)
                        line2 = conn2.recv(BUFFER_SIZE)
                        if not line2:
				counter = counter+1
				print(counter)
                                break
                file_desc2.close()
		print("End time for recv2.bin is %f"%(time.time()))
        	print "File content received and written"
		#a = os.path.getsize("recv2.bin")
                #time.sleep(a/1000000)
		sock2 = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        	sock2.sendto("I am done : 1",(udp_IP,udp_PORT))
	#time.sleep(10)
        conn2.close()
	s2.close()
        sock2.close()

def func3():
        global counter
        s3 = socket.socket()
        s3.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
        s3.bind((TCP_IP, TCP_PORT3))
        s3.listen(5)
        udp_IP = '10.10.5.2'
        udp_PORT = 20559
        while True:
                conn3, addr3 = s3.accept()
                file_desc3 = open('recv3.bin', 'wb')
                #print "File received"
                line3 = conn3.recv(1024)
                #print line
                while line3:
                        file_desc3.write(line3)
                        line3 = conn3.recv(BUFFER_SIZE)
                        if not line3:
                                counter = counter+1
                                print(counter)
                                break
                file_desc3.close()
		#print("End time for %s is %f"%(recv3.bin,time.time()))
		print("End time for recv3.bin is %f"%(time.time()))
                print "File content received and written"
                #a = os.path.getsize("recv3.bin")
                #time.sleep(a/1000000)
                sock3 = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                sock3.sendto("I am done : 1",(udp_IP,udp_PORT))
        #time.sleep(10)
        conn3.close()
        s3.close()
        sock3.close()

def func4():
        global counter
        s4 = socket.socket()
        s4.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
        s4.bind((TCP_IP, TCP_PORT4))
        s4.listen(5)
        udp_IP = '10.10.5.2'
        udp_PORT = 20559
        while True:
                conn4, addr4 = s4.accept()
                file_desc4 = open('recv4.bin', 'wb')
                #print "File received"
                line4 = conn4.recv(1024)
                #print line
                while line4:
                        file_desc4.write(line4)
                        line4 = conn4.recv(BUFFER_SIZE)
                        if not line4:
                                counter = counter+1
                                print(counter)
                                break
                file_desc4.close()
		#print("End time for %s is %f"%(recv4.bin,time.time()))
                print("End time for recv4.bin is %f"%(time.time()))
		print "File content received and written"
                #a = os.path.getsize("recv4.bin")
                #time.sleep(a/1000000)
                sock4 = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                sock4.sendto("I am done : 1",(udp_IP,udp_PORT))
        #time.sleep(10)
        conn4.close()
        s4.close()
        sock4.close()

def func5():
        global counter
        s5 = socket.socket()
        s5.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
        s5.bind((TCP_IP, TCP_PORT5))
        s5.listen(5)
        udp_IP = '10.10.5.2'
        udp_PORT = 20559
        while True:
                conn5, addr5 = s5.accept()
                file_desc5 = open('recv5.bin', 'wb')
                #print "File received"
                line5 = conn5.recv(1024)
                #print line
                while line5:
                        file_desc5.write(line5)
                        line5 = conn5.recv(BUFFER_SIZE)
                        if not line5:
                                counter = counter+1
                                print(counter)
                                break
                file_desc5.close()
		#print("End time for %s is %f"%(recv5.bin,time.time()))
                print("End time for recv5.bin is %f"%(time.time()))
		print "File content received and written"
                #a = os.path.getsize("recv5.bin")
                #time.sleep(a/1000000)
                sock5 = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                sock5.sendto("I am done : 1",(udp_IP,udp_PORT))
        #time.sleep(10)
        conn5.close()
        s5.close()
        sock5.close()
def func6():
        global counter
        s6 = socket.socket()
        s6.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
        s6.bind((TCP_IP, TCP_PORT6))
        s6.listen(5)
        udp_IP = '10.10.5.2'
        udp_PORT = 20559
        while True:
                conn6, addr6 = s6.accept()
                file_desc6 = open('recv6.bin', 'wb')
                #print "File received"
                line6 = conn6.recv(1024)
                #print line
                while line6:
                        file_desc6.write(line6)
                        line6 = conn6.recv(BUFFER_SIZE)
                        if not line6:
                                counter = counter+1
                                print(counter)
                                break
                file_desc6.close()
		#print("End time for %s is %f"%(recv6.bin,time.time()))
                print("End time for recv6.bin is %f"%(time.time()))
		print "File content received and written"
                #a = os.path.getsize("recv6.bin")
                #time.sleep(a/1000000)
                sock6 = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                sock6.sendto("I am done : 1",(udp_IP,udp_PORT))
        #time.sleep(10)
        conn6.close()
        s6.close()
        sock6.close()



"""
print "Creating socket..."
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print "Binding to broadcast:5005 ..."
s.bind((TCP_IP, TCP_PORT))
print "Creating buffer for 5 connections..."

s.listen(5)
"""
t1 = threading.Thread(target=func1)
t2 = threading.Thread(target=func2)
t3 = threading.Thread(target=func3)
t4 = threading.Thread(target=func4)
t5 = threading.Thread(target=func5)
t6 = threading.Thread(target=func6)
t1.start()
t2.start()
t3.start()
t4.start()
t5.start()
t6.start()
#t1.join()
#t2.join()
"""
while True:
#	t1 = threading.Thread(target=func1)
#	t2 = threading.Thread(target=func2)
#	t1.start()
#	t2.start()





    
    	print "Waiting for connection..."
    	conn, addr = s.accept()
    	print "Getting file..."
    	sleep_time = conn.recv(2)
    	sleep_int = int(sleep_time)
    	print sleep_int
    	#if sleep_int in (10,20,30,40):
    	sleep_timer = sleep_int
    	file_desc = open('recv.bin', 'wb')
    	line = conn.recv(1024)
    	print line
    	while line:
       	# print '.'
        file_desc.write(line)
        line = conn.recv(BUFFER_SIZE)
        if not line:
            break
    	file_desc.close()
    	print "RECIEVING: DONE"

 
    	file = open("sleep.txt","r")
    	sleep_time = file.readline()
    	print(sleep_time)
    	print(type(sleep_time))
    	

	conn.send(sleep_data)
	sleep_timer = int(sleep_time)
	actual_sleep = sleep_timer/2
	print(actual_sleep)
	time.sleep(10)     
	time.sleep(int(sleep_time))
	print "Sleep done"
	s.connect((TCP_IP, TCP_PORT))
	conn.send("I am done")
    
	conn.close()
    
    	udp_IP = '10.10.5.2'
    	udp_PORT = 20562
    	#buffer_SIZE = 1024
    	sock1 = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    	#print("before connect")
    	#server_address = (udp_IP, udp_PORT)
    	#sock1.connect((udp_IP, udp_PORT))
    	#print("ABC")
    	#sock.sendto("I am done",server_address)
	while(counter>0):
		counter=counter-1	
    		sock1.sendto("I am done : 2",(udp_IP,udp_PORT))
    	#print("DEF")
    	# s.send(sleep_timer)
    	sock1.close()
"""     
