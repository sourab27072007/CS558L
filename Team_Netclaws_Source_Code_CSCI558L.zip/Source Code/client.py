import socket
import threading
import sys
import timeit
import time
hostnew = "10.10.5.2"
portnew = 10015
#s = socket.socket()             # Create a socket object to talk to servers
sock = socket.socket()		# Create socket to talk to LB
sock.connect((hostnew, portnew))
buff1 = sys.argv[1]
buff2 = sys.argv[2]
#print(buff2)
buff3 = sys.argv[3]
#print(buff3)
buff4 = sys.argv[4]
#print(buff4)
buff5 = sys.argv[5]
#print(buff5)
buff6 = sys.argv[6]
#print(buff6)
start_time = timeit.default_timer()
sock.send(buff1)
sock.send(buff2)
sock.send(buff3)
sock.send(buff4)
sock.send(buff5)
sock.send(buff6)
print("Client Booted")

data1 = sock.recv(9)
#print(data1)
data2 = sock.recv(9)
#print(data2)
data3 = sock.recv(9)
#print(data3)
data4 = sock.recv(9)
#print(data4)
data5 = sock.recv(9)
data6 = sock.recv(9)
elapsed = timeit.default_timer() - start_time
print("Load Balancer's response time is %f"%elapsed)
#print "Send file to IP %s" %(data1)
#print "Send file to IP %s" %(data2)
TCP_IP1 = data1
TCP_IP2 = data2
TCP_IP3 = data3
TCP_IP4 = data4
TCP_IP5 = data5
TCP_IP6 = data6
TCP_PORT1 = 3090
TCP_PORT2 = 4091
TCP_PORT3 = 5092
TCP_PORT4 = 6093
TCP_PORT5 = 7094
TCP_PORT6 = 8095
BUFFER_SIZE = 1024



print_lock = threading.Lock()

def worker1():
	#print("\nIn worker 1")
	#recv server ip
	s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

	s.connect((TCP_IP1, TCP_PORT1))
	start_time1 = timeit.default_timer()
	#file_desc = open('data.bin', 'rb')
	file_desc = open(sys.argv[7], 'rb')
	#s.send(sys.argv[1])
	line = file_desc.read(BUFFER_SIZE)
	print("Start time for %s is %f"%(sys.argv[7],time.time()))
	while (line):
        	#print "sending..."
        	s.send(line)
        	line = file_desc.read(BUFFER_SIZE)
	print("File %s was successfully sent to IP %s"%(sys.argv[7],TCP_IP1))
	elapsed1 = timeit.default_timer() - start_time1
	#print("File upload time is %f"%elapsed1)
	print("File upload time of %s is %f"%(sys.argv[7],elapsed1))
	#print_lock.release()
	file_desc.close()
	s.close()
	#send to server
	

	#s.send("Hi i'm Thread 1")

def worker2():
	#s.send("Hi i'm thread 2")
	#print("\nIn worker 2")
        #recv server ip
	s1 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

	s1.connect((TCP_IP2, TCP_PORT2))
	start_time2 = timeit.default_timer()
        #file_desc1 = open('data1.bin', 'rb')
        file_desc1 = open(sys.argv[8], 'rb')
	print("Start time for %s is %f"%(sys.argv[8],time.time()))
        line1 = file_desc1.read(BUFFER_SIZE)

        while (line1):
                #print "sending..."
                s1.send(line1)
                line1 = file_desc1.read(BUFFER_SIZE)
	print("File %s was successfully sent to IP %s"%(sys.argv[8],TCP_IP2))
	elapsed2 = timeit.default_timer() - start_time2
        #print("File upload time is %f"%elapsed2)
	print("File upload time of %s is %f"%(sys.argv[8],elapsed2))
	#print_lock.release()
        file_desc1.close()
	s1.close()

def worker3():
        #s.send("Hi i'm thread 2")
        #print("\nIn worker 2")
        #recv server ip
        s3 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        s3.connect((TCP_IP3, TCP_PORT3))
        start_time3 = timeit.default_timer()
        #file_desc1 = open('data1.bin', 'rb')
        file_desc3 = open(sys.argv[9], 'rb')
	print("Start time for %s is %f"%(sys.argv[9],time.time()))
        line3 = file_desc3.read(BUFFER_SIZE)

        while (line3):
                #print "sending..."
                s3.send(line3)
                line3 = file_desc3.read(BUFFER_SIZE)
        print("File %s was successfully sent to IP %s"%(sys.argv[9],TCP_IP3))
        elapsed3 = timeit.default_timer() - start_time3
        #print("File upload time is %f"%elapsed3)
	print("File upload time of %s is %f"%(sys.argv[9],elapsed3))
        #print_lock.release()
        file_desc3.close()
        s3.close()

def worker4():
        #s.send("Hi i'm thread 2")
        #print("\nIn worker 2")
        #recv server ip
        s4 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        s4.connect((TCP_IP4, TCP_PORT4))
        start_time4 = timeit.default_timer()
        #file_desc1 = open('data1.bin', 'rb')
        file_desc4 = open(sys.argv[10], 'rb')
	print("Start time for %s is %f"%(sys.argv[10],time.time()))
        line4 = file_desc4.read(BUFFER_SIZE)

        while (line4):
                #print "sending..."
                s4.send(line4)
                line4 = file_desc4.read(BUFFER_SIZE)
        print("File %s was successfully sent to IP %s"%(sys.argv[10],TCP_IP4))
        elapsed4 = timeit.default_timer() - start_time4
        #print("File upload time is %f"%elapsed4)
	print("File upload time of %s is %f"%(sys.argv[10],elapsed4))
        #print_lock.release()
        file_desc4.close()
        s4.close()

def worker5():
        #s.send("Hi i'm thread 2")
        #print("\nIn worker 2")
        #recv server ip
        s5 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        s5.connect((TCP_IP5, TCP_PORT5))
        start_time5 = timeit.default_timer()
        #file_desc1 = open('data1.bin', 'rb')
        file_desc5 = open(sys.argv[11], 'rb')
	print("Start time for %s is %f"%(sys.argv[11],time.time()))
        line5 = file_desc5.read(BUFFER_SIZE)

        while (line5):
                #print "sending..."
                s5.send(line5)
                line5 = file_desc5.read(BUFFER_SIZE)
        print("File %s was successfully sent to IP %s"%(sys.argv[11],TCP_IP5))
        elapsed5 = timeit.default_timer() - start_time5
        #print("File upload time is %f"%elapsed5)
	print("File upload time of %s is %f"%(sys.argv[11],elapsed5))
        #print_lock.release()
        file_desc5.close()
        s5.close()

def worker6():
        #s.send("Hi i'm thread 2")
        #print("\nIn worker 2")
        #recv server ip
        s6 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        s6.connect((TCP_IP6, TCP_PORT6))
        start_time6 = timeit.default_timer()
        #file_desc1 = open('data1.bin', 'rb')
        file_desc6 = open(sys.argv[12], 'rb')
	print("Start time for %s is %f"%(sys.argv[12],time.time()))

        line6 = file_desc6.read(BUFFER_SIZE)

        while (line6):
                #print "sending..."
                s6.send(line6)
                line6 = file_desc6.read(BUFFER_SIZE)
        print("File %s was successfully sent to IP %s"%(sys.argv[12],TCP_IP6))
        elapsed6 = timeit.default_timer() - start_time6
        print("File upload time of %s is %f"%(sys.argv[12],elapsed6))
        #print_lock.release()
        file_desc6.close()
        s6.close()


"""
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

s.connect((TCP_IP, TCP_PORT1))
s1 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

s1.connect((TCP_IP, TCP_PORT2))
"""
#fileName = sys.argv[2]
t1 = threading.Thread(target=worker1)
t2 = threading.Thread(target=worker2)
t3 = threading.Thread(target=worker3)
t4 = threading.Thread(target=worker4)
t5 = threading.Thread(target=worker5)
t6 = threading.Thread(target=worker6)
#print_lock.acquire()
t1.start()
#print_lock.acquire()
t2.start()
t3.start()
t4.start()
t5.start()
t6.start()
#s.send(sys.argv[1])
#s.send("000010")

"""
file_desc = open('data.bin', 'rb')
#file_desc = open(sys.argv[2], 'rb')

line = file_desc.read(BUFFER_SIZE)

while (line):
	#print "sending..."
	s.send(line)
	line = file_desc.read(BUFFER_SIZE)

file_desc.close()
"""
#print("DONE")
#recvd = s.recv(20)
#print recvd
#s.shutdown(socket.SHUT_WR)
#SSSSprint
#recvd = s.recv(12)
#print recvd
#s.close()
#s1.close()
"""
udp_IP = '10.0.0.1' #put IP addresses of respective servers
udp_PORT = 20555
buffer_SIZE = 1024
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
#sock.bind((udp_IP, udp_PORT))
#sock.listen(5)
#conn, addr = sock.accept()
#msg = sock.recv(6)
#print msg
sock.close()
"""
