#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/time.h>

#include "cs402.h"

#include "my402list.h"

int  My402ListLength(My402List* List)
{
	return List->num_members;
}
int  My402ListEmpty(My402List* List)
{
	if(List->num_members==0)
		return 1;
	else
		return 0;
}
int  My402ListAppend(My402List* List, void* obj1)
{
	My402ListElem* temp=(My402ListElem*)malloc(sizeof(My402ListElem));
	My402ListElem* temp2=(My402ListElem*)malloc(sizeof(My402ListElem));
	if(List->num_members==0)
	{
		temp->obj=obj1;
		temp->prev=&List->anchor;
		temp->next=&List->anchor;
		List->anchor.prev=temp;
		List->anchor.next=temp;
		List->num_members=List->num_members+1;
		return 1;
	}
	else
	{
		temp2=My402ListLast(List);
		temp->obj=obj1;
		temp->prev=temp2;
		temp2->next=temp;
		temp->next=&List->anchor;
		List->anchor.prev=temp;
		List->num_members=List->num_members+1;
		return 1;
	}
	return 0;
}
int  My402ListPrepend(My402List* List, void* obj1) 
{
	My402ListElem* temp=(My402ListElem*)malloc(sizeof(My402ListElem));
	My402ListElem* temp2=(My402ListElem*)malloc(sizeof(My402ListElem));
	if(List->num_members==0)
	{
		temp->obj=obj1;
		temp->next=&List->anchor;
		temp->prev=&List->anchor;
		List->anchor.prev=temp;
		List->anchor.next=temp;
		List->num_members=List->num_members+1;
		return 1;
	}
	else
	{
		temp2=My402ListFirst(List);
		temp->obj=obj1;
		temp->next=temp2;
		temp2->prev=temp;
		temp->prev=&List->anchor;
		List->anchor.next=temp;
		List->num_members=List->num_members+1;
		return 1;
	}
	return 0;
}
void My402ListUnlink(My402List* List, My402ListElem* elem)
{
	//My402ListElem* temp=(My402ListElem*)malloc(sizeof(My402ListElem));
	//My402ListElem* temp2=(My402ListElem*)malloc(sizeof(My402ListElem));
	My402ListElem* temp;
	My402ListElem* temp2;
	temp=elem->next;
	temp2=elem->prev;
	temp2->next=temp;
	temp->prev=temp2;
	List->num_members=List->num_members-1;
	free(elem);
}
void My402ListUnlinkAll(My402List* List)
{
	My402ListElem* elem=NULL;
	for(elem=My402ListFirst(List);elem!=NULL;elem=My402ListNext(List,elem))
	{
		My402ListUnlink(List,elem);
	}
}
int  My402ListInsertAfter(My402List* List, void* obj1, My402ListElem* elem)
{
	int a;
	if(elem==NULL)
	{
		a=My402ListAppend(List,obj1);
		if(a)
			return 1;
		else
			return 0;
	}
	else
	{
		My402ListElem* temp=(My402ListElem*)malloc(sizeof(My402ListElem));
		My402ListElem* temp2=(My402ListElem*)malloc(sizeof(My402ListElem));
		temp->obj=obj1;
		temp2=elem->next;
		elem->next=temp;
		temp2->prev=temp;
		temp->prev=elem;
		temp->next=temp2;
		List->num_members=List->num_members+1;
		return 1;
	}
	return 0;
}
int  My402ListInsertBefore(My402List* List, void* obj1, My402ListElem* elem)
{
	int a;
	if(elem==NULL)
	{
		a=My402ListPrepend(List,obj1);
		if(a)
			return 1;
		else
			return 0;
	}
	else
	{
		My402ListElem* temp=(My402ListElem*)malloc(sizeof(My402ListElem));
		My402ListElem* temp2=(My402ListElem*)malloc(sizeof(My402ListElem));
		temp->obj=obj1;
		temp2=elem->prev;
		elem->prev=temp;
		temp2->next=temp;
		temp->prev=temp2;
		temp->next=elem;
		List->num_members=List->num_members+1;
		return 1;
	}
	return 0;
}

My402ListElem *My402ListFirst(My402List* List)
{
	if(List->num_members==0)
		return NULL;
	else
		return List->anchor.next;
}

My402ListElem *My402ListLast(My402List* List)
{
	if(List->num_members==0)
		return NULL;
	else
		return List->anchor.prev;
}

My402ListElem *My402ListNext(My402List* List, My402ListElem* elem)
{
	if(elem->next==&(List->anchor))
		return NULL;
	else
		return elem->next;
}

My402ListElem *My402ListPrev(My402List* List, My402ListElem* elem)
{
	if(elem->prev==&(List->anchor))
		return NULL;
	else
		return elem->prev;
}

My402ListElem *My402ListFind(My402List* List, void* obj1)
{
	My402ListElem* elem=NULL;
	for(elem=My402ListFirst(List);elem!=NULL;elem=My402ListNext(List,elem))
	{
		if(elem->obj==obj1)
			return elem;
	}
	return NULL;
}

int My402ListInit(My402List* List)
{
	List->anchor.next=&List->anchor;
	List->anchor.prev=&List->anchor;
	List->anchor.obj=NULL;
	List->num_members=0;
	if(List->anchor.next==&List->anchor && List->anchor.prev==&List->anchor && List->anchor.obj==NULL && List->num_members==0)
		return 1;
	else
		return 0;
}
