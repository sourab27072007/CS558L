#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/time.h>
#include <time.h>
#include <math.h>
#include <errno.h>
#include <sys/stat.h>

#include "cs402.h"

#include "my402list.h"

double glo_balance=0;

char* convstr(char *,double);

typedef struct transaction
{
    char trans_type[2];
    int trans_time;
    double trans_amt;
    char trans_descrp[1024];
}trans;

void BubbleForward(My402List *pList, My402ListElem **pp_elem1, My402ListElem **pp_elem2)
    /* (*pp_elem1) must be closer to First() than (*pp_elem2) */
{
    My402ListElem *elem1=(*pp_elem1), *elem2=(*pp_elem2);
    void *obj1=elem1->obj, *obj2=elem2->obj;
    My402ListElem *elem1prev=My402ListPrev(pList, elem1);
/*  My402ListElem *elem1next=My402ListNext(pList, elem1); */
/*  My402ListElem *elem2prev=My402ListPrev(pList, elem2); */
    My402ListElem *elem2next=My402ListNext(pList, elem2);

    My402ListUnlink(pList, elem1);
    My402ListUnlink(pList, elem2);
    if (elem1prev == NULL) {
        (void)My402ListPrepend(pList, obj2);
        *pp_elem1 = My402ListFirst(pList);
    } else {
        (void)My402ListInsertAfter(pList, obj2, elem1prev);
        *pp_elem1 = My402ListNext(pList, elem1prev);
    }
    if (elem2next == NULL) {
        (void)My402ListAppend(pList, obj1);
        *pp_elem2 = My402ListLast(pList);
    } else {
        (void)My402ListInsertBefore(pList, obj1, elem2next);
        *pp_elem2 = My402ListPrev(pList, elem2next);
    }
}

void BubbleSortForwardList(My402List *pList, int num_items)
{
    My402ListElem *elem=NULL;
    trans* cur_val=NULL;
    trans* next_val=NULL;
    int i=0;

    /*if (My402ListLength(pList) != num_items) {
        fprintf(stderr, "List length is not %1d in BubbleSortForwardList().\n", num_items);
        exit(1);
    }*/
    for (i=0; i < num_items; i++) {
        int j=0, something_swapped=FALSE;
        My402ListElem *next_elem=NULL;

        for (elem=My402ListFirst(pList), j=0; j < num_items-i-1; elem=next_elem, j++) {
            cur_val=(trans*)(elem->obj);

            next_elem=My402ListNext(pList, elem);
            next_val = (trans*)(next_elem->obj);

            if (cur_val->trans_time == next_val->trans_time)
            {
                fprintf(stderr,"Time stamps are equal, invalid\n");
                exit(1);
            }

            if (cur_val->trans_time > next_val->trans_time) {
                BubbleForward(pList, &elem, &next_elem);
                something_swapped = TRUE;
            }
        }
        if (!something_swapped) break;
    }
}

char* truncatespaces(char description[100])
{
    int len,i;
    for(i=1;i<=strlen(description);i++)
        if(description[i-1]=='\n')
            description[i-1]=description[i];
    len=strspn(description," ");
    for(i=len;i<(24+len);i++)
        description[i-len]=description[i];
    description[i-len]='\0';
    return description;
}

char* formattime(char t[30])
{
    int i;
    //char ch[20];
    int len=0;
    for(i=0;i<strlen(t);i++)
    {
        if(i<=10 || i>=20)
        {
             t[len]=t[i];
             len++;
        }       
    }
    t[len-1]='\0';
    return t;
}

char* Balance(char c1[30],double amt,char type[2])
{
    if(strcmp(type,"+")==0)
        glo_balance=glo_balance + amt;
    else
        glo_balance=glo_balance - amt;
    strcpy(c1,convstr(c1,fabs(glo_balance)));
    return c1;
}


char* convstr(char c[30],double amt)
{
    int i,len=0;
    char str[30];
    sprintf(str,"%.2f",amt);
    if(amt>=10000000)
    {
        strcpy(str,"?,???,???.??");
        strcpy(c,str);
        return c;
    }
    if(strlen(str)>9)
    {
        for(i=0;i<strlen(str);i++)
        {
             if(i==1 || i==4)
             {
                c[len]=',';
                len++;
                c[len]=str[i];  
             }
             else
                c[len]=str[i];
            len++;
        }
    c[len]='\0';   
    }
    else if(strlen(str)>6)
    {
        for(i=0;i<strlen(str);i++)
        {
            if(i==(strlen(str)-6))
            {
                 c[len]=',';
                 len++;
                 c[len]=str[i];
            }
            else
             c[len]=str[i];
         len++;
        }                    
    c[len]='\0';
    }
    else
        strcpy(c,str);

    return c;
}


int main(int argc, char *argv[])
{
    FILE *fp;
    struct stat st;
    char str[1100],type[2],t[15],amt[15],description[1024],ch[100];
    char c[30],c1[30],s[100][1100];
    char *sp;
    My402List* List=(My402List*)malloc(sizeof(My402List));
    int num_items,len;
    time_t raw,c_time;
    int a,i,count;
    
    len=0;
    count=0;
    num_items=0;

    strcpy(str,"");
    strcpy(type,"");
    strcpy(t,"");
    strcpy(amt,"");
    strcpy(description,"");
    strcpy(ch,"");
    strcpy(c,"");
    strcpy(c1,"");
    trans* temp2=NULL;
    My402ListElem* elem=(My402ListElem*)malloc(sizeof(My402ListElem));


    if(strcmp(argv[1],"sort")!=0)
    {
        fprintf(stderr,"Malformed Input, Second argument must be sort. The correct input format is ./warmup1 sort [filename] or ./warmup1 sort\n");
        printf("usage: warmup1 sort [tfile]\n");
        exit(1);
    }

//Check if file is provided by user to read the data from
    if(argc==3)
    {
         if(stat(argv[2],&st)==0)
         {
            if(S_ISDIR(st.st_mode))
            {
                fprintf(stderr,"The mentioned path is a directory, cannot be accessed\n");
                printf("usage: warmup1 sort [tfile]\n");
                exit(1);
            }
         }
         fp=fopen(argv[2],"r");
    }
       
//Read data from keyboard
    else if(argc==2)
        fp=stdin;
    else
    {
        fprintf(stderr,"Malformed command, Invalid number of arguments provided. The correct input format is ./warmup1 sort [filename] or ./warmup1 sort\n");
        printf("usage: warmup1 sort [tfile]\n");
        exit(1);
    }


    if(fp==NULL)
    {
        fprintf(stderr,"Malformed command, %s\n",strerror(errno));
        printf("usage: warmup1 sort [tfile]\n");
        exit(1);
    }

    //Initialize linked list created
    a=My402ListInit(List);

    if(a==0)
    {
        fprintf(stderr,"Error in initialization\n");
        exit(1);
    }

    //Read data from file line by line
    while(fgets(str,1100,fp)!=NULL)
    {
                //count no of lines read
        num_items++;
        
        //Check if entered line is greater than 1024 incuding new line
        if(strlen(str)>=1024)
        {
            fprintf(stderr,"Line entered is too long on line number %d\n",num_items);
            exit(-1);
        }


        //Store data of each field seperated by tabs in different variables
        i=0;
        count=0;
        sp=strtok(str,"\t");
        while(sp!=NULL)
        {
            strcpy(s[i++],sp);
            sp=strtok(NULL,"\t");
            count++;
        }

        if(count<=3)
        {
            fprintf(stderr,"Improper File format, There are less than 4 fields entered on line number %d\n", num_items);
            printf("usage: warmup1 sort [tfile]\n");
            exit(-1);
        }

        if(count>4)
        {
            fprintf(stderr, "Improper File format, There are more than 4 fields entered on line number %d\n", num_items);
            printf("usage: warmup1 sort [tfile]\n");
            exit(-1);
        }

        strcpy(type,s[0]);
        strcpy(t,s[1]);
        strcpy(amt,s[2]);
        strcpy(description,s[3]);
        /*strcpy(type,strtok(str,"\t"));
        strcpy(t,strtok(NULL,"\t"));
        strcpy(amt,strtok(NULL,"\t"));
        strcpy(description,strtok(NULL,"\t"));
        */

        if(strlen(type)==0)
        {
            fprintf(stderr, "Type cannot be empty  on line number %d\n",num_items);
            exit(1);
        }

        if(strlen(t)==0)
        {
            fprintf(stderr, "Timestamp cannot be empty on line number %d\n",num_items);
            exit(1);
        }

        if(strlen(amt)==0)
        {
            fprintf(stderr, "Amount cannot be empty on line number %d\n",num_items);
            exit(1);
        }

        if(strlen(description)==0)
        {
            fprintf(stderr, "Description cannot be empty on line number %d\n",num_items);
            exit(1);
        }

        //Check if type entered is only one character
        if(strlen(type)>1)
        {
            fprintf(stderr,"Type invalid, must be + or -  on line number %d\n", num_items);
            exit(1);
        }

        if(((strcmp(type,"+")==0) || (strcmp(type,"-")==0))!=1)
        {
            fprintf(stderr, "First character for transaction type must be + or - only on line number %d\n",num_items);
            printf("usage: warmup1 sort [tfile]\n");
            exit(1);
        }
        //Check if time stamp is less than 11 digits
        if(strlen(t)>10)
        {
            fprintf(stderr,"time stamp too long on line number %d\n",num_items);
            exit(-1);
        }

        len=strcspn(amt,".");
        
        if((strlen(amt)-len)!=3)
        {
            fprintf(stderr,"The amount must have exactly 2 digits after the decimal point on line number %d\n",num_items);
            exit(1);
        }
        trans* temp=(trans*)malloc(sizeof(trans));

        strcpy(temp->trans_type,type);
        temp->trans_time=atoi(t);
        temp->trans_amt=(double)atof(amt);
        strcpy(temp->trans_descrp,description);
        
        strcpy(description,truncatespaces(temp->trans_descrp));
        strcpy(temp->trans_descrp,description);

        if(strlen(description)==0)
        {
            fprintf(stderr,"description must contain some data on line number %d\n",num_items);
            exit(-1);
        }
        
        //amount should not be negative
        if(temp->trans_amt<0)
        {
            fprintf(stderr,"Amount must be positive on line number %d\n",num_items);
            exit(1);
        }
        //amount should not be more than or equal to 10 milliion
        if(temp->trans_amt>=10000000)
        {
            fprintf(stderr,"Amount cannot be greater than 10,000,000 on line number %d\n",num_items);
            exit(-1);
        }
        //amount should not be decimal number, greater than 1
        if(temp->trans_amt<1)
        {
            fprintf(stderr,"Amount must be greater than 1 on line number %d\n",num_items);
            exit(-1);
        }
        //Time should be before the current time, not some time in the future
        if(temp->trans_time>time(&c_time))
        {
            fprintf(stderr,"Invalid time stamp, time stamp cannot be ahead of current time on line number %d\n",num_items);
            exit(-1);
        }

        //printf("%s %d %lf %s\n",temp->trans_type,temp->trans_time,temp->trans_amt,temp->trans_descrp);

        //Append nodes to the list
        a=My402ListAppend(List,temp);
        if(a==0)
        {
            fprintf(stderr,"Error while Appending\n");
            exit(-1);
        }
        

    }

    BubbleSortForwardList(List,num_items);

    printf("+-----------------+--------------------------+----------------+----------------+\n");
    printf("|       Date      | Description              |         Amount |        Balance |\n");
    printf("+-----------------+--------------------------+----------------+----------------+\n");

    elem=My402ListFirst(List);
    for(i=My402ListLength(List);i>0;i--)
    {
        temp2=(trans*)(elem->obj);
        raw=temp2->trans_time;
        strcpy(ch,ctime(&raw));
        strcpy(ch,formattime(ch));
        
        strcpy(description,truncatespaces(temp2->trans_descrp));
        //strcpy(temp->trans_descrp,description);

        /*if(strlen(description)==0)
        {
            fprintf(stderr,"description must contain some data\n");
            exit(-1);
        }
        */
        strcpy(c,convstr(c,temp2->trans_amt));
        strcpy(c1,Balance(c1,temp2->trans_amt,temp2->trans_type));

       
        if((strcmp(temp2->trans_type,"+")==0) && glo_balance>0)
            printf("| %s | %-24s |  %12s  |  %12s  |\n",ch,description,c,c1);
        else if((strcmp(temp2->trans_type,"-")==0) && glo_balance>0)
            printf("| %s | %-24s | (%12s) |  %12s  |\n",ch,description,c,c1);
        else if((strcmp(temp2->trans_type,"+")==0) && glo_balance<0)
            printf("| %s | %-24s |  %12s  | (%12s) |\n",ch,description,c,c1);
        else
            printf("| %s | %-24s | (%12s) | (%12s) |\n",ch,description,c,c1);
        
        elem=My402ListNext(List,elem);
    }

    printf("+-----------------+--------------------------+----------------+----------------+\n");


    return(0);
}

