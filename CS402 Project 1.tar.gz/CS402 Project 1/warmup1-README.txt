Documentation for Warmup Assignment 1
=====================================

+-------+
| BUILD |
+-------+

Comments: Type "make" to compile the program.

	

+-----------------+
| SKIP (Optional) |
+-----------------+

Is there any tests in the standard test suite that you know that it's not working and you don't want the grader to run it at all so you won't get extra deductions, please list them here.  (Of course, if the grader won't run these tests, you will not get plus points for them.)

All test cases are passing.
 
+---------+
| GRADING |
+---------+

(A) Doubly-linked Circular List : 40 out of 40 pts

(B.1) Sort (file) : 30 out of 30 pts
(B.2) Sort (stdin) : 30 out of 30 pts

Missing required section(s) in README file : Nothing is missing in the required section.
Cannot compile : (All are compiling )
Compiler warnings : (There are no warnings)
"make clean" : (Included in makefile)
Segmentation faults : (No segmentation faults encountered).
Separate compilation : (Yes)
Malformed input : (For Malformed inputs,error message is displayed and usage information is mentioned).
Too slow : (No).
Bad commandline : Bad command lines have been handled with appropriate messages.
Did not use My402List and My402ListElem to implement "sort" in (B) : My402List and My402ListElem are used to implement sort in my program.

+------+
| BUGS |
+------+

Comments: (There are no bugs)

+------------------+
| OTHER (Optional) |
+------------------+

Comments on design decisions: No 
Comments on deviation from spec: No
