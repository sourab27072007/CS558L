#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#define PORT "23792"

void error(char *msg)
{
	perror(msg);
	exit(0);
}

int main(int argc, char *argv[])
{
	FILE *fp;
	int sockfd, portno;
	struct sockaddr_in serv_addr;
	struct hostent *server;
	char c[1024],copy[1024];
	char *lines[1000];
	int n=0,num=0,len=0,m=0;
	int i=0,k=0,t=0;
	char buffer[1024];

	if(argc<2)
	{
		fprintf(stderr,"usage %s hostname port\n", argv[0]);
		exit(0);
	}

	portno = atoi(PORT);

	sockfd = socket(AF_INET,SOCK_STREAM,0);

	if(sockfd<0)
	{
		error("ERROR opening socket");
	}
	printf("The client is up and running \n");

	server = gethostbyname("localhost");
	
	if (server == NULL)
	{
		fprintf(stderr,"ERROR, no such host\n");
		exit(0);
	}

	bzero((char *) &serv_addr, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;

	bcopy((char *)server->h_addr,(char *)&serv_addr.sin_addr.s_addr,server->h_length);

	serv_addr.sin_port =htons(portno);

	//Connect to Edge server on Port 23792

	if (connect(sockfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr))<0)
	{
		error("ERROR connecting");
	}
	
	strcpy(c,"");
	strcpy(buffer,"");
	strcpy(copy,"");

		i=0;
		n=0;
		num=0;
		m=0;
		k=0;
		fp=fopen(argv[1],"r");
		
		//Reading data from the file to a character array
		if(fp!=NULL)
		{
			while(fgets(buffer,256,fp)>0) //http://stackoverflow.com/questions/2001626/fgets-function-in-c
			{
				
				strcat(c,buffer);
				
			}

			//Send data to Edge server
			send(sockfd,c,1024,0);
			n=strlen(c);
			c[n]='\0';

			//Count Number of lines of data in the file
			m=strlen(c);
			strcpy(copy,c);
				for(i=0;i<m;i++)
					{
						if(copy[i]=='\n')
							if (copy[i+1]!='\n' )
								k++;
					}

			
			printf("The client has successfully finished sending %d lines to the edge server\n",k);

			strcpy(buffer,"");

			//Receive data from the edge server
			len=recv(sockfd,buffer,256,0);
			buffer[len]='\0';

			printf("The client has successfully finished receiving all computation results from the edge server\n");

			printf("The final computation results are:\n%s",buffer);
			
		}
		
	fclose(fp);

	close(sockfd);
	return 0;
}