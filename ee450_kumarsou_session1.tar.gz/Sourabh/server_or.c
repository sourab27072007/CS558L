#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#define UPORT2 "21792"
#define UPORT3 "24792"

void error(char *msg)
{
	perror(msg);
	exit(0);
}

int main()
{
	int sock, sock1, length, fromlen, i,n,n1,n2,k,t, count;
	struct sockaddr_in server;
	struct  sockaddr_in from;
	char buf[1024],copy[1024],ch[1024];
	char op[25],in1[25],in2[25],c[25],ans[25],temp[25],input1[25],input2[25];


	sock= socket(AF_INET, SOCK_DGRAM, 0);
	sock1=socket(AF_INET,SOCK_DGRAM,0);

	if(sock<0)
	{
		error("Error in opening socket of OR server.\n");
	}

	length=sizeof(server);
	bzero(&server,length);

	from.sin_family=AF_INET;
	from.sin_addr.s_addr=inet_addr("127.0.0.1");
	from.sin_port=htons(atoi(UPORT2));

	server.sin_family=AF_INET;
	server.sin_addr.s_addr=inet_addr("127.0.0.1");
	server.sin_port=htons(atoi(UPORT3));

	//Binding to the UDP port 21792 for receiving data from the edge server
	if(bind(sock,(struct  sockaddr *)&from,length)<0)
	{
		error("Error in binding server OR socket");
	}

	fromlen=sizeof(struct sockaddr_in);

	count=0;

	printf("The Server OR is up & running using UDP on port %d\n",atoi(UPORT2));
	printf("The Server OR start receiving lines from the edge server for OR computation. The computation results are:\n");


	while(1)
	{
		memset(c,0,strlen(c));
		memset(ans,0,strlen(ans));
		memset(temp,0,strlen(temp));
		memset(buf,0,strlen(buf));
		memset(copy,0,strlen(copy));
		memset(ch,0,strlen(ch));
		memset(in1,0,strlen(in1));
		memset(in2,0,strlen(in2));
		memset(input1,0,strlen(input1));
		memset(input2,0,strlen(input2));


		strcpy(copy,"");
		strcpy(buf,"");
		n=0;
		n1=0;

		//Receive data from the edge server on UDP port 21792
		n=recvfrom(sock,buf, 1024,0,(struct sockaddr *)&from,&fromlen);

		if(n<0)
		{
			error("recvfrom");
		}

		//Checking to see if the data is greater than 3 bytes, to confirm that it is not the End of the data being sent by the edge server.
		if(n>3)
		{
			strcpy(copy,buf);
			strcpy(ch,buf);
			buf[n]='\0';
			//printf("%s\n",copy);
			count++;
			
			//Obtaining the operands from the data sent by the edge server
			//http://en.cppreference.com/w/c/string/byte/strtok
			strcpy(op,strtok(ch,","));
			strcpy(in1,strtok(NULL,","));
			strcpy(in2,strtok(NULL,","));

			strcpy(input1,in1);
			strcpy(input2,in2);


			//Performing padding of zeros to the smaller operand
			i=0;
			if(strlen(in1)<strlen(in2))
			{
				
				for(i=0;i<strlen(in2)-strlen(in1);i++)
					strcat(c,"0");
				strcat(c,in1);
				strcpy(in1,c);
			}
			else
			{
				
				for(i=0;i<strlen(in1)-strlen(in2);i++)
					strcat(c,"0");
				strcat(c,in2);
				
				strcpy(in2,c);
			}

			//Performing OR operation on the operands obtained after padding
			k=strlen(in1);
			for(i=0;i<k;i++)
			{
				if(in1[i]=='0'&& in2[i]=='0')
					ans[i]='0';
				else
					ans[i]='1';
			}
			
			//Checking the number of zeros in the answer, before the first 1
			t=0;
			for(i=0;i<strlen(ans);i++)
			{
				if(ans[i]!='0')
					break;
			}

			//Removing the extra zeros in the answer, before the first 1
			t=i;
			if(i<strlen(ans))
			{
				for(k=0;k<strlen(ans)-i;k++)
				{
					temp[k]=ans[t];
					t++;
				}

			}
			else
				strcpy(temp,"0");

			printf("%s or %s = %s",input1,input2,temp);

			//Send computation result to the edge server on UDP port 24792
			n1=sendto(sock1,temp,strlen(temp),0,(struct sockaddr *)&server,length);
			
		}

		//If end message is received, go ahead & print the number of lines sent by edge to OR server
		else
		{
			
			printf("The Server OR has successfully received %d lines from the edge server and finished all OR computations\n",count);
			printf("The Server OR has successfully finished sending all computation results to the edge server\n");
			count=0;

		}
		printf("\n");
		
	}

	close(sock);
	close(sock1);
}