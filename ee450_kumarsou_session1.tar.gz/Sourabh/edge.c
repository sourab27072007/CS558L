#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#define PORT "23792"
#define UPORT1 "21792"
#define UPORT2 "22792"
#define UPORT3 "24792"

#define MAX_DATA 1024

void error(char *msg)
{
	perror(msg);
	exit(1);
}

int main()
{
	int sockfd,newsockfd, usockfd, u2sockfd, usockfd1; 
	int clilen,and_len,or_len,length;
	int portno, portno1, portno2,portno3;
	char buffer[1024],copy[1024];
	char temp[150],temp1[150],temp2[1024],ch[1024],c[1024];
	char *line[150],temp3[150][150];
	struct sockaddr_in serv_addr, cli_addr;
	struct sockaddr_in serv_addr_and,serv_addr_or,from;
	struct hostent *server;
	int n,i,m,k,c1,c2;
	char s1[100];
	int n1,n2,n3;
	char op[25],in1[25],in2[25];
	/*if(argc<2)
	{
		printf("Error, no port provided\n");
		exit(1);
	}*/
	sockfd=socket(AF_INET, SOCK_STREAM,0);
	usockfd= socket(AF_INET, SOCK_DGRAM,0);
	u2sockfd=socket(AF_INET, SOCK_DGRAM,0);

	usockfd1=socket(AF_INET,SOCK_DGRAM,0);


	if(sockfd<0)
	{
		error("ERROR opening the TCP socket\n");
	}

	if(usockfd<0)
	{
		error("ERROR opening the UDP socket of AND server\n");
	}

	bzero((char *) &serv_addr, sizeof(serv_addr));

	if(u2sockfd<0)
	{
		error("ERROR opening the UDP socket of OR socket\n");
	}

	if(usockfd1<0)
	{
		error("ERROR opening the UDP socket\n");
	}

	portno = atoi(PORT);
	portno1 = atoi(UPORT1);
	portno2 = atoi(UPORT2);
	portno3 = atoi(UPORT3);

	serv_addr.sin_family=AF_INET;
	serv_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
	serv_addr.sin_port=htons(portno);

	serv_addr_and.sin_family=AF_INET;
	serv_addr_and.sin_addr.s_addr=inet_addr("127.0.0.1");
	serv_addr_and.sin_port=htons(portno2);

	serv_addr_or.sin_family=AF_INET;
	serv_addr_or.sin_addr.s_addr=inet_addr("127.0.0.1");
	serv_addr_or.sin_port=htons(portno1);

	from.sin_family=AF_INET;
	from.sin_addr.s_addr=inet_addr("127.0.0.1");
	from.sin_port=htons(portno3);


	server = gethostbyname("localhost");
	bcopy((char *)server->h_addr,(char *)&serv_addr.sin_addr.s_addr,server->h_length);


//Binding the TCP socket to the port 23792
	if(bind(sockfd, (struct sockaddr *) &serv_addr,sizeof(serv_addr))<0)
	{
		error("Error on binding\n");
	}

	printf("The edge server is up and running\n");

//Binding the UDP socket to the port 24792
	if(bind(usockfd1, (struct sockaddr *) &from,sizeof(from))<0)
	{
		error("Error on binding\n");
	}


//Listening on port 23792 for any connects
	listen(sockfd,10);

	clilen=sizeof(cli_addr);

	length=sizeof(from);

	and_len=sizeof(serv_addr_and);
	or_len=sizeof(serv_addr_or);

	while(1)
	{
		i=0;
		m=0;
		k=0;
		c1=0;
		c2=0;
		n=1;
		n2=0;
		n3=0;

		memset(ch,0,strlen(ch));
		memset(buffer,0,strlen(buffer));
		memset(copy,0,strlen(copy));
		memset(temp,0,strlen(temp));
		memset(temp1,0,strlen(temp1));
		memset(temp2,0,strlen(temp2));

//Accept the client that is connecting to the server
		newsockfd=accept(sockfd,(struct sockaddr *) &cli_addr, &clilen);

		if(newsockfd<0)
		{
			error("Error on accept\n");
		}
		bzero(buffer,1024);

		//Receive data from the client
		//https://www.youtube.com/watch?v=FRm9nk9ooC8
			n=recv(newsockfd,buffer, MAX_DATA,0);
			buffer[n]='\0';
			
			m=strlen(buffer);
			strcpy(copy,buffer);

			//Count number of lines in the data that the client has sent
			for(i=0;i<m;i++)
			{
				if(copy[i]=='\n')
					if (copy[i+1]!='\n' )
						k++;
			}

			//Seperate each line in the data sent using strtok function
			//http://en.cppreference.com/w/c/string/byte/strtok
			line[0]=strtok(copy,"\n");
			
			for(i=1;i<k;i++)
			{
				//http://en.cppreference.com/w/c/string/byte/strtok
				
				line[i]=strtok(NULL,"\n");	
				
				
			}
			
			printf("The edge server has received %d lines from the client using TCP over port %d\n",k,portno);


			//Sending the data to the OR server and the AND server, based on the data recieved from the client

			for(i=0;i<k;i++)
			{
				n1=0;
				strcpy(temp,line[i]);
				//Checking if the first operand in a line is an AND or OR, extracting the data using strtok function
				//http://en.cppreference.com/w/c/string/byte/strtok
				strcpy(temp1,strtok(temp,","));

				if(strcmp(temp1,"and")==0)
				{
					memset(temp2,0,strlen(temp2));
					//printf("Sending %s\n",line[i]);

					//Send line to backend server AND to UDP port 22792
					n=sendto(usockfd,line[i],strlen(line[i]),0,(struct sockaddr *)&serv_addr_and,and_len);
					c1++;

					//Receive computation results from the backend server AND on UDP port 24792
					n1=recvfrom(usockfd1,temp2,100,0,(struct sockaddr *)&from,&length);
					//printf("Received Value:%d\n",n1);
					
					strcat(ch,temp2);
					strcat(ch,"\n");
					strcpy(temp3[i],temp2);
					temp2[n1]='\0';
					//printf("Line received is %s\n",temp2);
					
				}

				else
				{
					memset(temp2,0,strlen(temp2));

					//Send line to backend server OR to UDP port 21792
					n2=sendto(u2sockfd,line[i],strlen(line[i]),0,(struct sockaddr *)&serv_addr_or,or_len);
					c2++;

					//Receive computation results from the backend server OR on UDP port 24792
					n1=recvfrom(usockfd1,temp2,100,0,(struct sockaddr *)&from,&length);
					strcat(ch,temp2);
					strcat(ch,"\n");
					strcpy(temp3[i],temp2);
					temp2[n1]='\0';
					//printf("Line received is %s\n",temp2);
					//printf("\n");
				}
			}

			n3=strlen(ch);
			//ch[n3]='\0';

			printf("The edge server has successfully sent %d lines to Backend-server OR\n",c2);
			printf("The edge server has successfully sent %d lines to Backend-server AND\n",c1);

			printf("The edge server start receiving the computation results from Backend-server OR and Backend-server AND using UDP over port %d\n",portno3);
			printf("The computation results are:\n");


			//Extracting operands from each line using strtok function for printing
			for(i=0;i<k;i++)
			{
				memset(c,0,strlen(c));
				strcpy(c,line[i]);
				strcpy(op,strtok(c,","));
				strcpy(in1,strtok(NULL,","));
				strcpy(in2,strtok(NULL,","));
				if(strcmp(op,"and")==0)
					printf("%s and %s = %s\n",in1,in2,temp3[i]);
				else
					printf("%s or %s = %s\n",in1,in2,temp3[i]);
			}	


			strcpy(s1,"end");

			//Send special message "end" to represent the end of data from edge to the AND and OR backend servers.
			
			n=sendto(usockfd,s1,strlen(s1),0,(struct sockaddr *)&serv_addr_and,and_len);
			
			n=sendto(u2sockfd,s1,strlen(s1),0,(struct sockaddr *)&serv_addr_or,or_len);

			printf("The edge server has successfully finished receiving all computation results from Backend-server OR and Backend-server AND\n");

			//Send the computation results received from the backend servers in order to the client, using TCP port 23792
			send(newsockfd,ch,1024,0);

			printf("The edge server has successfully finished Sending all computation results to the client.\n");
		
	}
		close(newsockfd);
		close(usockfd);
		close(usockfd1);
		close(u2sockfd);
		return 0;

}