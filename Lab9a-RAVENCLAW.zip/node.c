#include <arpa/inet.h>
#include <linux/if_packet.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <net/if.h>
#include <netinet/ether.h>
#include <netinet/ip.h>
#include <netinet/in.h>
#include <unistd.h>
#include <time.h>
#include <sys/time.h>


#define MY_DEST_MAC0	0x00
#define MY_DEST_MAC1	0x00//0x11
#define MY_DEST_MAC2	0x00//0x43
#define MY_DEST_MAC3	0x00//0xd6
#define MY_DEST_MAC4	0x00//0xcf
#define MY_DEST_MAC5	0x00//0xcc
#define PROTO_ARP 0x0806

#define DEFAULT_IF	"lo"//"eth3"//"eth0"//"enp0s3"//"eth0"
#define BUF_SIZ		1500
#define MAC_LENGTH 6
#define IPV4_LENGTH 2

/*ARP constants*/
#define ARP_REQUEST 1
#define ARP_REPLY 1


struct arp_header
{
	unsigned short opcode;
	unsigned char sender_mac[MAC_LENGTH];
	unsigned char sender_ip[IPV4_LENGTH];
	unsigned char target_mac[MAC_LENGTH];
	unsigned char target_ip[IPV4_LENGTH];
};

struct ipheader
{
	u_int16_t daddr;
	u_int16_t saddr ;
	u_int16_t check;
	u_int8_t ttl;
	u_int8_t dummy;
};

void get_index_of_interface(int *hw_index,char*ethname)
{
	struct ifconf ifc;
	struct ifreq ifr[10],if_ip;
	struct ifreq ifr_index;
	int sd,ifc_num,i;
	struct sockaddr_in ipaddr;
	char *eth_name = "eth";
	char *ip_address = "10";

	sd = socket(PF_INET, SOCK_DGRAM, 0);
	if (sd > 0)
	{
		ifc.ifc_len = sizeof(ifr);
		ifc.ifc_req = ifr;

		if (ioctl(sd, SIOCGIFCONF, (char*)&ifc)<0)
		{
			printf("ioctl lookup failed\n");
			exit(0);
		}
		ifc_num = ifc.ifc_len / sizeof(struct ifreq);

		for (i = 0; i < ifc_num; i++)
		{

			if ((ifr[i]).ifr_addr.sa_family != AF_INET)
			{
				continue;
			}
			if( !strncmp((ifr[i]).ifr_name,eth_name,3))
			{

				strcpy(ifr_index.ifr_name,(ifr[i]).ifr_name);
				memset(&if_ip,0,sizeof(if_ip));
				strncpy(if_ip.ifr_name,(ifr[i]).ifr_name,IFNAMSIZ); //giving name of Interface
				if((ioctl(sd,SIOCGIFADDR,&if_ip))<0)
					printf("error in mac ioctl reading\n");//getting MAC Address
				memset(&ipaddr,0,sizeof(ipaddr));
				ipaddr.sin_addr = (((struct sockaddr_in *)&(if_ip.ifr_addr))->sin_addr);
				if(!strncmp(inet_ntoa(ipaddr.sin_addr),ip_address,2))
				{
					if (ioctl(sd, SIOCGIFINDEX, &ifr_index) == -1)
					{
						perror("SIOCGIFINDEX");
						exit(1);
					}
					*hw_index= ifr_index.ifr_ifindex;
					strcpy(ethname,(ifr[i]).ifr_name);
					break;
				}
			}

		}
	}
	close(sd);
}
static
u_short calc_ip_checksum(const u_char* Buffer) {
	struct ipheader *iph = (struct ipheader*)(Buffer + sizeof(struct ethhdr));
	unsigned int sum = 0;

	iph->dummy=0;
	/*    printf("\n ttl inside fn %d",iph->ttl);*/
	sum += (((u_short)iph->ttl) << 8) | (u_short)iph->dummy;
	sum += ntohs((iph->saddr) & 0xff) ;
	sum += ntohs((iph->daddr) & 0xff);

	int chk = (((u_short)(sum >> 16)) & 0xf) + ((u_short)(sum) & 0xffff);
	return ~((u_short)chk);

}

static
double GetCurrentTime()
{
  struct timeval t;
  if(gettimeofday(&t, NULL) == -1)
    {
      perror("time");
      exit(1);
    }
  return((t.tv_sec)*1000.0 + (t.tv_usec)/1000.0);

}

int main(int argc, char *argv[])
{
	int sockfd_s;
	struct ifreq if_mac;
	int index=0;
	uint8_t buffer[BUF_SIZ];
	struct ethhdr *eh_s;
	struct ethhdr *my_eth;
	char buf[100];
	memset(buf,'\0',100);
	my_eth = (struct ethhdr*)buf;

	struct sockaddr_ll socket_address,bind_addr;
	struct arp_header *arp_req;
	struct ipheader *ip;
	struct sockaddr saddr;
	struct sockaddr_in dest;
	unsigned int saddr_len = sizeof(saddr);
	unsigned short received_checksum;
	unsigned char *data_segment;
	struct ipheader *ip_hd;
	time_t t;
	unsigned char *str = "done";
	int flag = 0;
	double start_time,stop_time,throughput;


	/* Get interface name*/
	char eth_name[10];
	memset(eth_name,'\0',10);
	int hw_name;
	get_index_of_interface(&hw_name,eth_name);

	/* Open RAW socket to send on */
	if ((sockfd_s = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_IP))) < 0) {
		perror("socket");
	}
	int sockfd_send;
	if ((sockfd_send = socket(AF_PACKET, SOCK_RAW,  htons(ETH_P_IP))) < 0) {
		perror("socket");
	}

	/*bind the socket to the interface*/
	bind_addr.sll_family = AF_PACKET;
	bind_addr.sll_ifindex = hw_name;
	bind_addr.sll_protocol = htons(ETH_P_IP);

	if((bind(sockfd_s, (struct sockaddr *)&bind_addr, sizeof(bind_addr)))== -1)
	{
		perror("Error binding raw socket to interface\n");
		exit(1);
	}


	/* Get the MAC address */
	memset(&if_mac, 0, sizeof(struct ifreq));
	strncpy(if_mac.ifr_name, eth_name, 4);
	if (ioctl(sockfd_s, SIOCGIFHWADDR, &if_mac) < 0)
		perror("SIOCGIFHWADDR");

	int i=0,buflen=-1;
	for(i=0;i<6;i++)
	{
		my_eth->h_source[i] = (unsigned char)(if_mac.ifr_hwaddr.sa_data[i]);
	}

	while(1)
	{
		/* Construct the Ethernet header */
		memset(buffer, 0, BUF_SIZ);
		/*receive packets */
		buflen=recvfrom(sockfd_s,buffer,1500,0,(struct sockaddr *)&saddr,(socklen_t *)&saddr_len);
		if(buflen<0)
		{
			printf("error in reading recvfrom function\n");
			exit(1);
		}

		eh_s = (struct ethhdr *) buffer;
		arp_req = (struct arp_header *)(buffer+sizeof(struct ethhdr));

		if(arp_req->opcode == htons(ARP_REQUEST))
		{
			for(i=0;i<6;i++)
				my_eth->h_dest[i] = eh_s->h_source[i];

			for(i =0;i<6;i++)
			{
				eh_s->h_dest[i] = eh_s->h_source[i];
				eh_s->h_source[i] = my_eth->h_source[i];
			}
			eh_s->h_proto = htons(ETH_P_IP);

			for(index=0;index<6;index++)
			{
				arp_req->target_mac[index] = eh_s->h_dest[index];
				arp_req->sender_mac[index] = my_eth->h_source[index];
			}
			arp_req->opcode = htons(ARP_REPLY);
			arp_req->target_ip[1]=arp_req->sender_ip[1];
			arp_req->sender_ip[1]=atoi(argv[1]);			/* Index of the network device */
			memset(&socket_address,'\0',sizeof(socket_address));
			socket_address.sll_ifindex = hw_name;
			/* Address length*/
			socket_address.sll_halen = ETH_ALEN;

			/* Destination MAC */
			for(i=0;i<6;i++)
				socket_address.sll_addr[i] = eh_s->h_source[i];
			/* Send packet */
			if (sendto(sockfd_send, buffer, BUF_SIZ, 0, (struct sockaddr*)&socket_address, sizeof(struct sockaddr_ll)) < 0)
				perror("sendto");
			else
				printf("Packet sent successfully\n");

			break;
		}
	}
	if(argc > 4)
	{
		usleep(1000000);


		memset(buffer,'\0',BUF_SIZ);
		eh_s = (struct ethhdr*)buffer;
		ip_hd = (struct ipheader*)(buffer+sizeof(struct ethhdr));
		data_segment = buffer+sizeof(struct ethhdr)+sizeof(struct ipheader);

		/*fill the packet*/
		srand((unsigned) time(&t));

		for(i=0;i<atoi(argv[3]);i++)
		{
			data_segment[i] == (uint8_t)(rand()%100);
		}
		/*construct the ether head*/
		for(i=0;i<6;i++)
		{
			eh_s->h_dest[i] = my_eth->h_dest[i];
			eh_s->h_source[i] = my_eth->h_source[i];
		}
		eh_s->h_proto = htons(ETH_P_IP);

		/*construct the IP header*/
		ip_hd->saddr = atoi(argv[1]);
		ip_hd->daddr = atoi(argv[2]);
		ip_hd->ttl = 64;
		ip_hd->check = htons(calc_ip_checksum(buffer));

		/*fill the data*/


		/* Index of the network device */
		memset(&socket_address,'\0',sizeof(socket_address));
		socket_address.sll_ifindex = hw_name;
		/* Address length*/
		socket_address.sll_halen = ETH_ALEN;

		/* Destination MAC */
		for(i=0;i<6;i++)
			socket_address.sll_addr[i] = eh_s->h_source[i];
		/* Send packet */
		for(i=0;i<atoi(argv[4]);i++)
		{
			if (sendto(sockfd_send, buffer, BUF_SIZ, 0, (struct sockaddr*)&socket_address, sizeof(struct sockaddr_ll)) < 0)
				perror("sendto");
			else
				printf("Transmitted Packet\n");
			//usleep(1);
		}
		memset(data_segment, '\0',(BUF_SIZ-sizeof(struct ethhdr)-sizeof(struct ipheader)));
		strncpy(data_segment,"done",4);
		/*for(i=0;i<5;i++)
		{*/
			if (sendto(sockfd_send, buffer, BUF_SIZ, 0, (struct sockaddr*)&socket_address, sizeof(struct sockaddr_ll)) < 0)
				perror("sendto");
			else
				printf("Transmitted the last packet:%d\n",i);
	/*		usleep(1000);
		}*/
		close(sockfd_send);

	}
	else
	{
		i = 0;
		while(1)
		{
			start_time = GetCurrentTime();
			memset(buffer, 0, BUF_SIZ);
			/*receive packets */
			buflen=recvfrom(sockfd_s,buffer,BUF_SIZ,0,(struct sockaddr *)&saddr,(socklen_t *)&saddr_len);
			if(buflen<0)
			{
				printf("error in reading recvfrom function\n");
				exit(1);
			}

			eh_s = (struct ethhdr *) buffer;
			ip_hd = (struct ipheader*)(buffer+sizeof(struct ethhdr));
			data_segment = buffer+sizeof(struct ethhdr)+sizeof(struct ipheader);
			received_checksum = htons(calc_ip_checksum(buffer));

			if(received_checksum == ip_hd->check)
			{
				/*				printf("%s\n",data_segment);*/
				if(!strncmp(data_segment,str,4))
				{
					flag++;
					if(flag == 2)
					{
						close(sockfd_s);
						printf("All packets received\n");
						stop_time = GetCurrentTime();
						break;
					}
				}
				printf("Received Packet:%d\n",i++);
			}
			else
			{
				printf("Checksum Error...\nExiting...\n");
				/*close(sockfd_s);*/
				/*continue;*/
			}
		}
	throughput = (atoi(argv[2])*atoi(argv[3])*8)/((stop_time-start_time)*1000);
	printf("Throughput:%0.2f Mbps\n",throughput);
	}
	return 0;
}