/******************************************************************************/
/* Important Summer 2017 CSCI 402 usage information:                          */
/*                                                                            */
/* This fils is part of CSCI 402 kernel programming assignments at USC.       */
/*         53616c7465645f5f2e8d450c0c5851acd538befe33744efca0f1c4f9fb5f       */
/*         3c8feabc561a99e53d4d21951738da923cd1c7bbd11b30a1afb11172f80b       */
/*         984b1acfbbf8fae6ea57e0583d2610a618379293cb1de8e1e9d07e6287e8       */
/*         de7e82f3d48866aa2009b599e92c852f7dbf7a6e573f1c7228ca34b9f368       */
/*         faaef0c0fcf294cb                                                   */
/* Please understand that you are NOT permitted to distribute or publically   */
/*         display a copy of this file (or ANY PART of it) for any reason.    */
/* If anyone (including your prospective employer) asks you to post the code, */
/*         you must inform them that you do NOT have permissions to do so.    */
/* You are also NOT permitted to remove or alter this comment block.          */
/* If this comment block is removed or altered in a submitted file, 20 points */
/*         will be deducted.                                                  */
/******************************************************************************/
    
#include "kernel.h"
#include "config.h"
#include "globals.h"
#include "errno.h"
    
#include "util/debug.h"
#include "util/list.h"
#include "util/string.h"
#include "util/printf.h"
    
#include "proc/kthread.h"
#include "proc/proc.h"
#include "proc/sched.h"
#include "proc/proc.h"
    
#include "mm/slab.h"
#include "mm/page.h"
#include "mm/mmobj.h"
#include "mm/mm.h"
#include "mm/mman.h"
    
#include "vm/vmmap.h"
    
#include "fs/vfs.h"
#include "fs/vfs_syscall.h"
#include "fs/vnode.h"
#include "fs/file.h"
    
proc_t *curproc = NULL; /* global */
static slab_allocator_t *proc_allocator = NULL;
    
static list_t _proc_list;
static proc_t *proc_initproc = NULL; /* Pointer to the init process (PID 1) */
    
void
proc_init()
{
        list_init(&_proc_list);
        proc_allocator = slab_allocator_create("proc", sizeof(proc_t));
        KASSERT(proc_allocator != NULL);
}
    
proc_t *
proc_lookup(int pid)
{
        proc_t *p;
        list_iterate_begin(&_proc_list, p, proc_t, p_list_link) {
                if (p->p_pid == pid) {
                        return p;
                }
        } list_iterate_end();
        return NULL;
}
    
list_t *
proc_list()
{
        return &_proc_list;
}
    
static pid_t next_pid = 0;
    
/**
 * Returns the next available PID.
 *
 * Note: Where n is the number of running processes, this algorithm is
 * worst case O(n^2). As long as PIDs never wrap around it is O(n).
 *
 * @return the next available PID
 */
static int
_proc_getid()
{
        proc_t *p;
        pid_t pid = next_pid;
        while (1) {
failed:
                list_iterate_begin(&_proc_list, p, proc_t, p_list_link) {
                        if (p->p_pid == pid) {
                                if ((pid = (pid + 1) % PROC_MAX_COUNT) == next_pid) {
                                        return -1;
                                } else {
                                        goto failed;
                                }
                        }
                } list_iterate_end();
                next_pid = (pid + 1) % PROC_MAX_COUNT;
                return pid;
        }
}
    
/*
The lifecycle of threads and processes is relatively straightforward. When
a process is created, a thread should be added to it and the process should be
made runnable by adding its thread to the run queue. If a process exits and
it still has child processes, it should reassign those children to the init process,
which, after performing some system setup, will sit in a loop collecting orphaned
processes. When a thread attempts to exit the current process, the process code
must cancel any other threads in the same process (and join with them, if there
are multiple) so that they can do any cleanup necessary for their current tasks.
Once each thread finishes cleaning up its current task, it makes a call to the
process code to indicate it is exiting so that the process can do any final cleanup
on the thread data structure.
*/
    
    
/*
 * The new process, although it isn't really running since it has no
 * threads, should be in the PROC_RUNNING state.
 *
 * Don't forget to set proc_initproc when you create the init
 * process. You will need to be able to reference the init process
 * when reparenting processes to the init process.
 */
proc_t *
proc_create(char *name)
{
    pid_t pid = 0;
    proc_t *p = NULL;
    int i = 0;
    int fd = 0;
      
    pid = _proc_getid(); /* Get next available pid */
        
    KASSERT(PID_IDLE != pid || list_empty(&_proc_list)); /* pid can only be PID_IDLE if this is the first process */
    KASSERT(PID_INIT != pid || PID_IDLE == curproc->p_pid); /* pid can only be PID_INIT when creating from idle process */
    /*dbg(DBG_PRINT, "(GRADING1A 2.a)\n"); KASSERT - GRADING1A 2.a */
        
    p = (proc_t*)slab_obj_alloc(proc_allocator); /* Allocate slab for process */
       
    p->p_pid = pid; /* Set process id to next available pid */
    strcpy(p->p_comm, name); /* Set process name to input name */
    p->p_status=0;
    p->p_state = PROC_RUNNING; /* Set process state to PROC_RUNNING */
    p->p_pagedir = pt_create_pagedir();
      
    /* VFS */
    for(i = 0; i < NFILES; i++)
    {
        p->p_files[i] = NULL;
       /* dbg(DBG_PRINT, "(GRADING2B)\n");*/
    }
    /*p->p_cwd = vfs_root_vn;
    if(p->p_pid>3)
    {
        vref(p->p_cwd);
        dbg(DBG_PRINT, "(GRADING2B)\n");
    }*/
    if(p->p_pid != PID_IDLE && p->p_pid != PID_INIT)
    {
        p->p_cwd = curproc->p_cwd;
    }
 
    #ifdef __VM__
    p->p_vmmap = vmmap_create();
    p->p_vmmap->vmm_proc = p;
    p->p_start_brk = NULL;
    p->p_brk = NULL;
     
    if (p->p_vmmap == NULL){
        if (p->p_cwd != NULL){
            dbg(DBG_PRINT,"(GRADING3D 5)\n");
            vput(p->p_cwd);
        }
 
        if (list_link_is_linked(&p->p_child_link)){
            dbg(DBG_PRINT,"(GRADING3D 5)\n");
            list_remove(&p->p_child_link);
        }
 
        pt_destroy_pagedir(p->p_pagedir);
        list_remove(&p->p_list_link);
        slab_obj_free(proc_allocator, p);
        dbg(DBG_PRINT,"(GRADING3D 5)\n");
        return NULL;
    }
 
     
#endif
    /*if (p->p_pid > 3){
        p->p_cwd = p->p_pproc->p_cwd;
        vref(p->p_cwd);
    } else {
         bad, but we'll catch this later with a KASSERT if it doesn't
         * get set later 
        p->p_cwd = NULL;
    }*/
      
 
    /* VFS */
        
    list_init(&p->p_threads); /* Process threads list */
    list_init(&p->p_children); /* Process children list */
    list_link_init(&p->p_list_link); /* Process pool list link element */
    list_link_init(&p->p_child_link); /* Parent process list link element */
    sched_queue_init(&p->p_wait); /* Wait queue */
        
    list_insert_tail(&_proc_list,&p->p_list_link); /* Put this process on the process pool list */
        
    if(p->p_pid == PID_IDLE)
    {
        p->p_pproc = NULL; /* IDLE process has no parent */
    }
    else if(p->p_pid == PID_INIT) /* Allocating for init process */
    {
        proc_initproc = p; /* Set proc_initproc */
        p->p_pproc = curproc;
        list_insert_tail(&curproc->p_children, &p->p_child_link);
    }
    else
    {
        p->p_pproc = curproc;
        list_insert_tail(&curproc->p_children, &p->p_child_link);
    }
        
    /* Process threads initialized outside */
   /* dbg(DBG_PRINT,"(GRADING1C)\n");
    dbg(DBG_PRINT,"(GRADING2B)\n");*/
    return p;
}
    
/**
 * Cleans up as much as the process as can be done from within the
 * process. This involves:
 *    - Closing all open files (VFS)
 *    - Cleaning up VM mappings (VM)
 *    - Waking up its parent if it is waiting
 *    - Reparenting any children to the init process
 *    - Setting its status and state appropriately
 *
 * The parent will finish destroying the process within do_waitpid (make
 * sure you understand why it cannot be done here). Until the parent
 * finishes destroying it, the process is informally called a 'zombie'
 * process.
 *
 * This is also where any children of the current process should be
 * reparented to the init process (unless, of course, the current
 * process is the init process. However, the init process should not
 * have any children at the time it exits).
 *
 * Note: You do _NOT_ have to special case the idle process. It should
 * never exit this way.
 *
 * @param status the status to exit the process with
 */
void
proc_cleanup(int status)
{
    proc_t *kproc = NULL;
    kthread_t *kthr = NULL;
    int i = 0;
        
    KASSERT(NULL != proc_initproc); /* should have an "init" process */
    KASSERT(1 <= curproc->p_pid); /* this process should not be idle process */
    KASSERT(NULL != curproc->p_pproc); /* this process should have parent process */
    /*dbg(DBG_PRINT, "(GRADING1A 2.b)\n");  KASSERT - GRADING1A 2.b */
        
    /* Do NOT special case PID_IDLE process */
      
    /* VFS */
     
    for(i = 0; i < NFILES; i++)
    {
        if(curproc->p_files[i] != NULL)
        {
            do_close(i);
           /* dbg(DBG_PRINT, "(GRADING2B)\n");*/
        }
       /* dbg(DBG_PRINT, "(GRADING2B)\n");*/
    }
    if (curproc->p_pid != 2 /*&& curproc->p_pid != 3*/)
    {
        KASSERT(curproc->p_cwd != NULL && "cwd is null");
        vput(curproc->p_cwd);
        curproc->p_cwd = NULL;
    }
 
   /* if(curproc->p_cwd->vn_refcount!=0)
    {
        dbg(DBG_PRINT, "kkkkkkkkkkkkkkkkkkkkkkkkkk\n");
        vput(curproc->p_cwd);
        dbg(DBG_PRINT, "(GRADING2B)\n");
        curproc->p_cwd = NULL;
    }*/
     
    /* VFS */
      
    if(!sched_queue_empty(&curproc->p_pproc->p_wait)) /* If parent process is waiting */
    {
        sched_wakeup_on(&curproc->p_pproc->p_wait); /* Wakeup parent process */
    } 
    /* Child process reparenting */
    if(!list_empty(&curproc->p_children))
    {
        /*kproc & curproc are the same process, but kproc is supposed to be the child process of curproc*/
        list_iterate_begin(&curproc->p_children, kproc, proc_t, p_child_link) /* curproc->p_children traverse */
        {
            list_remove(&kproc->p_child_link);
            if(curproc->p_pid != PID_INIT)
            {
                kproc->p_pproc = proc_initproc;
                list_insert_tail(&proc_initproc->p_children,&kproc->p_child_link);
            }
        }
        list_iterate_end();
            
    }
     
    #ifdef __VM__
    vmmap_destroy(curproc->p_vmmap);
    #endif
     
    curproc->p_state = PROC_DEAD; /* Turn into zombie process */
    curproc->p_status = status; /* Set process exit status */
    sched_switch(); /* Run different thread */
     
    KASSERT(NULL != curproc->p_pproc); /* this process should have parent process */
   /* dbg(DBG_PRINT, "(GRADING1A 2.b)\n");  KASSERT - GRADING1A 2.b */
    /* Leave to parent process to complete process destruction */
}
    
/*
 * This has nothing to do with signals and kill(1).
 *
 * Calling this on the current process is equivalent to calling
 * do_exit().
 *
 * In Weenix, this is only called from proc_kill_all.
 */
void
proc_kill(proc_t *p, int status)
{
    kthread_t *kthr = NULL;
    proc_t *kproc = NULL;
        
    if(p == curproc) /* If called on current process, do_exit() */
    {
        do_exit(status); /* do_exit() */
    }
    else
    {
        /* Thread cancellation and joining */
        list_iterate_begin(&p->p_threads, kthr, kthread_t, kt_plink) /* p->pthreads traverse */
        {
                kthread_cancel(kthr, 0); /* Cancel this thread */
        }
        list_iterate_end();
            
        p->p_status = status; /* Set process exit status */
    }
    /*dbg(DBG_PRINT,"(GRADING1C 8)\n");*/
}
    
/*
 * Remember, proc_kill on the current process will _NOT_ return.
 * Don't kill direct children of the idle process.
 *
 * In Weenix, this is only called by sys_halt.
 */
void
proc_kill_all()
{
    proc_t *kproc;
    list_iterate_begin(&_proc_list, kproc, proc_t, p_list_link) /* p->pthreads traverse */
    {
        if(curproc != kproc)
        {
            if(kproc->p_pid != PID_IDLE && kproc->p_pproc->p_pid != PID_IDLE) /* If it is NOT IDLE process or child of IDLE process */
            {
                 dbg(DBG_PRINT,"(GRADING3D 5)\n");
                proc_kill(kproc,kproc->p_status); /* Kill process */
            }
        }
        
    }
    list_iterate_end();

     
 
   /* dbg(DBG_PRINT,"(GRADING1C 9)\n");*/
}
    
/*
 * This function is only called from kthread_exit.
 *
 * Unless you are implementing MTP, this just means that the process
 * needs to be cleaned up and a new thread needs to be scheduled to
 * run. If you are implementing MTP, a single thread exiting does not
 * necessarily mean that the process should be exited.
 */
void
proc_thread_exited(void *retval) /* TODO: Verify functionality */
{
    /* Only called from kthread_exit() */
    /* No MTP - cleanup process, new thread scheduled to run */
    /* MTP - single thread exiting does not mean process exit */
    proc_cleanup(curproc->p_status); /* Process cleanup */
     /*dbg(DBG_PRINT,"(GRADING1C)\n");*/
      /*sched_switch();*/
}
    
/* If pid is -1 dispose of one of the exited children of the current
 * process and return its exit status in the status argument, or if
 * all children of this process are still running, then this function
 * blocks on its own p_wait queue until one exits.
 *
 * If pid is greater than 0 and the given pid is a child of the
 * current process then wait for the given pid to exit and dispose
 * of it.
 *
 * If the current process has no children, or the given pid is not
 * a child of the current process return -ECHILD.
 *
 * Pids other than -1 and positive numbers are not supported.
 * Options other than 0 are not supported.
 */
pid_t
do_waitpid(pid_t pid, int options, int *status)
{
    proc_t *p = NULL;
    proc_t *proc = NULL;
    kthread_t *thr = NULL;
     
    /* If the current process has no children or given pid is not child of current process */
    if(list_empty(&curproc->p_children))
    {
        /*dbg(DBG_PRINT,"(GRADING1C)\n");*/
        return -ECHILD; /* Return -ECHILD */
    }
        
    if(pid == -1) /* If pid is -1 */
    {
        while(1)
        {
            list_iterate_begin(&curproc->p_children, p, proc_t, p_child_link) /* curproc->p_children traverse */
            {
                KASSERT(NULL != p); /* the dead child process should not be NULL */
                KASSERT(-1 == pid || p->p_pid == pid); /* should be able to find a valid process ID for the process */
                KASSERT(NULL != p->p_pagedir); /* this process should have a valid pagedir */
               /* dbg(DBG_PRINT, "(GRADING1A 2.c)\n");*/ /* KASSERT - GRADING1A 2.c */
                    
                if(p->p_state == PROC_DEAD) /* Found dead child */
                {
                       
                    if (status != NULL)
                    {
                    *status = p->p_status; /* Set status pointer to process exit status */
                    }
                    list_iterate_begin(&p->p_threads, thr, kthread_t, kt_plink)
                    {
                        KASSERT(KT_EXITED == thr->kt_state); /* thr points to a thread to be destroyed */
                       /* dbg(DBG_PRINT, "(GRADING1A 2.c)\n"); *//* KASSERT - GRADING1A 2.c */
                            
                        kthread_destroy(thr); /* Destroy thread */
                    }
                    list_iterate_end();
                        
                    list_remove(&p->p_child_link); /* Remove process from parent's children list */
                    list_remove(&p->p_list_link); /* Remove process from process pool list */
                      
                    pt_destroy_pagedir(p->p_pagedir); /* Destroy pages */
                    slab_obj_free(proc_allocator, p); /* Process destruction */
                   /* dbg(DBG_PRINT,"(GRADING1C)\n");*/
                    return p->p_pid; /* Return pid of exited process */
                }
            }
            list_iterate_end();
            sched_sleep_on(&curproc->p_wait); /* Suspend execution until a child exits */
        }
    }
    else
    {
         proc = proc_lookup(pid);
         if(proc==NULL)
         {
           /* dbg(DBG_PRINT,"(GRADING1C)\n");*/
            return -ECHILD;
         }
    
        if(curproc==proc->p_pproc)
        {
        KASSERT(NULL != proc); /* the dead child process should not be NULL */
        KASSERT(-1 == pid || proc->p_pid == pid); /* should be able to find a valid process ID for the process */
        KASSERT(NULL != proc->p_pagedir); /* this process should have a valid pagedir */
       /* dbg(DBG_PRINT, "(GRADING1A 2.c)\n");*/
        while(proc->p_state != PROC_DEAD) /* If process is not dead */
        {
            sched_sleep_on(&curproc->p_wait);
        }
        if (status != NULL)
        {
        *status = proc->p_status; /* Set status pointer to process exit status */
        } 
        list_iterate_begin(&proc->p_threads, thr, kthread_t, kt_plink)
        {
            KASSERT(KT_EXITED == thr->kt_state); /* thr points to a thread to be destroyed */
           /* dbg(DBG_PRINT, "(GRADING1A 2.c)\n");*/
            kthread_destroy(thr); /* Destroy thread */
        }
        list_iterate_end();
            
        list_remove(&proc->p_child_link); /* Remove process from parent's children list */
        list_remove(&proc->p_list_link); /* Remove process from process pool list */
            
        pt_destroy_pagedir(proc->p_pagedir); /* Destroy pages */
        slab_obj_free(proc_allocator, proc); /* Process destruction */
        /*dbg(DBG_PRINT,"(GRADING1C)\n");*/
        return proc->p_pid; /* Return pid of exited process */
        }
    }
    return 0;
}
    
/*
 * Cancel all threads, join with them, and exit from the current
 * thread.
 *
 * @param status the exit status of the process
 */
void
do_exit(int status) /* TODO: Verify functionality */
{  
    curproc->p_status = status; /* Set current process status to input status */
    kthread_cancel(curthr,NULL); /* Exit from current thread */
    /*dbg(DBG_PRINT,"(GRADING1C)\n");*/
}
    
size_t
proc_info(const void *arg, char *buf, size_t osize)
{
        const proc_t *p = (proc_t *) arg;
        size_t size = osize;
        proc_t *child;
    
        KASSERT(NULL != p);
        KASSERT(NULL != buf);
    
        iprintf(&buf, &size, "pid:          %i\n", p->p_pid);
        iprintf(&buf, &size, "name:         %s\n", p->p_comm);
        if (NULL != p->p_pproc) {
                iprintf(&buf, &size, "parent:       %i (%s)\n",
                        p->p_pproc->p_pid, p->p_pproc->p_comm);
        } else {
                iprintf(&buf, &size, "parent:       -\n");
        }
    
#ifdef __MTP__
        int count = 0;
        kthread_t *kthr;
        list_iterate_begin(&p->p_threads, kthr, kthread_t, kt_plink) {
                ++count;
        } list_iterate_end();
        iprintf(&buf, &size, "thread count: %i\n", count);
#endif
    
        if (list_empty(&p->p_children)) {
                iprintf(&buf, &size, "children:     -\n");
        } else {
                iprintf(&buf, &size, "children:\n");
        }
        list_iterate_begin(&p->p_children, child, proc_t, p_child_link) {
                iprintf(&buf, &size, "     %i (%s)\n", child->p_pid, child->p_comm);
        } list_iterate_end();
    
        iprintf(&buf, &size, "status:       %i\n", p->p_status);
        iprintf(&buf, &size, "state:        %i\n", p->p_state);
    
#ifdef __VFS__
#ifdef __GETCWD__
        if (NULL != p->p_cwd) {
                char cwd[256];
                lookup_dirpath(p->p_cwd, cwd, sizeof(cwd));
                iprintf(&buf, &size, "cwd:          %-s\n", cwd);
        } else {
                iprintf(&buf, &size, "cwd:          -\n");
        }
#endif /* __GETCWD__ */
#endif
    
#ifdef __VM__
        iprintf(&buf, &size, "start brk:    0x%p\n", p->p_start_brk);
        iprintf(&buf, &size, "brk:          0x%p\n", p->p_brk);
#endif
    
        return size;
}
    
size_t
proc_list_info(const void *arg, char *buf, size_t osize)
{
        size_t size = osize;
        proc_t *p;
    
        KASSERT(NULL == arg);
        KASSERT(NULL != buf);
    
#if defined(__VFS__) && defined(__GETCWD__)
        iprintf(&buf, &size, "%5s %-13s %-18s %-s\n", "PID", "NAME", "PARENT", "CWD");
#else
        iprintf(&buf, &size, "%5s %-13s %-s\n", "PID", "NAME", "PARENT");
#endif
    
        list_iterate_begin(&_proc_list, p, proc_t, p_list_link) {
                char parent[64];
                if (NULL != p->p_pproc) {
                        snprintf(parent, sizeof(parent),
                                 "%3i (%s)", p->p_pproc->p_pid, p->p_pproc->p_comm);
                } else {
                        snprintf(parent, sizeof(parent), "  -");
                }
    
#if defined(__VFS__) && defined(__GETCWD__)
                if (NULL != p->p_cwd) {
                        char cwd[256];
                        lookup_dirpath(p->p_cwd, cwd, sizeof(cwd));
                        iprintf(&buf, &size, " %3i  %-13s %-18s %-s\n",
                                p->p_pid, p->p_comm, parent, cwd);
                } else {
                        iprintf(&buf, &size, " %3i  %-13s %-18s -\n",
                                p->p_pid, p->p_comm, parent);
                }
#else
                iprintf(&buf, &size, " %3i  %-13s %-s\n",
                        p->p_pid, p->p_comm, parent);
#endif
        } list_iterate_end();
        return size;
}
