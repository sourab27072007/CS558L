Documentation for Kernel Assignment 2
=====================================

+------------------------+
| BUILD & RUN (Required) |
+------------------------+

Replace "(Comments?)" with the command the grader should use to compile
    your kernel (it should simply be "make").
    To compile the kernel, the grader should type: make.
    To run the kernel,the grader should type: ./weenix -n
+--------------------+
| GRADING (Required) |
+--------------------+

(A.1) In fs/vnode.c:
    (a) In special_file_read(): 6 out of 6 pts
    (b) In special_file_write(): 6 out of 6 pts

(A.2) In fs/namev.c:
    (a) In lookup(): 6 out of 6 pts
    (b) In dir_namev(): 10 out of 10 pts
    (c) In open_namev(): 2 out of 2 pts

(A.3) In fs/vfs_syscall.c:
    (a) In do_write(): 6 out of 6 pts
    (b) In do_mknod(): 2 out of 2 pts
    (c) In do_mkdir(): 2 out of 2 pts
    (d) In do_rmdir(): 2 out of 2 pts
    (e) In do_unlink(): 2 out of 2 pts
    (f) In do_stat(): 2 out of 2 pts

(B) vfstest: 39 out of 39 pts
    What is your kshell command to invoke vfstest_main(): vfstest

(C.1) faber_fs_thread_test (3 out of 3 pts)
    What is your kshell command to invoke faber_fs_thread_test(): thrtest (number of threads to run)
(C.2) faber_directory_test (2 out of 2 pts)
    What is your kshell command to invoke faber_directory_test(): dirtest (number of threads to run)

(D) Self-checks: (10 out of 10 pts)
    Comments: None is needed (please provide details, add subsections and/or items as needed; or, say that "none is needed")

Missing/incomplete required section(s) in README file (vfs-README.txt): No missing/incomplete sections in README file (-0 pts)
Submitted binary file : binary file not submitted  (-0 pts)
Submitted extra (unmodified) file : extra (unmodified) file not submitted (-0 pts)
Wrong file location in submission : Correct file location in submission  (-0 pts)
Extra printout DBG=error,test tout is for which item in the grading guidelines :None (-0 pts)
Incorrectly formatted or mis-labeled "conforming dbg() calls" : Correctly formatted or labeled "conforming dbg() calls" (-0 pts)
Cannot compile : compiles (-0 pts)
Compiler warnings : No compiler warnings (-0 pts)
"make clean" : make clean implemented properly (-0 pts)
Kernel panic : No kernel panic  (-0 pts)
Kernel hangs : No kernel hangs (-0 pts)
Cannot halt kernel cleanly : Can halt kernel cleanly  (-0 pts)

+---------------------------------+
| BUGS / TESTS TO SKIP (Required) |
+---------------------------------+

Is there are any tests in the standard test suite that you know that it's not
working and you don't want the grader to run it at all so you won't get extra
deductions, please list them here.  (Of course, if the grader won't run these
tests, you will not get plus points for them.)  If there is none, please replace
the question mark with "none".

Comments: None

+--------------------------------------+
| CONTRIBUTION FROM MEMBERS (Required) |
+--------------------------------------+

1)  Names and USC e-mail addresses of team members: 
          Name                                  e-mail address
      Sourabh Kumar                            kumarsou@usc.edu
      Albert Zhu                               zhualber@usc.edu
      Brinda Raghunatha Bharadwaj              braghuna@usc.edu
      Deepashree Puttenhalli Vajrappa          puttenha@usc.edu
2)  Is the following statement correct about your submission (please replace
        "(Comments?)" with either "yes" or "no", and if the answer is "no",
        please list percentages for each team member)?  "Each team member
        contributed equally in this assignment": Yes

+------------------+
| OTHER (Optional) |
+------------------+

Comments on deviation from spec (you will still lose points, but it's better to let the grader know):No deviation from spec.
General comments on design decisions: None


