#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/stat.h>
#include <netdb.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <sys/time.h>



void error(const char *msg)
{
    perror(msg);
    exit(0);
}


int main(int argc, char *argv[]) 
{
    
printf("The client is up and running\n");
    char *res;
     int fd;
   int result;
long int sendSize;
int curr_seq=0;
struct stat stat_buffer;
int num_pack=0;

    int sockfd, portno, n;
    struct sockaddr_in serv_addr;
    struct hostent *serv;
    
    int sockfd1;
    int length;
    struct sockaddr_in server, from;
    struct hostent *hp;
    int nackCounter = 0;
    int file_sent=0;
    socklen_t fromlen;
    fromlen = sizeof(struct sockaddr_in);
    
    
    char buffer[256];
    if (argc < 4) {
        fprintf(stderr,"usage %s hostname port filename\n", argv[0]);
        exit(0);
    }
    
    
    portno = atoi(argv[2]);
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0)
        error("ERROR opening socket");
    serv = gethostbyname(argv[1]);
    if (serv == NULL) {
        fprintf(stderr,"ERROR, no such host\n");
        exit(0);
    }
    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    bcopy((char *)serv->h_addr,
          (char *)&serv_addr.sin_addr.s_addr,
          serv->h_length);
    serv_addr.sin_port = htons(portno);
   
    bzero(buffer,256);
   
    fd = open(argv[3], O_RDONLY);
    if (fd == -1) {
        error("open");
    }
  
    if (stat(argv[3], &stat_buffer)== -1)
   {
        error("error in stat\n");
        exit(0);
    }
    bzero(buffer,256);
    sprintf(buffer, "%lld", (long long) stat_buffer.st_size);
    
    printf("File Size is : %s\n",buffer);

     n = sendto(sockfd,buffer,sizeof(buffer),0,(struct sockaddr *)&serv_addr,fromlen);
                if (n  < 0) error("sendto");
    
    
    sockfd1= socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd1 < 0) error("socket");
    
    int buffSize = 32*1024*1024;
    
    if (setsockopt(sockfd1, SOL_SOCKET, SO_SNDBUF, &buffSize, sizeof buffSize)<0){
        error("buffer error");
    }
    
    if (setsockopt(sockfd1, SOL_SOCKET, SO_RCVBUF, &buffSize, sizeof buffSize)<0){
        error("buffer error");
    }
    
    
    server.sin_family = AF_INET;
    hp = gethostbyname(argv[1]);
    if (hp==0) 
{
error("Unknown host");
}
    
    bcopy((char *)hp->h_addr,
          (char *)&server.sin_addr,
          hp->h_length);
    server.sin_port = htons(portno+1);
    length=sizeof(struct sockaddr_in);
    
    
    
    res = (char*)mmap(0, stat_buffer.st_size, PROT_READ, MAP_SHARED, fd, 0);
    if (res == MAP_FAILED) {
        close(fd);
        error("res");
    }    
    num_pack = stat_buffer.st_size/1464;
    num_pack = num_pack+1;
    long int i=0;
printf("Client starting to send data \n");
    while (1) {
        long int size=stat_buffer.st_size;
        
        
    while(1)
    {
            char data[1464];
            char send_data[1472];
            char seq_num[9];
            
            if(curr_seq == num_pack-1)
            {
                file_sent=1;
                break;
            }
            
            if (curr_seq < num_pack)
       { 
                sprintf(seq_num,"%8d",curr_seq);
                memcpy(send_data,seq_num,8);
                memcpy(send_data+8,&res[curr_seq*1464],1464);
                
                n = sendto(sockfd1,send_data,sizeof(send_data),0,(struct sockaddr *)&server,fromlen);
                if (n  < 0) error("sendto");
               
                curr_seq++;
            }
            else{ 
                
                sprintf(seq_num,"%8d",curr_seq);
                memcpy(send_data,seq_num,8);
                memcpy(send_data+8,&res[curr_seq*1464],stat_buffer.st_size-(curr_seq*1464));
                printf("Sending last sequence: %d\n",curr_seq);
                n = sendto(sockfd1,send_data,sizeof(send_data),0,(struct sockaddr *)&server,fromlen);
                if (n  < 0) error("sendto last seq");
                curr_seq++;
                
            }
        }


        if(file_sent)
        {
            
            
               
                
    int nn,ii;
    bzero(buffer,256);
    int control[1470];
    printf("Entering UDP listner\n");
    while(1) {
        
        bzero(control,1470);
        nn = recvfrom(sockfd1,control,sizeof(control),0,(struct sockaddr *)&server,&fromlen);
        if (nn < 0) 
{
error("ERROR in recieving NACK");
      }
        if (control[0] == -1) 
    {
       
            printf("File Sent successfully\n");
            return;
        }
        else {
            
            
            
            char dataa[1464];
            char send_dataa[1472];
            char seq_numr[9];
            for(ii=0;ii<1470;ii++){
                
                if (control[ii] != num_pack){
                    memcpy(dataa,&res[control[ii]*1464],1464);
                    
                    sprintf(seq_numr,"%8d",control[ii]);
                    memcpy(send_dataa,seq_numr,8);
                    memcpy(send_dataa+8,dataa,sizeof(dataa));
                    
                    nn = sendto(sockfd1,send_dataa,sizeof(send_dataa),0,(struct sockaddr *)&server,fromlen);
                    if (nn  < 0) error("sendto");
                    
                }
                else{
                    memcpy(dataa,&res[control[ii]*1464],stat_buffer.st_size-((num_pack-1)*1464));
                    
                    sprintf(seq_numr,"%8d",control[i]);
                    memcpy(send_dataa,seq_numr,8);
                    memcpy(send_dataa+8,dataa,sizeof(dataa));
                   
                    nn = sendto(sockfd1,send_dataa,sizeof(send_dataa),0,(struct sockaddr *)&server,fromlen);
                    if (nn  < 0) error("sendto");
                    
                }
            }//for
        }//else
    }//while
                exit(0);
            
            break;
        }
    }//end while
    