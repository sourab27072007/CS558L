#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h> 
#include <arpa/inet.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/ip.h>
#include <sys/stat.h>
#include <sys/mman.h> 
#include <fcntl.h>
#include <time.h>


void error(char *msg)
{
perror(msg);
exit(0);
}

int main(int argc, char *argv[])
{
	int sock,n,length,num_pac,i,portno;
	char *res;
	struct sockaddr_in server,from;
	struct hostent *hp;
	struct timeval begin, end;
	struct stat stat_buffer;

	int curr_seq=0;
	int file_sent=0;

	char buffer[256];
	bzero((char *) &server, sizeof(server));
	if (argc != 3)
	{
	printf("Usage: server port\n");
	exit(1);
	}

	sock= socket(AF_INET, SOCK_DGRAM,0);
	if(sock<0)
	{
		error("socket");
	}

	server.sin_family=AF_INET;

	portno = atoi(argv[2]);
	hp=gethostbyname(argv[1]);
	if(hp==0)
	{
		error("unknown host");
	}

	int fp;
    fp = open("small.txt",  O_RDONLY); 
    if(0 == fp)
    {
        printf("Error opening file");
        return 1;
    }

     if (stat ("small.txt",&stat_buffer) == -1)
     perror("fstat error");
	
	bcopy((char *)hp->h_addr,(char *)&server.sin_addr,hp->h_length);
	server.sin_port = htons(portno);

	int sockbuf=100*1024*1024;
	setsockopt(sock, SOL_SOCKET, SO_SNDBUF, (char*)&sockbuf, sizeof(sockbuf));
	setsockopt(sock, SOL_SOCKET, SO_RCVBUF, (char*)&sockbuf, sizeof(sockbuf));

	length=sizeof(struct sockaddr_in);
	bzero(buffer,256);

	


	/*res=mmap(0, stat_buffer.st_size, PROT_READ, MAP_SHARED, fp, 0);
	if(*res == -1)
	{
	 perror("mmap error");
	}*/

	res = mmap(0,stat_buffer.st_size, PROT_READ, MAP_SHARED,fp, 0);
	if(res==MAP_FAILED)
{
	close(fp);
	 perror("mmap error");
}
sprintf(buffer, "%lld", (long long)stat_buffer.st_size);
	//if((stat_buffer.st_size % 1464)==0)
//{
//	num_pac=stat_buffer.st_size/1464;
//}
//else
{
	num_pac=(stat_buffer.st_size/1464);
	num_pac=num_pac + 1;
}

//for(i=0;i<15;i++)
//{
	//printf("%s\n",buffer);
	gettimeofday(&begin, NULL);
n=sendto(sock,(char *)buffer,sizeof(buffer),0,(struct sockaddr *)&server,(socklen_t)length);

//}

int send=0;

	while(1)
	{

			char data[1464];
            char send_data[1472];
            char seq_char[9];

            
             if(curr_seq == num_pac)
            {
                file_sent=1;
                printf("last packet received\n");
                break;
            }
            if(curr_seq < num_pac)
            {
            sprintf(seq_char,"%8d",curr_seq);
            memcpy(send_data,seq_char,8);
            memcpy(send_data+8,&res[curr_seq*1464],1464);
            send = sendto(sock,send_data,sizeof(send_data),0,(struct sockaddr *)&server,length);
            
            	if (send  < 0)
            	{
             		error("sendto");
         		}
         	curr_seq++;
            }
            else
            {
            	sprintf(seq_char,"%8d",curr_seq);
                memcpy(send_data,seq_char,8);
                memcpy(send_data+8,&res[curr_seq*1464],stat_buffer.st_size-(curr_seq*1464));
                
            	send = sendto(sock,send_data,sizeof(send_data),0,(struct sockaddr *)&server,length);
            	if (send  < 0)
            	{
             		error("sendto");
         		}
         		curr_seq++;
            }
           
            


	}
gettimeofday(&end, NULL);

double elapsed = (end.tv_sec - begin.tv_sec) + 
              ((end.tv_usec - begin.tv_usec)/1000000.0);
printf("time elapsed is %lf\n",elapsed);
printf("final speed is %lf\n",8*stat_buffer.st_size/(1000000*elapsed));
}