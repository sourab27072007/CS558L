#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <sys/time.h>
#include <libgen.h>


void error(const char *msg)
{
    perror(msg);
    exit(0);
}

int main(int argc, char *argv[])
{

printf("The server is up and running\n");
    int sockfd;
    socklen_t clilen;
    struct sockaddr_in serv_addr, cli_addr;
    char buffer[256];
    char fileName[256];
    char* bname;
    bzero(buffer,256);
    int n;
    int portno;
char *ret;
int fd;
int result;
int num_pack;

    if (argc < 2) {
        fprintf(stderr,"ERROR, no port provided\n");
        exit(1);
    }
    
    
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0)
        error("ERROR opening socket");
    bzero((char *) &serv_addr, sizeof(serv_addr));
    portno = atoi(argv[1]);
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(portno);
    if (bind(sockfd, (struct sockaddr *) &serv_addr,
             sizeof(serv_addr)) < 0)
        error("ERROR on binding");
   
    clilen = sizeof(cli_addr);
    bzero(buffer,256);

    n = recvfrom(sockfd,buffer,sizeof(buffer),0,(struct sockaddr *)&cli_addr, (socklen_t*)&clilen);
            if (n < 0) error("recvfrom");
  
    printf("File Size: %s\n",buffer);
    long int file_size=atoi(buffer);
  
    while (1) {
        
   
    char *ret;
    int fd;
    int result;
    
    fd = open("file1.txt", O_RDWR | O_CREAT | O_TRUNC, (mode_t)0600);
    if (fd == -1) {
        error("open");
    }
    result = lseek(fd, file_size-1, SEEK_SET);
    if (result == -1) {
        close(fd);
        error("lseek");
    }
    
    result = write(fd, "", 1);
    if (result != 1) {
        close(fd);
        error("write");
    }
    ret = (char*)mmap(0, file_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (ret == MAP_FAILED) {
        close(fd);
        error("ret");
    }
    
    
    char data_recv[1472];
    char data[1464];
    long int recv_file=0;
    long int total_pack=(file_size/1464);
    total_pack = total_pack +1;
    char pktsRcvd[1000000]={};
    int nackCounter=0;

   
    int sockfd1, length;
    socklen_t fromlen;
    struct sockaddr_in server;
    struct sockaddr_in from;
    char buf[1024];
    
    sockfd1=socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd1 < 0) error("Opening socket");
    
    int buffSize = 32*1024*1024;
    if(setsockopt(sockfd1, SOL_SOCKET, SO_SNDBUF, &buffSize, sizeof buffSize)<0){
        error("buff change error");
    }
    if(setsockopt(sockfd1, SOL_SOCKET, SO_RCVBUF, &buffSize, sizeof buffSize)<0){
        error("buff change error");
    }
    
    length = sizeof(server);
    bzero(&server,length);
    server.sin_family=AF_INET;
    server.sin_addr.s_addr=INADDR_ANY;
    server.sin_port=htons(portno+1);
    if (bind(sockfd1,(struct sockaddr *)&server,length)<0)
        error("binding");
    fromlen = sizeof(struct sockaddr_in);
    
    
    struct timespec tv;
    fd_set readfds;
    
    tv.tv_sec = 0;
    tv.tv_nsec = 100000000;
  
    FD_ZERO(&readfds);
    FD_SET(sockfd1, &readfds);
    
    while(1) {
        
       
        FD_ZERO(&readfds);
        FD_SET(sockfd1, &readfds);
       
        int setRet = pselect(sockfd1+1, &readfds, NULL, NULL, &tv, NULL);
        
       
        if(setRet > 0 ){
            n = recvfrom(sockfd1,data_recv,1472,0,(struct sockaddr *)&from, (socklen_t*)&length);
            if (n < 0) error("recvfrom");
            char seq_char[8];
            memcpy(seq_char,data_recv,8);
            int seq=atoi(seq_char);
            if(pktsRcvd[seq]==0){
                
                num_pack++;
                pktsRcvd[seq]=1;
                memcpy(data,data_recv+8,sizeof(data_recv)-8);
                
                if (seq < total_pack-1){
                    memcpy(&ret[seq*1464],data,sizeof(data));
                    recv_file+=sizeof(data);
                }
                else{
                    
                    memcpy(&ret[seq*1464],data,file_size-((seq)*1464));
                    recv_file+=(file_size-((seq)*1464));
                }
                
                if(recv_file>=file_size)
                {
                    printf("STATISTICS\n");
                    printf("file_size original: %ld\n", file_size);
                    printf("file_size after Reception: %ld\n", recv_file);
                    printf("Total NACK packets: %d\n",nackCounter);
                    
                    if (munmap(ret, file_size) == -1) {
                        error("munmap");
                        
                    }
                    close(fd);
                    
                    int final[1];
                    final[0] = -1;
                   
                    n = sendto(sockfd1,final,sizeof(final),0,(struct sockaddr *)&from, length);
                    if (n < 0) error("ERROR sending final packet");
                    n = sendto(sockfd1,final,sizeof(final),0,(struct sockaddr *)&from, length);
                    if (n < 0) error("ERROR sending final packet");
                    n = sendto(sockfd1,final,sizeof(final),0,(struct sockaddr *)&from, length);
                    if (n < 0) error("ERROR sending final packet");
                    break;
                }
            }
        }
        else {
            
            int control[1470];
            long int reqs=0;
            int j;
            int num=0;
            
            for(j=0;j<total_pack;j++) {
                if(pktsRcvd[j]==0) {
                    
                    control[num] = j;
                    num++;
                    
                    reqs++;
                    
                    if(reqs==1470) {
                        nackCounter++;
                        num=0;
                       
                        n = sendto(sockfd1,control,sizeof(control),0,(struct sockaddr *)&from, length);
                        if (n < 0) 
{
error("NACK error");
}
                        
                        n = sendto(sockfd1,control,sizeof(control),0,(struct sockaddr *)&from, length);
                        if (n < 0) 
{
error("NACK sendto error");
}
                        break;
                        
                    }
                }
            }
            if(j==total_pack)
            {
                nackCounter++;
                
                n = sendto(sockfd1,control,sizeof(control),0,(struct sockaddr *)&from, length);
                if (n < 0) error("NACK sendto error");
                
                n = sendto(sockfd1,control,sizeof(control),0,(struct sockaddr *)&from, length);
                if (n < 0) error("NACK sendto error");
                
                
            }
           
            FD_ZERO(&readfds);
            FD_SET(sockfd1, &readfds);
            
        }
    }
    close(sockfd1);
  
    close(sockfd);
    
    return;

            exit(0);
        
    } 
    close(sockfd);
    return 0;
}