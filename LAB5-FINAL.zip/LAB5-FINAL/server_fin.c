#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <sys/time.h>
#include <libgen.h>

int main(int argc, char *argv[])
{
    int sockfd,length,n;
    int portno;
    socklen_t fromlen;
    struct sockaddr_in server,from;
    char buffer[256];
    char recvData[1472];
    
    char data[1464];
    int seq;
    
    
    int fd=open("file1.txt", O_RDWR | O_CREAT | O_TRUNC, (mode_t)0666);
    if(fd==-1)
        printf("Error opening file\n");
    
    sockfd=socket(AF_INET,SOCK_DGRAM,0);
    if(sockfd<0)
        printf("Error opening socket\n");
    int buffSize=1024*1024*1024;

    if(setsockopt(sockfd,SOL_SOCKET,SO_SNDBUF,&buffSize,sizeof(buffSize))<0)
        printf("Buff change error\n");
    if(setsockopt(sockfd,SOL_SOCKET,SO_RCVBUF,&buffSize,sizeof(buffSize))<0)
        printf("Buff change error\n");

    length=sizeof(server);
    bzero(&server,length);
    portno=atoi(argv[1]);
    server.sin_family=AF_INET;
    server.sin_addr.s_addr=INADDR_ANY;
    server.sin_port=htons(portno);

    if(bind(sockfd,(struct sockaddr *)&server,length)<0)
        printf("Binding error\n");
    fromlen=sizeof(struct sockaddr_in);
   // printf("%s\n",buffer);
    n=recvfrom(sockfd,buffer,sizeof(buffer),0,(struct sockaddr *)&from,(socklen_t *)&length);
    long int fileSize=atoi(buffer);
//printf("%s\n",buffer);
    int result = lseek(fd, fileSize-1, SEEK_SET);
    if (result == -1) 
    {
        close(fd);
        error("lseek");
    }
    
    result = write(fd, "", 1);
    if (result != 1) {
        close(fd);
        error("write");
    }
    char *map = (char*)mmap(0, fileSize, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);

    long int recvSize=0;
    long int totPkts=(fileSize/1464);
    totPkts = totPkts +1;
    char pktsRcvd[1000000]={};

    
    while(1)
    {
        n=recvfrom(sockfd,recvData,1472,0,(struct sockaddr *)&from,(socklen_t *)&length);
       //printf("%s\n",recvData );
        if(n<0)
            printf("Recvfrom error\n");
        char seqc[8];
        memcpy(seqc,recvData,8);
        seq=atoi(seqc);
        
        memcpy(data,recvData+8,sizeof(recvData)-8);
        if(seq<totPkts-1)
        {
            memcpy(&map[seq*1464],data,sizeof(data));
            recvSize+=sizeof(data);
        }
        else
        {
            printf("Writing last packet\n");
            memcpy(&map[seq*1464],data,fileSize-((seq)*1464));
            recvSize+=(fileSize-((seq)*1464));
        }
        if(recvSize>=fileSize)
        {
            printf("File received\n");
            printf("Filesize: %ld\n", fileSize);
            printf("Recv size: %ld\n", recvSize);
            if (munmap(map, fileSize) == -1)
                printf("error munmap\n");
            close(fd);
            break;
        }
    }

}
