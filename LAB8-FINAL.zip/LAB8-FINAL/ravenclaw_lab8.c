#include<netinet/in.h>
#include<errno.h>
#include<netdb.h>
#include<stdio.h> 
#include<stdlib.h>    
#include<string.h>    
 
#include<netinet/ip_icmp.h>   
#include<netinet/udp.h>   
#include<netinet/tcp.h>   
#include<netinet/ip.h>   
#include<netinet/if_ether.h>  
#include<net/ethernet.h> 
#include<sys/socket.h>
#include<arpa/inet.h>
#include<sys/ioctl.h>
#include<sys/time.h>
#include<sys/types.h>
#include<unistd.h>

#include <net/if.h>
#include <linux/if_packet.h> 

#include <netinet/ether.h>
#include <linux/if_packet.h>
 
typedef struct table_arp{
   char ip_addr[20];
   struct ether_addr ether_addr;
   char device[5];
   struct table_arp *next;	
}arp_table;

typedef struct table_ip{
   char ip_addr[20];
   struct ether_addr ether_addr;
   char next_hop[20];
   char device[6];
   struct table_ip *next;	
}ip_table,my_ip_table;

ip_table *ip_head;

char prev_ip_addr[20];

void create_arp_table(char *);
//void display_arp();

//void create_ip_table(char *);
//void display_ip();
int look_up_route_table(char*,struct ether_addr*,char*);
void thread_entry_point(void *data); 
char interface[3][5];
int port_index=0;

//arp_table *head=NULL;
ip_table *ip_head=NULL;
arp_table *head=NULL;

static unsigned short compute_checksum(unsigned short *addr, unsigned int count) {
  register unsigned long sum = 0;
  while (count > 1) {
    sum += * addr++;
    count -= 2;
  }
  //if any bytes left, pad the bytes and add
  if(count > 0) {
    sum += ((*addr)&htons(0xFF00));
  }
  //Fold sum to 16 bits: add carrier to result
  while (sum>>16) {
      sum = (sum & 0xffff) + (sum >> 16);
  }
  //one's complement
  sum = ~sum;
  return ((unsigned short)sum);
}

unsigned short checksum_icmp(unsigned char *buffer, int length)
{
    unsigned long sum;
    //char *buffer =packet+14+20;
    // initialize sum to zero and loop until length (in words) is 0

    for (sum=0; length>1; length-=2) // sizeof() returns number of bytes, we're interested in number of words
        sum += *buffer++;   // add 1 word of buffer to sum and proceed to the next

    // we may have an extra byte
    if (length==1)
        sum += (char)*buffer;

    sum = (sum >> 16) + (sum & 0xFFFF);  // add high 16 to low 16
    sum += (sum >> 16);          // add carry
    return ~sum;
}

unsigned short cksum(unsigned char *ip, int len){
         unsigned long sum = 0;
         const uint16_t *ip1;

         ip1 = (uint16_t *)ip;
         while (len > 1)
         {
                 sum += *ip1++;
                 if (sum & 0x80000000)
                         sum = (sum & 0xFFFF) + (sum >> 16);
                 len -= 2;
         }

         while (sum >> 16)
                 sum = (sum & 0xFFFF) + (sum >> 16);

         return(~sum);
}

/*int lookup_table(char* ipaddr,struct  ether_addr *matched_mac_addr,char *device_info){

	my_ip_table *temp = my_ip_head;
        while(temp!=NULL){
		if(strncmp(ipaddr,temp->ip_addr,6) == 0){
			printf("ip address found is %s\n destination matched is %s\n next hop is %s\n",ipaddr,temp->ip_addr,temp->next_hop);
			*matched_mac_addr = temp->ether_addr;
	  	strcpy(device_info,temp->device_name);
		return 1;
		}
        temp=temp->next; 	
	}
	return 0;	
}*/

void create_ip_table(){
FILE *arp_fd, *ip_fd;
int type,flag;
char mask[2]={0};
char line[100],mac_tmp[18],tmp_next[20],tmp_dev[5];
struct ether_addr *ether;
int count=0;
ip_table *new_ip_table;
arp_fd = fopen("/proc/net/arp", "r");
if(arp_fd == NULL){
	printf("ERROR with arp file\n");
	exit(1);
}
ip_fd = fopen("router.tmp", "r");
if(ip_fd == NULL){
	printf("ERROR with route file\n");
	exit(1);
}
while(fgets(line, sizeof(line),ip_fd)){
	count++;
	if(ip_head ==NULL){
		new_ip_table = (ip_table*)malloc(sizeof(ip_table));
		sscanf(line,"%s %s",new_ip_table->ip_addr, new_ip_table->next_hop);
		new_ip_table->next = NULL;
		ip_head = new_ip_table;
		while(fgets(line,sizeof(line),arp_fd)){
			sscanf(line,"%s 0x%x 0x%x %s %s %s \n",tmp_next,&type,&flag,mac_tmp,mask,tmp_dev);
			if(strcmp(new_ip_table->next_hop,tmp_next) == 0){
				strcpy(new_ip_table->device,tmp_dev);
				ether=(struct ether_addr *)ether_aton(mac_tmp);
				new_ip_table->ether_addr=*ether;
			}
		}		
	}
	else{  
		 rewind(arp_fd);
//		new_ip_table = new_ip_table->next;
 		new_ip_table->next = (ip_table*) malloc(sizeof(ip_table));
                new_ip_table = new_ip_table->next;
		sscanf(line,"%s %s",new_ip_table->ip_addr, new_ip_table->next_hop);
		new_ip_table->next = NULL;
		while(fgets(line,sizeof(line),arp_fd)){
			sscanf(line,"%s 0x%x 0x%x %s %s %s \n",tmp_next,&type,&flag,mac_tmp,mask,tmp_dev);
			if(strcmp(new_ip_table->next_hop,tmp_next) == 0){
				strcpy(new_ip_table->device,tmp_dev);
				ether=(struct ether_addr *)ether_aton(mac_tmp);
				new_ip_table->ether_addr= *ether;

			}
		}
	}
}
	fclose(arp_fd);
	fclose(ip_fd);
}



int look_up_route_table(char* ipaddr,struct  ether_addr *mac_addr,char *inf){
	if(strncmp(prev_ip_addr,ipaddr,6)==0)
		return 1;
	ip_table *temp = ip_head;
        while(temp!=NULL){
		if(strncmp(ipaddr,temp->ip_addr,6) == 0){
			printf("ip address found is %s\n destination matched is %s\n next hop is %s\n",ipaddr,temp->ip_addr,temp->next_hop);
			*mac_addr = temp->ether_addr;
		 	 //printf("Interface is %s \n MAC address is %02x %02x\n",temp->device,temp->ether_addr.ether_addr_octet[4],temp->ether_addr.ether_addr_octet[5]);
	  	strcpy(inf,temp->device);
		strcpy(prev_ip_addr,ipaddr);
		return 1;
		}
        temp=temp->next; 	
	}
	return 0;	
}

void display_ip() {
  ip_table *table = ip_head;
  while(table !=NULL) {
	printf("%s %s ", table->ip_addr, table->next_hop);
	printf("%0x:%0x:%0x:%0x:%0x:%0x",(table->ether_addr).ether_addr_octet[0],(table->ether_addr).ether_addr_octet[1],(table->ether_addr).ether_addr_octet[2],(table->ether_addr).ether_addr_octet[3],(table->ether_addr).ether_addr_octet[4], (table->ether_addr).ether_addr_octet[5]);
	printf(" %s\n", table->device);
        table = table->next;
  } 
return;
}

void create_arp_table(char *name) {

  FILE *arp_fd;
  char line[100];
  int type , flags;
  char mask[2]={0};
  char mac_tmp[18];
  struct ether_addr *ether;
  arp_table *new_table;
  arp_fd = fopen("/proc/net/arp" , "r");
  if(arp_fd == NULL){
    printf("ERROR: while opening the arp fd\n");
    exit(1);
  }


  fgets(line , sizeof(line), arp_fd);
  while(fgets(line , sizeof(line), arp_fd)) {
          if(strncmp(line,"192",3)==0){
		continue;
          }
	  if(head == NULL){
      new_table = (arp_table *)malloc(sizeof(arp_table));
      sscanf(line, "%s 0x%x 0x%x %s %s %s\n", new_table->ip_addr, &type, &flags, mac_tmp, mask, new_table->device);
      new_table->next = NULL;
      head = new_table;
     }	
     else {
       new_table->next = (arp_table *)malloc(sizeof(arp_table));
       new_table = new_table->next;
       sscanf(line, "%s 0x%x 0x%x %s %s %s\n", new_table->ip_addr, &type, &flags, mac_tmp, mask, new_table->device);
       new_table->next = NULL;
  }
  (ether) = (struct ether_addr *)ether_aton(mac_tmp);
  (new_table->ether_addr) = *ether;
  strcat(name, new_table->device);
  strcat(name," ");
  }
  fclose(arp_fd);
}


void display_arp() {
  
  arp_table *table = head;
  for(;;) {
    printf("%s %x %s\n", table->ip_addr,(table->ether_addr).ether_addr_octet[5],table->device);
    table = table->next;
	if(table==NULL)
		break;
  } 
  return;

}

int main()
{

	char *interface_names =(char *)malloc(sizeof(char)*60);
	create_arp_table(interface_names); 
    display_arp(); 
    printf("********************************\n\n\n");

    printf("********** IP TABLE *********************\n");
    create_ip_table(interface_names);
    printf("interface names:%s\n",interface_names); 
    display_ip();
    printf("*****************************************\n");  
    sscanf(interface_names, "%s %s %s\n", interface[0], interface[1], interface[2]);
    printf("%s %s %s\n",interface[0], interface[1], interface[2]); 

    pthread_t thread[3];
    int i;
    for(i=0;i<3;i++) 
    {
        pthread_create(&thread[i], NULL,(void *)&thread_entry_point, (void *)interface[i]);
    }

    pthread_join(thread[0],NULL);
    pthread_join(thread[1],NULL);
    pthread_join(thread[2],NULL);
    return 0;

}

void thread_entry_point(void *port) 
{

	char databuf[1500];
	int receive_socket,send_socket;
	struct sockaddr_ll phy_addr; 
	struct sockaddr_ll send_addr;
	struct sockaddr_ll phy_sock_address;
	struct sockaddr_in dest_internet_addr;
	struct iphdr *ip_header;
	struct ifreq ifr_s,if_addr,ifr_in;
	struct ether_header *eh_h = (struct ether_header *) databuf;
	int phy_addr_size,receive_size;
	
	if((receive_socket = socket( AF_PACKET , SOCK_RAW , htons(ETH_P_IP))) < 0)
	{
    	perror("Socket Error");
    	exit(1);
    }
   
    memset(&ifr_s, 0, sizeof(ifr_s));
    memset(&ifr_in, 0, sizeof(ifr_s));
	memset(&if_addr, 0, sizeof(if_addr));
    memset(&send_addr, 0, sizeof(send_addr));

	phy_addr_size = sizeof phy_addr;
    strncpy((char *)if_addr.ifr_name, (char *)port, IFNAMSIZ);
    strncpy((char *)ifr_s.ifr_name, (char *)port, IFNAMSIZ);
    strncpy((char *)ifr_in.ifr_name, (char *)port, IFNAMSIZ);

    if((ioctl(receive_socket, SIOCGIFINDEX, &ifr_s)) == -1)
    {
    	perror("Error getting Interface index !\n");
    	exit(-1);
  	}
  	if (ioctl(receive_socket, SIOCGIFADDR, &if_addr) == -1)
  	{
		perror("Error getting IP address !\n");
    	exit(-1);
   	}
  	send_addr.sll_family = AF_PACKET;
  	send_addr.sll_ifindex = ifr_s.ifr_ifindex;
  	send_addr.sll_protocol = htons(ETH_P_ALL);
	if((ioctl(receive_socket, SIOCGIFINDEX, &ifr_in)) == -1)
    {
    	perror("Error getting Interface index !\n");
    	exit(-1);
    }
  	if((bind(receive_socket, (struct sockaddr *)&send_addr, sizeof(send_addr)))== -1)
  	{
    	perror("Error binding raw socket to interface\n");
    	exit(-1);
 	}
	char *device_info=(char*)malloc(sizeof(char)); 
 	struct ether_addr *matched_mac_addr = (struct ether_addr*)malloc(sizeof(struct ether_addr));
 	
 	if ((send_socket = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_IP))) < 0) 
  	{
    	perror("socket");
  	}
  	while(1)
  	{
        
		memset(&databuf,0,sizeof(databuf));
  		if((receive_size = recvfrom(receive_socket , databuf , sizeof(databuf) , 0 , (struct sockaddr *)&phy_addr , (socklen_t*)&phy_addr_size)) < 0)
    		perror("Recvfrom error , failed to get packets\n");
    	if(phy_addr.sll_pkttype == PACKET_HOST)
    	{
    		ip_header = (struct iphdr *) (databuf + sizeof(struct ether_header));
    		dest_internet_addr.sin_addr.s_addr = ip_header->daddr; 
    		if(!strcmp(inet_ntoa(dest_internet_addr.sin_addr),"255.255.255.255")||(!strcmp(inet_ntoa(dest_internet_addr.sin_addr),"10.1.2.3")&&ip_header->ttl!=1)||!strcmp(inet_ntoa(dest_internet_addr.sin_addr),"10.1.2.4"))
	  		{ 	 
	    		continue;
	  		}
	  		else
	  		{
    if(ip_header->ttl == 1){
        printf("Received packet with TTL=1,receive_size=%d\n ",receive_size);
        
        char temp[28];
        memcpy(temp,ip_header,28);
        uint8_t temp_eth[6];
        temp_eth[0]=eh_h->ether_dhost[0];
        temp_eth[1]=eh_h->ether_dhost[1];
        temp_eth[2]=eh_h->ether_dhost[2];
        temp_eth[3]=eh_h->ether_dhost[3];
        temp_eth[4]=eh_h->ether_dhost[4];
        temp_eth[5]=eh_h->ether_dhost[5];
        eh_h->ether_dhost[0]=eh_h->ether_shost[0];
        eh_h->ether_dhost[1]=eh_h->ether_shost[1];
        eh_h->ether_dhost[2]=eh_h->ether_shost[2];
        eh_h->ether_dhost[3]=eh_h->ether_shost[3];
        eh_h->ether_dhost[4]=eh_h->ether_shost[4];
        eh_h->ether_dhost[5]=eh_h->ether_shost[5];
        eh_h->ether_shost[0]=temp_eth[0];
        eh_h->ether_shost[1]=temp_eth[1];
        eh_h->ether_shost[2]=temp_eth[2];
        eh_h->ether_shost[3]=temp_eth[3];
        eh_h->ether_shost[4]=temp_eth[4];
        eh_h->ether_shost[5]=temp_eth[5];
        struct sockaddr_in *myaddr;
        myaddr = (struct sockaddr_in *)&if_addr.ifr_addr;
        ip_header->daddr=ip_header->saddr;
        ip_header->saddr=myaddr->sin_addr.s_addr;
        ip_header->frag_off=0;
        ip_header->tos=0;
        ip_header->ttl=64;
        ip_header->tot_len=htons(88);
        ip_header->protocol=1;
        ip_header->ihl=5;
        ip_header->check=0;

        ip_header->check=cksum((unsigned char*)ip_header,20);
        struct icmp *myicmp= (struct icmp *)(databuf + sizeof(struct ether_header) + sizeof(struct iphdr ));
       memset(myicmp,0,receive_size-sizeof(struct ether_header)-sizeof(struct iphdr));
        memcpy(myicmp->icmp_data,temp,28);
        myicmp->icmp_code=0;
        	myicmp->icmp_type = 11;
		myicmp->icmp_cksum=0;
    		
    		myicmp->icmp_cksum=cksum((unsigned char*)myicmp, receive_size-sizeof(struct ether_header)-sizeof(struct iphdr));
                myicmp->icmp_id=0;
                myicmp->icmp_seq=0;


	       	phy_sock_address.sll_ifindex = ifr_in.ifr_ifindex;
                phy_sock_address.sll_halen = ETH_ALEN;
                phy_sock_address.sll_addr[0] = eh_h->ether_dhost[0];
                phy_sock_address.sll_addr[1] = eh_h->ether_dhost[1];
                phy_sock_address.sll_addr[2] = eh_h->ether_dhost[2];
                phy_sock_address.sll_addr[3] = eh_h->ether_dhost[3];
                phy_sock_address.sll_addr[4] = eh_h->ether_dhost[4];
                phy_sock_address.sll_addr[5] = eh_h->ether_dhost[5];

                 if (sendto(send_socket, databuf, sizeof(databuf), 0, (struct sockaddr*)&phy_sock_address, sizeof(struct sockaddr_ll)) < 0)
                    perror("Send failed\n");


	  }  
    else 
	  			{
					if(strncmp(prev_ip_addr,inet_ntoa(dest_internet_addr.sin_addr),6)!=0){
				
    						if( look_up_route_table(inet_ntoa(dest_internet_addr.sin_addr),matched_mac_addr,device_info)==0)
							continue;
                                                else  
                                        		strcpy(prev_ip_addr,inet_ntoa(dest_internet_addr.sin_addr));
                                        }
	  				
                    memset(&ifr_s, 0, sizeof(ifr_s));
                    strncpy((char *)ifr_s.ifr_name, device_info , IFNAMSIZ-1);
		  			if (ioctl(send_socket, SIOCGIFINDEX, &ifr_s) < 0) 
		    			perror("SIOCGIFINDEX");
                    phy_sock_address.sll_ifindex = ifr_s.ifr_ifindex;
		    		
                    memset(&ifr_s, 0, sizeof(ifr_s));
                    strncpy((char *)ifr_s.ifr_name, device_info , IFNAMSIZ-1);
		  			if (ioctl(send_socket, SIOCGIFHWADDR, &ifr_s) < 0) 
		    			perror("SIOCGIFHWADDR");

		  			eh_h->ether_dhost[0] = matched_mac_addr->ether_addr_octet[0]; 
		  			eh_h->ether_dhost[1] = matched_mac_addr->ether_addr_octet[1];
		  			eh_h->ether_dhost[2] = matched_mac_addr->ether_addr_octet[2];
		  			eh_h->ether_dhost[3] = matched_mac_addr->ether_addr_octet[3];
		  			eh_h->ether_dhost[4] = matched_mac_addr->ether_addr_octet[4];
		  			eh_h->ether_dhost[5] = matched_mac_addr->ether_addr_octet[5];
		  			eh_h->ether_type = htons(ETH_P_IP);
				    eh_h->ether_shost[0] = ((uint8_t *)&ifr_s.ifr_hwaddr.sa_data)[0];
		  			eh_h->ether_shost[1] = ((uint8_t *)&ifr_s.ifr_hwaddr.sa_data)[1];
		  			eh_h->ether_shost[2] = ((uint8_t *)&ifr_s.ifr_hwaddr.sa_data)[2];
		  			eh_h->ether_shost[3] = ((uint8_t *)&ifr_s.ifr_hwaddr.sa_data)[3];
		  			eh_h->ether_shost[4] = ((uint8_t *)&ifr_s.ifr_hwaddr.sa_data)[4];
		  			eh_h->ether_shost[5] = ((uint8_t *)&ifr_s.ifr_hwaddr.sa_data)[5];
		  			phy_sock_address.sll_halen = ETH_ALEN;

		  			phy_sock_address.sll_addr[0] = matched_mac_addr->ether_addr_octet[0];
		  			phy_sock_address.sll_addr[1] = matched_mac_addr->ether_addr_octet[1];
		  			phy_sock_address.sll_addr[2] = matched_mac_addr->ether_addr_octet[2];
		  			phy_sock_address.sll_addr[3] = matched_mac_addr->ether_addr_octet[3];
		  			phy_sock_address.sll_addr[4] = matched_mac_addr->ether_addr_octet[4];
		  			phy_sock_address.sll_addr[5] = matched_mac_addr->ether_addr_octet[5];
					if(ip_header->ttl==2){
						ip_header->ttl--;
                                        	printf("forwarding packet ttl : %d\n",ip_header->ttl);
						ip_header->check=0;
						ip_header->check = cksum((unsigned char*)ip_header, (ip_header->ihl)*4);
					}
		  			if (sendto(send_socket, databuf, sizeof(databuf), 0, (struct sockaddr*)&phy_sock_address, sizeof(struct sockaddr_ll)) < 0)
		    			perror("Send failed\n");
	    		}

	  		}
	  	}
    }
    	close(receive_socket);
    	return ;
}


