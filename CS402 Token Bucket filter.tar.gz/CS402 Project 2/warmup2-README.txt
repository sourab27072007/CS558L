Documentation for Warmup Assignment 2
=====================================

+-------+
| BUILD |
+-------+

Comments:  Type "make" to compile the program.

+---------+
| GRADING |
+---------+

Basic running of the code : 100 out of 100 pts

Missing required section(s) in README file : (NONE)
Cannot compile : (Compiles correctly)
Compiler warnings : (No compiler warnings)
"make clean" : (works)
Segmentation faults : (no segmentation faults)
Separate compilation : (yes)
Using busy-wait : (No)
Handling of commandline arguments:
    1) -n : (handled)
    2) -lambda : (handled)
    3) -mu : (handled)
    4) -r : (handled)
    5) -B : (handled)
    6) -P : (handled)
Trace output :
    1) regular packets: (output displayed correctly)
    2) dropped packets: (output displayed correctly)
    3) removed packets: (output displayed correctly)
    4) token arrival (dropped or not dropped): (output displayed correctly)
Statistics output :
    1) inter-arrival time : (output displayed correctly)
    2) service time : (output displayed correctly)
    3) number of customers in Q1 : (output displayed correctly)
    4) number of customers in Q2 : (output displayed correctly)
    5) number of customers at a server : (output displayed correctly)
    6) time in system : (output displayed correctly)
    7) standard deviation for time in system : (output displayed correctly)
    8) drop probability : (output displayed correctly)
Output bad format : (No, output displayed correctly)
Output wrong precision for statistics (should be 6-8 significant digits) : (output displayed with correct precision)
Large service time test : (output displayed correctly)
Large inter-arrival time test : (output displayed correctly)
Tiny inter-arrival time test : (output displayed correctly)
Tiny service time test : (output displayed correctly)
Large total number of customers test : (output displayed correctly)
Large total number of customers with high arrival rate test : (output displayed correctly)
Dropped tokens test : (output displayed correctly)
Cannot handle <Cntrl+C> at all (ignored or no statistics) : (Handled)
Can handle <Cntrl+C> but statistics way off : (Statistics are correct & precise)
Not using condition variables and do some kind of busy-wait : (Using condition variables, no busy wait)
Synchronization check : (yes, mutex used)
Deadlocks : (no)

+----------------------+
| BUGS / TESTS TO SKIP |
+----------------------+

Is there are any tests in the standard test suite that you know that it's not
working and you don't want the grader to run it at all so you won't get extra
deductions, please list them here.  (Of course, if the grader won't run these
tests, you will not get plus points for them.)

Comments: None

+------------------+
| OTHER (Optional) |
+------------------+

Comments on design decisions: None
Comments on deviation from spec: None


