#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/time.h>
#include <time.h>
#include <math.h>
#include <errno.h>
#include <sys/stat.h>
#include <pthread.h>
#include <signal.h>
#include <unistd.h>	

#include "cs402.h"
#include "my402list.h"

typedef struct packet
{
	int index;
	int P_token;
	double inter_arr;
	double service_time;
	double Q1_arrive;
	double Q1_leave;
	double Q2_arrive;
	double Q2_leave;
	double S_arrive;
	double S_leave;
	double total_time_sys;
	double Q1_time;
	double Q2_time;
	double S_time;
}pack;

void *token_arrival(void *);
void *packet_arrival(void *);
void *server1(void *);
void *server2(void *);
//double find_time();
void read_file();
void handler(int);
void *monitor();


pthread_mutex_t m=PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cv=PTHREAD_COND_INITIALIZER;

//int num,B,P;
//double lamda,mu,r;
int num=20;
int B=10;
int P=3;
double lamda=1;
double mu=0.35;
double r=1.5;
int n=0;
int flag=0;
int f=0;
int fl=0;
int f_drop=0;

int total_tok=0;

int dropped_tok=0;
int dropped_packs=0;
int removed_packs=0;
int completed_packs=0;
int arrived_packs=0;

double Q1_total=0;
double Q2_total=0;
double service_total1=0;
double service_total2=0;
double arrival_total=0;
double total_service=0;
double total_system_time=0;
double total_sq_system_time=0;

double start_t=0;
//double start_t1=0;
int count=1;


My402List* Q1;
My402List* Q2;

FILE *fp;

sigset_t set;

pthread_t t[10];

int main(int argc, char *argv[])
{
	struct timeval tim;
	//struct stat st;

	pack* packets=malloc(sizeof(pack));
	char str[2048],temp[20],temp1[20],temp2[20],file_name[100];
	int i,len;
	int k=0;
	int z1;
	int z2;

	double Q1_avg=0;
	double Q2_avg=0;
	double S1_avg=0;
	double S2_avg=0;
	double arrival_avg=0;
	double S_avg=0;
	double token_drop_prob=0;
	double packet_drop_prob=0;
	double total_sys_avg=0;
	double total_sq_sys_avg=0;
	double var_sys_time=0;
	double st_sys_time=0;

	double t1=0;
	double t2=0;
	double t3=0;
	double a1=0;
	int a2=0;
	double a3=0;
	double total_emulation=0;

	Q1=(My402List*)malloc(sizeof(My402List));
	Q2=(My402List*)malloc(sizeof(My402List));

	My402ListElem* elem2=NULL;
	pack* temp3=NULL;

	sigemptyset(&set);
	sigaddset(&set,SIGINT);

	//int l=0;
    //struct timeval tim;
    //double t1,t2;

	flag=0;
	strcpy(str,"");
	strcpy(temp,"");
	strcpy(temp1,"");
	strcpy(temp2,"");
	strcpy(file_name,"");

	z1=My402ListInit(Q1);
	z2=My402ListInit(Q2);
	if(z1==0)
	{
	    fprintf(stderr,"Error in initialization in Q1\n");
	    exit(1);
	}
	if(z2==0)
	{
	    fprintf(stderr,"Error in initialization in Q2\n");
	    exit(1);
	}
	//My402List* List=(My402List*)malloc(sizeof(My402List));
	/*if(argc == 1)
    {
        fprintf(stderr,"Malformed Input\n");
        printf("usage: warmup1 sort [tfile]\n");
        exit(1);
    }
    */
	if(argc%2==0)
	{
		fprintf(stderr,"Malformed Input command\n");
        printf("Usage: warmup2 [-lambda lambda] [-mu mu] [-r r] [-B B] [-P P] [-n num] [-t tsfile]\n");
		exit(1);
	}
    
	for(i=1;i<argc;i=i+2)
	{
		
		if(strcmp(argv[i],"-t")==0)
		{


			/*if(stat(argv[i+1],&st)==0)
	        {
	            if(S_ISDIR(st.st_mode))
	            {
	                fprintf(stderr,"The mentioned path is a directory, cannot be accessed\n");
	                printf("usage: warmup1 sort [tfile]\n");
	                exit(1);
	            }
	        }
	        */
			fp=fopen(argv[i+1],"r");
			strcpy(file_name,argv[i+1]);
			flag=1;

			if(fp==NULL)
		    {
		        fprintf(stderr,"Input file %s %s\n",argv[i+1],strerror(errno));
		        printf("Usage: warmup2 [-lambda lambda] [-mu mu] [-r r] [-B B] [-P P] [-n num] [-t tsfile]\n");
		        exit(1);
		    }

		}
		else if(strcmp(argv[i],"-lambda")==0)
		{
			lamda=atof(argv[i+1]);
			if(lamda<=0)
			{
				fprintf(stderr,"Invalid lambda value entered\n");
				printf("Usage: warmup2 [-lambda lambda] [-mu mu] [-r r] [-B B] [-P P] [-n num] [-t tsfile]\n");
				exit(1);
			}
		}
			
		else if(strcmp(argv[i],"-mu")==0)
		{
			mu=atof(argv[i+1]);
			if(mu<=0)
			{
				fprintf(stderr,"Invalid mu value entered\n");
				printf("Usage: warmup2 [-lambda lambda] [-mu mu] [-r r] [-B B] [-P P] [-n num] [-t tsfile]\n");
				exit(1);
			}
		}
			
		else if(strcmp(argv[i],"-n")==0)
		{
			num=atoi(argv[i+1]);
			if(num<=0)
			{
				fprintf(stderr,"Invalid number of packets value entered\n");
				printf("Usage: warmup2 [-lambda lambda] [-mu mu] [-r r] [-B B] [-P P] [-n num] [-t tsfile]\n");
				exit(1);
			}
		}
			
		else if(strcmp(argv[i],"-P")==0)
		{
			P=atoi(argv[i+1]);
			if(P<=0)
			{
				fprintf(stderr,"Invalid P value entered\n");
				printf("Usage: warmup2 [-lambda lambda] [-mu mu] [-r r] [-B B] [-P P] [-n num] [-t tsfile]\n");
				exit(1);
			}
		}
			
		else if(strcmp(argv[i],"-B")==0)
		{
			B=atoi(argv[i+1]);
			if(B<=0)
			{
				fprintf(stderr,"Invalid B value entered\n");
				printf("Usage: warmup2 [-lambda lambda] [-mu mu] [-r r] [-B B] [-P P] [-n num] [-t tsfile]\n");
				exit(1);
			}
		}
			
		else if(strcmp(argv[i],"-r")==0)
		{
			r=atof(argv[i+1]);
			if(r<=0)
			{
				fprintf(stderr,"Invalid r value entered\n");
				printf("Usage: warmup2 [-lambda lambda] [-mu mu] [-r r] [-B B] [-P P] [-n num] [-t tsfile]\n");
				exit(1);
			}
		}
			
		else
		{
			fprintf(stderr, "Malformed Input command\n");
			printf("Usage: warmup2 [-lambda lambda] [-mu mu] [-r r] [-B B] [-P P] [-n num] [-t tsfile]\n");
			exit(1);
		}
		
	}
	

	if(flag==1)
	{
		if(fgets(str,1024,fp)!=NULL)
		{
			//printf("b\n");
			
			for(i=1;i<=strlen(str);i++)
			{
				if(str[i-1]=='\n')
					str[i-1]=str[i];
			}
				
			for(k=0;k<strlen(str);k++)
			{
				if(!(str[k]>=48 && str[k]<=57))
				{
					printf("Malformed Input - Line 1 is just not a number\n");
					exit(1);
				}
			}
				
			num=atoi(str);
			if(num<=0)
			{
				printf("Malformed Input - Line 1 is just not a number\n");
				exit(1);
			}
		}
		//printf("%d\n",num);

		if(fgets(str,1024,fp)!=NULL)
		{
			//printf("c\n");

			for(i=1;i<=strlen(str);i++)
				if(str[i-1]=='\n')
					str[i-1]='\0';
			//printf("%s\n",str);

			for(k=0;k<strlen(str);k++)
			{
				if(!((str[k]>=48 && str[k]<=57) || (str[k]==' ') || (str[k]=='\t')))
				{
					fprintf(stderr, "Malformed input\n");
					printf("Invalid characters entered in file\n");
					exit(1);
				}
			}
			i=0;
			len=0;
			while((str[i]!=' ') && (str[i]!='\t'))
			{
				//printf("%c",str[i]);
				temp[len]=str[i];
				i++;
				len++;
					
			}
			temp[len]='\0';
			len=0;
			//printf("%s\n",temp);
			a1=atof(temp);
			lamda=(1000/a1);
			while((str[i]==' ')||(str[i]=='\t'))
				i++;
			while((str[i]!=' ')&&(str[i]!='\t'))
			{
				temp1[len]=str[i];
				i++;
				len++;	
			}
			temp1[len]='\0';
			len=0;
			//printf("%s\n",temp1);
			a2=atoi(temp1);
			P=a2;
			while((str[i]==' ')||(str[i]=='\t'))
				i++;
			while(str[i]!='\0')
			{
				temp2[len]=str[i];
				i++;
				len++;
			}
			temp2[len]='\0';
			//printf("%s\n",temp2);
			a3=atof(temp2);
			mu=(1000/a3);
		}

	}


	if(flag==0)
	{
		if(num<=0)
		{
			fprintf(stderr,"Number of packets cannot be zero or negative\n");
			exit(1);
		}
		if(num>2147483647)
		{
			fprintf(stderr, "Number of packets entered is too big, number of packets should not exceed 2147483647\n");
			exit(1);
		}
		if(lamda<=0)
		{

			fprintf(stderr,"Lambda cannot be equal to zero or negative\n");
			exit(1);
		}
		if(mu<=0)
		{
			fprintf(stderr,"Mu cannot be equal to zero or negative\n");
			exit(1);
		}
		if(r<=0)
		{
			fprintf(stderr,"r cannot be equal to zero or negative\n");
			exit(1);
		}
		if(P<=0)
		{
			fprintf(stderr,"P cannot be equal to zero or negative\n");
			exit(1);
		}
		if(B<=0)
		{
			fprintf(stderr,"Bucket size cannot be zero or negative\n");
			exit(1);
		}
		
			
		printf("\nEmulation parameters:\n");
		printf("\tnumber to arrive = %d\n",num);
		printf("\tlambda = %lf\n",lamda);
		printf("\tmu = %lf\n",mu);
		printf("\tr = %lf\n",r);
		printf("\tB = %d\n",B);
		printf("\tP = %d\n",P);
	}
	
	if(flag==1)
	{
		if(num<=0)
		{
			fprintf(stderr,"Number of packets cannot be equal to zero or negative\n");
			exit(1);
		}
		if(num>2147483647)
		{
			fprintf(stderr, "Number of packets entered is too big, number of packets should not exceed 2147483647\n");
			exit(1);
		}
		if(lamda<=0)
		{
			fprintf(stderr,"Lambda cannot be equal to zero or negative\n");
			exit(1);
		}
		if(mu<=0)
		{
			fprintf(stderr,"Mu cannot be equal to zero or negative\n");
			exit(1);
		}
		if(r<=0)
		{
			fprintf(stderr,"r cannot be equal to zero or negative\n");
			exit(1);
		}
		if(P<=0)
		{
			fprintf(stderr,"P cannot be equal to zero or negative\n");
			exit(1);
		}
		if(B<=0)
		{
			fprintf(stderr,"Bucket size cannot be zero or negative\n");
			exit(1);
		}
		
		printf("\nEmulation parameters:\n");
		printf("\tnumber to arrive = %d\n",num);
		printf("\tr = %lf\n",r);
		printf("\tB = %d\n",B);
		printf("\ttsfile = %s\n",file_name);
	}

	if(flag==0)
	{
		if(lamda<0.1)
			lamda=0.1;
		if(mu<0.1)
			mu=0.1;
	}

	if(r<0.1)
		r=0.1;
	
	//printf("%lf\n %lf\n %lf\n %d\n %d\n %d\n",lamda,mu,r,num,P,B);

	packets->index=1;
	packets->P_token=P;
	packets->inter_arr=(1/lamda);
	packets->service_time=(1/mu);
	
	

	//printf("Index %d\n %d\n %lf\n %lf\n",packets->index, packets->P_token,packets->inter_arr,packets->service_time);

	
	//printf("%s %s %s\n",temp,temp1,temp2);

	sigprocmask(SIG_BLOCK,&set,0);

	pthread_create(&t[0],0,server1,packets);
	pthread_create(&t[1],0,server2,packets);
	pthread_create(&t[2],0,token_arrival,packets);
	pthread_create(&t[3],0,packet_arrival,packets);
	pthread_create(&t[4],0,monitor,NULL);

	pthread_join(t[0],0);
	pthread_join(t[1],0);
	pthread_join(t[2],0);
	pthread_join(t[3],0);
	//pthread_join(t[4],0);

	

	if(fl==1)
		{
			if(My402ListEmpty(Q1)!=1)
			{
				elem2=My402ListFirst(Q1);
				temp3=(pack*)(elem2->obj);
				while(elem2!=NULL)
				{
					gettimeofday(&tim,NULL);
					t2=tim.tv_sec+(tim.tv_usec/1000000.0);
					
					printf("%012.3fms: p%d removed from Q1\n",(t2-start_t)*1000,temp3->index);
					elem2=My402ListNext(Q1,elem2);
					if(elem2!=NULL)
					temp3=(pack*)(elem2->obj);
					removed_packs++;
				}
				My402ListUnlinkAll(Q1);
			}
			pthread_cond_broadcast(&cv);

		}

	if(f==1 || fl==1 || f_drop==1)
		{
			if(My402ListEmpty(Q2)!=1)
			{
				elem2=My402ListFirst(Q2);
				temp3=(pack*)(elem2->obj);
				while(elem2!=NULL)
				{
					gettimeofday(&tim,NULL);
					t3=tim.tv_sec+(tim.tv_usec/1000000.0);

					printf("%012.3fms: p%d removed from Q2\n",(t3-start_t)*1000,temp3->index);
					elem2=My402ListNext(Q2,elem2);
					if(elem2!=NULL)
					temp3=(pack*)(elem2->obj);
					removed_packs++;
				}
				My402ListUnlinkAll(Q2);
			}
		}

	gettimeofday(&tim,NULL);
	t1=tim.tv_sec+(tim.tv_usec/1000000.0);
	total_emulation=t1-start_t;

	printf("%012.3fms: Emulation ends MAIN\n",(t1-start_t)*1000);



	printf("\nStatistics:\n");

	if(arrived_packs>0)
	{
		arrival_avg=arrival_total/(double)(arrived_packs);
		printf("\taverage packet inter-arrival time = %.6gs\n",arrival_avg);
	}
	else
		printf("\taverage packet inter-arrival time = N/A, No packets arrived at this facility\n");

	if(completed_packs>0)
	{
		total_service=service_total1+service_total2;
		S_avg=total_service/(double)(completed_packs);
		printf("\taverage packet service time = %.6gs\n",S_avg);
	}
	else
		printf("\taverage packet service time = N/A, No packets arrived at this facility\n");
	

	Q1_avg=Q1_total/total_emulation;
	printf("\taverage number of packets in Q1 = %.6g\n",Q1_avg);

	Q2_avg=Q2_total/total_emulation;
	printf("\taverage number of packets in Q2 = %.6g\n",Q2_avg);

	S1_avg=service_total1/total_emulation;
	printf("\taverage number of packets at S1 = %.6g\n",S1_avg);

	S2_avg=service_total2/total_emulation;
	printf("\taverage number of packets at S2 = %.6g\n",S2_avg);

	if(completed_packs>0)
	{
		total_sys_avg=total_system_time/(double)(completed_packs);
		printf("\taverage time a packet spent in system = %.6gs\n",total_sys_avg);
		total_sq_sys_avg=total_sq_system_time/(double)(completed_packs);
	}
	else
	{
		printf("\taverage time a packet spent in system = N/A, No packets arrived at this facility\n");
		
	}

	var_sys_time=total_sq_sys_avg-(total_sys_avg*total_sys_avg);
	if(var_sys_time>=0 && completed_packs>0)
	{
		st_sys_time=(double)(sqrt(var_sys_time));
		printf("\tstandard deviation for time spent in system = %.6g\n",st_sys_time);
	}
	else
		printf("\tstandard deviation for time spent in system = N/A, No packets arrived at this facility or variance was found to be zero or negative\n");
	
		
	if(total_tok>0)
	{
		token_drop_prob=(double)dropped_tok/(double)(total_tok);
		printf("\ttoken drop probability = %.6g\n",token_drop_prob);
	}
	else
		printf("\ttoken drop probability = N/A, no tokens were generated\n");
	
	if(arrived_packs>0)
	{
		packet_drop_prob=(double)dropped_packs/(double)(arrived_packs);
		printf("\tpacket drop probability = %.6g\n",packet_drop_prob);
	}
	else
		printf("\tpacket drop probability = N/A, no packets arrived at the facility\n");
	



	/*
	printf("Removed packets: %d\n",removed_packs);
	printf("Dropped packets: %d\n",dropped_packs);
	printf("Dropped tokens: %d\n",dropped_tok);
	printf("Total emulation time is %lf\n",total_emulation);
	printf("Total time in Q1: %lf\n",Q1_total);
	printf("Total time in Q2: %lf\n",Q2_total);
	printf("Total arrival times: %lf\n",arrival_total);
	printf("Total time in service 1: %lf\n",service_total1);
	printf("Total time in service 2: %lf\n",service_total2);

	printf("Completed packets: %d\n",completed_packs);

	printf("Arguments are: %d\n",argc);
	*/
	//pthread_exit(0);
	return 0;

}

void *packet_arrival(void *a)
{
	struct timespec ts;
	//int y1,y2;
	double t1=0;
	double t2=0;
	double t3=0;
	double t4=0;
	double t5=0;
	double t6=0;
	struct timeval tim;
	//int count=1;
	double b=0;
	int k=0;
	double t7=0;
	double t8=0;
	double x=0;
	//double t9=0;


	pack* packets=NULL;
	//My402ListElem* elem=(My402ListElem*)malloc(sizeof(My402ListElem));
	My402ListElem* elem=NULL;
	//My402ListElem* elem2=(My402ListElem*)malloc(sizeof(My402ListElem));
	pack* temp= NULL;
	//pack* temp2=(pack*)malloc(sizeof(pack));
	//packets=(pack*)malloc(sizeof(pack));
	packets=(pack*)a;
	packets->Q1_arrive=0;
	packets->Q1_leave=0;
	packets->Q2_arrive=0;
	packets->Q2_leave=0;
	packets->S_leave=0;
	packets->S_arrive=0;
	packets->total_time_sys=0;
	packets->Q1_time=0;
	packets->Q2_time=0;
	packets->S_time=0;
	//printf("Packet thread\n");
	//printf("Packet %d\n %lf\n %lf\n",packets->P_token,packets->inter_arr,packets->service_time);
	printf("%012.3fms: Emulation begins\n",start_t);
	gettimeofday(&tim,NULL);
	start_t=tim.tv_sec+(tim.tv_usec/1000000.0);
	//start_t1=find_time();
	//printf("Start time is %lf\n",start_t1);
	//t3=packets->inter_arr;

	while(1)
	{
		//printf("First\n");
		pthread_mutex_lock(&m);

		//Exit packet thread when token generation is fast
		if(count>num && My402ListLength(Q2)==1)
		{
			pthread_cond_broadcast(&cv);
			pthread_mutex_unlock(&m);
			break;
		}
		//Exit packet thread when token generation is slow
		//else if(count>num && My402ListLength(Q2)==0)
		else if(count>num)
		{
			pthread_cond_broadcast(&cv);
			//printf("Dropppp\n");

			pthread_mutex_unlock(&m);
			break;
		}
		
		//Append to 1st queue
		//printf("Pack\n");
		
		
		//check if difference between observed & expected arrival time is greater than 0(overhead is greater than 0).
		if(t8>0)
		{
			//New arrival time=Expected arrival time-overhead
			//b=packets->inter_arr-t8;
			b=x-t8;
			//If New arrival time<0, then sleep for 0
			if(b<0 || packets->inter_arr<0.01)
				b=0;
		}
		else if(t8<0 && packets->inter_arr<0.01)
			b=0;	
		else
			b=packets->inter_arr;

		//printf("Value of b is: %lf\n",b);
		
		//b=packets->inter_arr;
		k=(int)(b);
		ts.tv_sec=k;
		ts.tv_nsec=(int)((b-k)*1000000000);
		pthread_mutex_unlock(&m);

		//pthread_setcancelstate(PTHREAD_CANCEL_DISABLE,0);

		nanosleep(&ts,NULL);
		//New Packet creation
		//packets=(pack*)malloc(sizeof(pack));

		pthread_mutex_lock(&m);
		
		if(fl==1)
		{
			/*
			if(My402ListEmpty(Q1)!=1)
			{
				elem2=My402ListFirst(Q1);
				temp2=(pack*)(elem2->obj);
				while(elem2!=NULL)
				{
					printf("\np%d removed from Q1\n",temp2->index);
					elem2=My402ListNext(Q1,elem2);
					if(elem2!=NULL)
					temp2=(pack*)(elem2->obj);
					removed_packs++;
				}
				My402ListUnlinkAll(Q1);
			}
			*/
			pthread_cond_broadcast(&cv);
			//printf("Packet suspended-kill\n");
			pthread_mutex_unlock(&m);
			break;
		}

		//pthread_setcancelstate(PTHREAD_CANCEL_ENABLE,0);
		//pthread_cleanup_push(pthread_mutex_unlock,&m);

		if(packets->P_token<=B && count<=num)
		{
			
			(void)My402ListAppend(Q1,packets);
			elem=My402ListFirst(Q1);
			temp=(pack*)(elem->obj);

			count++;			
			gettimeofday(&tim,NULL);
			t1=tim.tv_sec+(tim.tv_usec/1000000.0);
			//Absolute time value
			t2=t1-start_t;
			//(New arrival time)t4=absolute time value - old absolute arrival time
			t4=t2-t3;
			//printf("Value of t7 is: %lf\n",t7);
			/*if(t3>packets->inter_arr)
			{
				packets->inter_arr=t3;

			}*/
			packets->inter_arr=t4;
			//t3=old absolute arrival time
			t3=t2;
			//t8=observed arrival time - expected arrival time
			//t8=t4-b;
			//t8=t4-x;

			//printf("t4 value is: %lf\n",t4);
			
			
			gettimeofday(&tim,NULL);
			t5=tim.tv_sec+(tim.tv_usec/1000000.0);
			packets->Q1_arrive=t5;
			arrival_total=arrival_total+packets->inter_arr;
			arrived_packs++;

			printf("%012.3fms: p%d arrives, needs %d tokens, inter-arrival time = %.3lfms\n",(t2*1000),packets->index,packets->P_token,packets->inter_arr*1000);
			printf("%012.3fms: p%d enters Q1\n",(t5-start_t)*1000,packets->index);
		}
		else if(packets->P_token>B && count<=num)
		{
			count++;
			dropped_packs++;
			gettimeofday(&tim,NULL);
			t1=tim.tv_sec+(tim.tv_usec/1000000.0);
			//Absolute time value
			t2=t1-start_t;
			//(New arrival time)t4=absolute time value - old absolute arrival time
			t4=t2-t3;
			//printf("Value of t7 is: %lf\n",t7);
			/*if(t3>packets->inter_arr)
			{
				packets->inter_arr=t3;

			}*/
			packets->inter_arr=t4;
			//t3=old absolute arrival time
			t3=t2;
			
			//t8=t4-b;


			gettimeofday(&tim,NULL);
			t5=tim.tv_sec+(tim.tv_usec/1000000.0);
			packets->Q1_arrive=t5;
			arrival_total=arrival_total+packets->inter_arr;
			arrived_packs++;

			printf("%012.3fms: p%d arrives, needs %d tokens, inter-arrival time = %.3lfms, dropped\n",(t2*1000),packets->index,packets->P_token,packets->inter_arr*1000);
			if(packets->index==num)
			{
				pthread_cond_broadcast(&cv);
				f_drop=1;
			}
				
		}
			

		//read from file if required
		if(fp!=NULL)
		read_file();
		
		if(lamda<=0)
		{
			fprintf(stderr,"Lambda cannot be equal to zero or negative\n");
			exit(1);
		}
		if(mu<=0)
		{
			fprintf(stderr,"Mu cannot be equal to zero or negative\n");
			exit(1);
		}
		if(r<=0)
		{
			fprintf(stderr,"r cannot be equal to zero or negative\n");
			exit(1);
		}
		if(P<=0)
		{
			fprintf(stderr,"P cannot be equal to zero or negative\n");
			exit(1);
		}

		//New Packet creation
		if(count<=num)
		{
			packets=(pack*)malloc(sizeof(pack));
		
			//Add different attributes of packet to new packet
			packets->index=count;
			packets->P_token=P;
			packets->inter_arr=(1/lamda);
			packets->service_time=(1/mu);
			packets->Q1_arrive=0;
			packets->Q1_leave=0;
			packets->Q2_arrive=0;
			packets->Q2_leave=0;
			packets->S_leave=0;
			packets->S_arrive=0;
			packets->Q1_time=0;
			packets->Q2_time=0;
			packets->S_time=0;
			packets->total_time_sys=0;
		}
		
		

		x=packets->inter_arr;
		t8=t4-x;
		//printf("t8 value is: %lf\n",t8);
		
		if(My402ListEmpty(Q1)!=1)
		{
			elem=My402ListFirst(Q1);
			temp=(pack*)(elem->obj);
			if(temp->P_token<=n)
			{
			n=n-temp->P_token;
			
			gettimeofday(&tim,NULL);
			t6=tim.tv_sec+(tim.tv_usec/1000000.0);
			//t5=t4-t1;
			//t5=time in Q1
			temp->Q1_leave=t6;
			temp->Q1_time=temp->Q1_leave-temp->Q1_arrive;
			printf("%012.3fms: p%d leaves Q1, time in Q1 = %.3lfms, token bucket now has %d tokens\n",(t6-start_t)*1000,temp->index,(temp->Q1_leave-temp->Q1_arrive)*1000,n);
			
			//append to 2nd queue
			(void)My402ListAppend(Q2,temp);
			//start global timer for Q2
			gettimeofday(&tim,NULL);
			t7=tim.tv_sec+(tim.tv_usec/1000000.0);
			temp->Q2_arrive=t7;
			printf("%012.3fms: Packet P%d enters Q2\n",(t7-start_t)*1000,temp->index);
			
			//unlink from 1st queue
			My402ListUnlink(Q1,elem);
			//printf("Index: %d\n",temp->index);
			/*if(temp->index==34)
			{
				printf("WTF\n");
				My402ListUnlink(Q1,elem);
			}
			*/	
			if(My402ListLength(Q2)==1)
			pthread_cond_broadcast(&cv);
			}
		}
		//pthread_cleanup_pop(1);
		pthread_mutex_unlock(&m);

		//printf("count: %d\n",count);
		
	}
	//printf("Packet thread dead\n");
	return 0;
}

void *token_arrival(void *a)
{
	struct timespec ts;
	struct timeval tim;
	//int count=1;
	//int y2;
	double b=0;
	int k=0;
	int n2=0;
	double t1=0;
	double t2=0;
	double t3=0;
	double t4=0;
	pack* temp=NULL;
	//pack* temp2=(pack*)malloc(sizeof(pack));
	//My402ListElem* elem=(My402ListElem*)malloc(sizeof(My402ListElem));
	My402ListElem* elem=NULL;
	//My402ListElem* elem2=(My402ListElem*)malloc(sizeof(My402ListElem));
	//temp=(pack*)malloc(sizeof(pack));
	//temp=(pack*)a;
	
	n=0;
	//printf("Token Count:%d\n %d\n %lf\n %lf\n",temp->index,temp->P_token,temp->inter_arr,temp->service_time);
	while(1)
	{
		//printf("Second\n");
		//pthread_mutex_lock(&m);	
		//printf("Token\n");
		b=(1/r);
		k=(int)(b);
		ts.tv_sec=k;
		ts.tv_nsec=(int)((b-k)*1000000000);
		
		//printf("Token thread\n");
		//pthread_mutex_unlock(&m);

		//pthread_setcancelstate(PTHREAD_CANCEL_DISABLE,0);
		//pthread_cleanup_push(pthread_mutex_unlock,&m);

		nanosleep(&ts,NULL);

		pthread_mutex_lock(&m);
		if(fl==1)
		{
			/*
			if(My402ListEmpty(Q1)!=1)
			{
				elem2=My402ListFirst(Q1);
				temp2=(pack*)(elem2->obj);
				while(elem2!=NULL)
				{
					printf("\np%d removed from Q1\n",temp2->index);
					elem2=My402ListNext(Q1,elem2);
					if(elem2!=NULL)
					temp2=(pack*)(elem2->obj);
					removed_packs++;
				}
				My402ListUnlinkAll(Q1);
			}
			*/
			pthread_cond_broadcast(&cv);
			//printf("Token suspended-kill\n");
			pthread_mutex_unlock(&m);
			break;
		}
		
		//pthread_setcancelstate(PTHREAD_CANCEL_DISABLE,0);
		//pthread_cleanup_push(pthread_mutex_unlock,&m);
		
		
		//printf("Toke2\n");
		if(count<=num || (My402ListEmpty(Q1)!=1))
		{
			if(n<B)
		{
			n++;
			gettimeofday(&tim,NULL);
			t1=tim.tv_sec+(tim.tv_usec/1000000.0);
			total_tok++;
			printf("%012.3fms: token t%d arrives, token bucket now has %d token\n",(t1-start_t)*1000,total_tok,n);
			n2=n;
		}
		else
		{
			n2++;
			dropped_tok++;
			gettimeofday(&tim,NULL);
			t2=tim.tv_sec+(tim.tv_usec/1000000.0);
			total_tok++;
			printf("%012.3fms: token t%d arrives, dropped\n",(t2-start_t)*1000,total_tok);
		}
		}
		
			
		
		//printf("Token %d generated\n",n);
		//gettimeofday(&tim,NULL)
		//double t1=tim.tv_sec+(tim.tv_usec/1000000.0);
		if(My402ListEmpty(Q1)!=1)
		{	
			elem=My402ListFirst(Q1);
			temp=(pack*)(elem->obj);
			if(temp->P_token<=n)
			{
				n=n-temp->P_token;
				//gettimeofday(&tim,NULL)
				//double t2=tim.tv_sec+(tim.tv_usec/1000000.0);
				//t3=t2-(time at which packet entered Q1);
				//t3=time in Q1
				gettimeofday(&tim,NULL);
				t3=tim.tv_sec+(tim.tv_usec/1000000.0);
				temp->Q1_leave=t3;
				temp->Q1_time=temp->Q1_leave-temp->Q1_arrive;
				printf("%012.3fms: p%d leaves Q1, time in Q1 = %.3lfms, token bucket now has %d tokens\n",(t3-start_t)*1000,temp->index,(temp->Q1_leave-temp->Q1_arrive)*1000,n);
				/*if(t3>b)
				{
					packets->inter_arr=(b-(t3-b));

				}*/
				//append to 2nd queue
				(void)My402ListAppend(Q2,temp);
				gettimeofday(&tim,NULL);
				t4=tim.tv_sec+(tim.tv_usec/1000000.0);
				//temp->Q2_arrive=t4+0.025;
				temp->Q2_arrive=t4;
				printf("%012.3fms: P%d enters Q2\n",(t4-start_t)*1000,temp->index);
				//start global timer for Q2
				//unlink from 1st queue
				
				//printf("No of elements in Q1: %d\n",My402ListLength(Q1));

				My402ListUnlink(Q1,elem);

				pthread_cond_broadcast(&cv);
				
				//if(2nd queue has only 1 element)
				
				//end global timer for Q2
				
				//pthread_cond_signal(&cv,&m);
			}
		
		}
		if(count>num && (My402ListEmpty(Q1)==1))
		{
			pthread_mutex_unlock(&m);
			break;
		}
		/*
		if(My402ListLength(Q2)>0)
		{
					pthread_cond_signal(&cv);
					//printf("Packe sig\n");
		}
		*/
				//printf("Index: %d\n",temp->index);
			
		pthread_mutex_unlock(&m);

		
	}
	//printf("Token thread dead\n");
	return 0;	
}

void *server1(void *packets)
{
	struct timespec ts;
	struct timeval tim;
	double t1=0;
	double t2=0;
	double t3=0;
	//double t4=0;
	double b=0;
	int k=0;
	pack* temp=NULL;
	//pack* temp2=(pack*)malloc(sizeof(pack));
	My402ListElem* elem=NULL;
	//My402ListElem* elem2=(My402ListElem*)malloc(sizeof(My402ListElem));

	while(1)
	{
		//printf("Server thread\n");
		pthread_mutex_lock(&m);

		//printf("server1\n");
		//while Q2 is empty or fl=1, go to sleep
		while(!((My402ListEmpty(Q2)!=1) && (fl==0)))
		{
			//printf("wait 1\n");
			if(f==1 || fl==1 || f_drop==1)
			{
				break;
			}
			pthread_cond_wait(&cv,&m);	
		}
			
		if(f==1 || fl==1 || f_drop==1)
		{
			/*
			if(My402ListEmpty(Q2)!=1)
			{
				elem2=My402ListFirst(Q2);
				temp2=(pack*)(elem2->obj);
				while(elem2!=NULL)
				{
					printf("\np%d removed from Q2\n",temp2->index);
					elem2=My402ListNext(Q2,elem2);
					if(elem2!=NULL)
					temp2=(pack*)(elem2->obj);
					removed_packs++;
				}
				My402ListUnlinkAll(Q2);
			}
			*/
			//gettimeofday(&tim,NULL);
			//t4=tim.tv_sec+(tim.tv_usec/1000000.0);
			//printf("%012.3fms: Emulation ends\n",(t4-start_t)*1000);
			pthread_mutex_unlock(&m);
			break;
		}
			
		elem=My402ListFirst(Q2);
		temp=(pack*)(elem->obj);
		gettimeofday(&tim,NULL);
		t1=tim.tv_sec+(tim.tv_usec/1000000.0);
		temp->Q2_leave=t1;
		temp->Q2_time=temp->Q2_leave-temp->Q2_arrive;
		printf("%012.3fms: p%d leaves Q2,time in Q2= %.3lfms\n",(t1-start_t)*1000,temp->index,(temp->Q2_leave-temp->Q2_arrive)*1000);
		//printf("p%d arrives, needs %d tokens, inter-arrival time is %.3lfms\n",temp->index,temp->P_token,temp->inter_arr*1000);
		b=temp->service_time;
		//if(temp->service_time<0.01)
		//	b=0;
		if((b-(t3-t2))<0 && b<0.01)
			b=0;
		else
			b=temp->service_time;
		
		k=(int)(b);
		ts.tv_sec=k;
		ts.tv_nsec=(int)((b-k)*1000000000);
		
		//printf("Service thread2\n");
		gettimeofday(&tim,NULL);
		t2=tim.tv_sec+(tim.tv_usec/1000000.0);
		temp->S_arrive=t2;
		printf("%012.3fms: p%d begins service at S1, requesting %dms of service\n",(t2-start_t)*1000,temp->index,(int)(temp->service_time*1000));
		My402ListUnlink(Q2,elem);
		pthread_mutex_unlock(&m);
		nanosleep(&ts,NULL);
		pthread_mutex_lock(&m);
		gettimeofday(&tim,NULL);
		t3=tim.tv_sec+(tim.tv_usec/1000000.0);
		temp->S_leave=t3;
		temp->S_time=temp->S_leave-temp->S_arrive;
		temp->total_time_sys=temp->S_leave-temp->Q1_arrive;
		Q1_total=Q1_total+temp->Q1_time;
		Q2_total=Q2_total+temp->Q2_time;
		
		total_system_time=total_system_time+temp->total_time_sys;
		total_sq_system_time=total_sq_system_time+(temp->total_time_sys*temp->total_time_sys);

		//pthread_mutex_lock(&m);
		service_total1=service_total1+temp->S_time;
		completed_packs++;
		printf("%012.3fms: p%d departs from S1, service time = %.3lfms,time in system = %.3lfms\n",(t3-start_t)*1000,temp->index,(temp->S_leave-temp->S_arrive)*1000,(temp->S_leave-temp->Q1_arrive)*1000);
		

		//printf("Server index: %d\n",temp->index);
		if((temp->index==num) && (My402ListEmpty(Q2)==1))
		{
			f++;
			pthread_cond_broadcast(&cv);
			pthread_mutex_unlock(&m);
			break;
		}

		pthread_mutex_unlock(&m);
		
			

	}
	//printf("Server 1 dead\n");
	return 0;
}


void *server2(void *packets)
{
	struct timeval tim;
	struct timespec ts;
	double b=0;
	int k=0;
	double t1=0;
	double t2=0;
	double t3=0;
	//double t4=0;
	//double t6=0;
	pack* temp=NULL;
	//pack* temp2=(pack*)malloc(sizeof(pack));
	My402ListElem* elem=NULL;

	//My402ListElem* elem2=(My402ListElem*)malloc(sizeof(My402ListElem));

	while(1)
	{
		//printf("Server thread2\n");
		pthread_mutex_lock(&m);

		//printf("server2\n");
		
		while(!((My402ListEmpty(Q2)!=1) && (fl==0)))
		{
			//printf("wait2\n");
			if(f==1 || fl==1 || f_drop==1)
			{
				break;
			}
			pthread_cond_wait(&cv,&m);	
		}
		if(f==1 || fl==1 || f_drop==1)
		{
			/*if(My402ListEmpty(Q2)!=1)
			{
				elem2=My402ListFirst(Q2);
				temp2=(pack*)(elem2->obj);
				while(elem2!=NULL)
				{
					printf("\np%d removed from Q2\n",temp2->index);
					elem2=My402ListNext(Q2,elem2);
					if(elem2!=NULL)
					temp2=(pack*)(elem2->obj);
					removed_packs++;
				}
				My402ListUnlinkAll(Q2);
			}
			*/
			
			pthread_mutex_unlock(&m);
			break;
		}
		
		elem=My402ListFirst(Q2);
		temp=(pack*)(elem->obj);
		gettimeofday(&tim,NULL);
		t1=tim.tv_sec+(tim.tv_usec/1000000.0);
		temp->Q2_leave=t1;
		temp->Q2_time=temp->Q2_leave-temp->Q2_arrive;
		printf("%012.3fms: p%d leaves Q2,time in Q2= %.3lfms\n",(t1-start_t)*1000,temp->index,(temp->Q2_leave-temp->Q2_arrive)*1000);
		//printf("p%d arrives, needs %d tokens, inter-arrival time is %lf\n",temp->index,temp->P_token,temp->inter_arr*1000);
		b=temp->service_time;
		//if(temp->service_time<0.01)
		//	b=0;
		if((b-(t3-t2))<0 && b<0.01)
			b=0;
		else
			b=temp->service_time;

		//b=temp->service_time;
		k=(int)(b);
		ts.tv_sec=k;
		ts.tv_nsec=(int)((b-k)*1000000000);
		
		//printf("Service thread2\n");
		gettimeofday(&tim,NULL);
		t2=tim.tv_sec+(tim.tv_usec/1000000.0);
		temp->S_arrive=t2;
		printf("%012.3fms: p%d begins service at S2, requesting %dms of service\n",(t2-start_t)*1000,temp->index,(int)(temp->service_time*1000));
		My402ListUnlink(Q2,elem);
		pthread_mutex_unlock(&m);

		nanosleep(&ts,NULL);

		pthread_mutex_lock(&m);
		gettimeofday(&tim,NULL);
		t3=tim.tv_sec+(tim.tv_usec/1000000.0);
		temp->S_leave=t3;
		//printf("p%d departs from S2, service time = ,time in system =\n",temp->index);
		temp->S_time=temp->S_leave-temp->S_arrive;
		temp->total_time_sys=temp->S_leave-temp->Q1_arrive;
		Q1_total=Q1_total+temp->Q1_time;
		Q2_total=Q2_total+temp->Q2_time;
		
		total_system_time=total_system_time+temp->total_time_sys;
		total_sq_system_time=total_sq_system_time+(temp->total_time_sys*temp->total_time_sys);
		

		service_total2=service_total2+temp->S_time;
		completed_packs++;
		printf("%012.3fms: p%d departs from S2, service time = %.3lfms,time in system = %.3lfms\n",(t3-start_t)*1000,temp->index,(temp->S_leave-temp->S_arrive)*1000,(temp->S_leave-temp->Q1_arrive)*1000);

		//t6=find_time();
		//printf("\n\nTime between t6 & start=%lf\n\n",(t6-start_t1));
		//printf("T6 value is %lf\n",t6);
		
		//printf("Server index2: %d\n",temp->index);
		if((temp->index==num) && (My402ListEmpty(Q2)==1))
		{
			f++;
			pthread_cond_broadcast(&cv);
			pthread_mutex_unlock(&m);
			break;
		}
		pthread_mutex_unlock(&m);


	}
	//printf("Server 2 dead\n");	
	return 0;
}


void read_file()
{
	char str[1024],temp[20],temp1[20],temp2[20];
	int i=0;
	int len=0;
	int k=0;
	double a1=0;
	int a2=0;
	double a3=0;
	if(fgets(str,1024,fp)!=NULL)
		{
			//printf("c\n");

			for(i=1;i<=strlen(str);i++)
				if(str[i-1]=='\n')
					str[i-1]='\0';
			//printf("%s\n",str);

			for(k=0;k<strlen(str);k++)
			{
				if(!((str[k]>=48 && str[k]<=57) || (str[k]==' ') || (str[k]=='\t')))
				{
					printf("Invalid characters entered in file\n");
					exit(1);
				}
			}

			i=0;
			len=0;
			while((str[i]!=' ') && (str[i]!='\t'))
			{
				//printf("%c",str[i]);
				temp[len]=str[i];
				i++;
				len++;
					
			}
			temp[len]='\0';
			len=0;
			//printf("%s\n",temp);
			a1=atof(temp);
			if(a1<=0)
			{
				fprintf(stderr,"Malformed Input in file, invalid inter arrival time\n");
				exit(1);
			}
			lamda=(1000/a1);
			while((str[i]==' ')||(str[i]=='\t'))
				i++;
			while((str[i]!=' ')&&(str[i]!='\t'))
			{
				temp1[len]=str[i];
				i++;
				len++;	
			}
			temp1[len]='\0';
			len=0;
			//printf("%s\n",temp1);
			a2=atoi(temp1);
			if(a2<=0)
			{
				fprintf(stderr,"Malformed Input in file, Invalid P tokens entered\n");
				exit(1);
			}
			P=a2;
			while((str[i]==' ')||(str[i]=='\t'))
				i++;
			while(str[i]!='\0')
			{
				temp2[len]=str[i];
				i++;
				len++;
			}
			temp2[len]='\0';
			//printf("%s\n",temp2);
			a3=atof(temp2);
			if(a3<=0)
			{
				fprintf(stderr,"Malformed Input in file, Invalid service time entered\n");
				exit(1);
			}
			mu=(1000/a3);
		}
}

void *monitor()
{
	int sig;
	while(1)
	{
		sigwait(&set,&sig);
		pthread_mutex_lock(&m);
		fl=1;
		printf("\nSIGINT caught, no new packets or tokens will be allowed\n");
		pthread_cond_broadcast(&cv);

		pthread_mutex_unlock(&m);
		pthread_cancel(t[2]);
		pthread_cancel(t[3]);
		break;
	}
	return 0;
}
