#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/time.h>
#include <time.h>
#include <math.h>
#include <errno.h>
#include <sys/stat.h>
#include <pthread.h>

void *server1(void *);
void *server2(void *);
void *server3(void *);
void *server4(void *);

pthread_mutex_t m=PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t writersQ=PTHREAD_COND_INITIALIZER;
pthread_cond_t readersQ=PTHREAD_COND_INITIALIZER;

int readers=0;
int writers=0;

int main()
{
	pthread_t t[4];
	int a=0;
	pthread_create(&t[0],0,server1,&a);
	pthread_create(&t[1],0,server2,&a);
	//pthread_create(&t[2],0,server3,&a);
	//pthread_create(&t[3],0,server4,&a);
	printf("%d\n",a);
	pthread_join(t[0],0);
	pthread_join(t[1],0);
	//pthread_exit(0);
	return 0;

}

void *server1(void *x)
{
	//pthread_mutex_lock(&m);
	//int i=0;
	pthread_mutex_lock(&m);
	while(!(writers==0))
		pthread_cond_wait(&readersQ,&m);
	readers++;
	pthread_mutex_unlock(&m);
	pthread_mutex_lock(&m);
	*(int *)x = *(int *)x+1;
	printf("Value of x is %d\n",*(int *)x);
	if(--readers==0)
		pthread_cond_signal(&writersQ);
	pthread_mutex_unlock(&m);

	//pthread_mutex_unlock(&m);
	return 0;
}

void *server2(void *x)
{
	
	//pthread_mutex_lock(&m);
	pthread_mutex_lock(&m);
	while(!((readers==0)&&(writers==0)))
		pthread_cond_wait(&writersQ,&m);
	writers++;
	pthread_mutex_unlock(&m);
	*(int *)x = *(int *)x+2;
	printf("Value of x is %d\n",*(int *)x);
	pthread_mutex_lock(&m);
	writers--;
	pthread_cond_signal(&writersQ);
	pthread_cond_broadcast(&readersQ);
	pthread_mutex_unlock(&m);
	

	//pthread_mutex_unlock(&m);
	return 0;
}


void *server3(void *x)
{
	
	//pthread_mutex_lock(&m);
	*(int *)x = *(int *)x+3;
	printf("Value of x is %d\n",*(int *)x);
	//pthread_mutex_unlock(&m);
	return 0;
}

void *server4(void *x)
{
	
	//pthread_mutex_lock(&m);
	*(int *)x = *(int *)x+4;
	printf("Value of x is %d\n",*(int *)x);
	//pthread_mutex_unlock(&m);
	return 0;
}